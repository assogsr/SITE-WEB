# Tester GSR sur votre ordinateur

**Version de recette actuelle : voir [le guide Docker du 12 octobre 2026](../docs/phase1/GUIDE_RECETTE_DOCKER_GSR.md), qui précise les commandes depuis la racine, les cinq profils et les blocages antivirus.**

Ce paquet démarre la version sécurisée du projet localement. Il ne publie rien et ne contacte ni WordPress ni LWS. Tous les comptes et dossiers fournis sont fictifs.

## Windows

1. Installez Docker Desktop depuis https://www.docker.com/products/docker-desktop/ puis ouvrez-le. Il peut nécessiter WSL2 et un redémarrage ; attendez que Docker soit prêt.
2. Extrayez complètement cette archive ZIP dans un dossier.
3. Double-cliquez sur DEMARRER-WINDOWS.cmd. La première préparation nécessite Internet et plusieurs minutes pour télécharger les images Docker. Les dépendances Python sont incluses.
4. Le navigateur ouvre http://localhost:3000. Gardez Docker Desktop ouvert pendant les essais.
5. Pour arrêter, utilisez ARRETER-WINDOWS.cmd. Les données fictives sont conservées pour la prochaine ouverture.

## macOS / Linux ou terminal Windows

Sur les Mac à puce Apple, le backend utilise l’émulation amd64 fournie par Docker Desktop.

Depuis le dossier extrait, avec Docker Desktop ou Docker Engine et Compose installés :

```
docker compose up -d --build --wait --wait-timeout 180
```

Ouvrez http://localhost:3000. Pour arrêter : `docker compose stop`.

## Parcours de test

- Site public : navigation, formations, agences et contact. Envoyez uniquement des coordonnées fictives et utilisez la référence complète dans /suivi.
- CRM : http://localhost:3000/crm/login. Cliquez sur l’un des comptes de démonstration proposés puis connectez-vous ; aucun mot de passe existant n’est reproduit dans ce guide.

Accueil et Responsable peuvent consulter et modifier les prospects des deux agences, conformément au partage validé par GSR. Les calendriers et les sessions restent limités à leur agence, les exports à la Direction ; l’éditeur accède aux contenus sans données commerciales privées. Annuler un prospect lié à un RDV d’une autre agence reste réservé à la Direction. Les anciennes références fictives fournies dans le CRM ne sont pas utilisables en suivi public : créez une nouvelle demande pour tester ce suivi.

Les quotas de formulaires restent actifs (cinq demandes par dix minutes dans ce paquet local). En cas de 429, attendez avant de recommencer. Ne saisissez pas de données réelles : cette version contient volontairement des identifiants de démonstration visibles et ne convient pas à un hébergement public.

## En cas de problème

- Connexion refusée : vérifiez que Docker Desktop fonctionne et que le lancement est terminé.
- Port 3000 occupé : fermez le programme qui l’utilise. Dans PowerShell, vous pouvez aussi lancer `$env:GSR_PORT="3001"; docker compose up -d --build --wait` puis ouvrir http://localhost:3001. Les ports locaux 3000 et 3001 sont déjà autorisés.
- Diagnostic : `docker compose ps` puis `docker compose logs --tail=50`.

MongoDB et l’API ne sont pas exposés à votre réseau ; seul le site est accessible sur la boucle locale. Une clé JWT aléatoire est créée au premier démarrage et conservée dans un volume local. N’utilisez jamais les mots de passe de ce paquet pour une application réelle.

## Validation initiale du paquet (avant le lot bloquant)

Démarrage Docker vérifié : trois services sains. Six contrôles navigateur réussis, sans erreur JavaScript : accueil, contact et connexion au CRM avec chacun des quatre rôles. Validation exécutée localement sur le port 3001 pour conserver le serveur cloud existant. Les tests ont modifié uniquement une base fictive propre à ce paquet.

## WhatsApp des agences

Le bouton vert est disponible sur toutes les pages publiques. Il propose Créteil et Bonneuil-sur-Marne. Aucun numéro WhatsApp n’est fourni par défaut ; les liens restent désactivés tant que la Direction ne les a pas configurés. Pour configurer : connectez-vous au CRM avec le rôle Direction, puis ouvrez http://localhost:3000/administration/whatsapp dans le même navigateur. Cette page de réglage est séparée du CRM. Renseignez uniquement les numéros internationaux confirmés par vos agences comme actifs sur WhatsApp, puis enregistrez. Vider un champ désactive le lien correspondant. En cas d’utilisation du port 3001, remplacez simplement 3000 dans cette adresse.

## Lot bloquant — 11 octobre 2026

MongoDB est maintenant initialisé en replica set pour permettre les transactions. Les volumes existants sont conservés : ne lancez pas `docker compose down -v`. Le démarrage comprend désormais les services site, backend, MongoDB, sauvegarde et notifications. La sauvegarde possède un contrôle de santé ; le service de notifications tourne avec les envois désactivés.

Une nouvelle réservation avec créneau affiche un lien personnel d’annulation/report. Il expire après sept jours par défaut ; il ne donne accès ni au dossier privé ni à l’identité. Conservez-le sans le partager. Pour un rendez-vous le jour même, contactez l’agence. Un déplacement reste dans la même agence. Les anciennes réservations ne reçoivent pas de lien rétroactif.

Avec le rôle Direction, ouvrez `/administration/notifications` pour préparer les expéditeurs SMTP et les modèles approuvés. Aucun serveur ou modèle validé n’est fourni ; les trois expéditeurs officiels approuvés sont préconfigurés. La clé SMTP doit être installée séparément dans le volume de secrets (`smtp-password`), jamais dans le formulaire ni le dépôt. Une activation technique supplémentaire `GSR_SMTP_SEND_ENABLED=true` est nécessaire. Ne l’activez pas pour les essais fictifs. Les envois non confirmés restent en vérification humaine, sans renvoi automatique.

Une sauvegarde chiffrée est créée au démarrage puis toutes les 24 heures. Les archives et la clé sont dans des volumes distincts. Garder une copie indépendante de la clé est indispensable pour restaurer. `GSR_BACKUP_DESTINATION` prépare une destination extérieure ; par défaut, le stockage reste local et ne protège pas contre la perte de l’hôte. Un répertoire monté doit être accessible à l’utilisateur du conteneur (UID 10001). Ne publiez ni la clé ni les archives.

Restauration de test uniquement, vers une base neuve `gsr_restore_test_*` :

```sh
docker compose exec -T backup python backup.py restore /backups/NOM.gsrbackup gsr_restore_test_RECETTE
```

Une base existante est refusée. Les archives altérées sont refusées avant restauration. Un dump effectué pendant des écritures est retenté trois fois, puis refusé : la sauvegarde d’une infrastructure active devra utiliser une stratégie cohérente adaptée. Voir [RAPPORT_LOT_BLOQUANT_GSR.md](../RAPPORT_LOT_BLOQUANT_GSR.md).

## Décision email GSR — trois comptes séparés

Les contacts et expéditeurs approuvés sont Créteil `creteil.gsr@gmail.com`, Bonneuil `accueil.gsr@gmail.com` et partenariats/formation IA `asso.gsr@gmail.com`. Les demandes partenariat/IA utilisent toujours le service associatif, quelle que soit l’agence. Le champ `Reply-To` reprend l’expéditeur correspondant.

Dans `/administration/notifications`, la Direction prépare trois configurations SMTP distinctes et personnalise les modèles. Les mots de passe sont uniquement dans des fichiers privés distincts du volume de secrets : `smtp-creteil-password`, `smtp-bonneuil-password`, `smtp-asso-password`, accessibles à l’UID 10001 et sans permission de groupe/autres (`0600`). Aucune clé n’est livrée ou inscrite dans le code, la base ou le formulaire. Les anciens paramètres communs sont conservés pour compatibilité mais ne permettent pas de débloquer un envoi réel.

Le paquet local conserve les tests de connexion réels désactivés (`GSR_SMTP_TEST_ENABLED=false`) et les envois désactivés. Une simulation SMTP ne valide jamais les comptes Gmail. Même une activation technique d’envoi ne suffit pas : les **trois comptes** doivent avoir une connexion authentifiée testée sur leurs paramètres/secrets actuels, et le modèle doit être approuvé. Changer une configuration, un expéditeur ou un secret invalide la vérification correspondante. Le test de connexion ne valide pas la réception/délivrabilité : celle-ci reste à vérifier sur les comptes réels lors d’une étape autorisée.

Le journal Direction contient date, service, expéditeur, adresse de réponse, destinataire et résultat. Les incidents ambigus restent sans relance automatique. Aucun SMTP réel n’a été contacté dans ce lot.
