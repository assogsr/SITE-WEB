import asyncio
import os
from pathlib import Path

os.environ['JWT_SECRET']=Path('/settings/jwt-secret').read_text().strip()
from notifications import worker

asyncio.run(worker())
