import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import api, { apiError, getCreneaux } from "@/lib/api";
import { PageHero, Section } from "@/components/site/Page";

export default function RdvManagement() {
  const { token } = useParams();
  const [rdv, setRdv] = useState(null);
  const [slots, setSlots] = useState([]);
  const [selected, setSelected] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    let robots = document.querySelector('meta[name="robots"]');
    const previous = robots?.getAttribute("content");
    if (!robots) { robots = document.createElement("meta"); robots.name = "robots"; document.head.appendChild(robots); }
    robots.content = "noindex, nofollow";
    return () => { if (previous == null) robots.remove(); else robots.content = previous; };
  }, []);
  useEffect(() => {
    let active = true;
    api.get(`/rdv/gestion/${token}`).then(async ({ data }) => {
      if (!active) return;
      setRdv(data);
      const rows = data.active ? await getCreneaux(data.agency) : [];
      if (active) setSlots(rows);
    }).catch(e => active && setError(apiError(e)));
    return () => { active = false; };
  }, [token]);
  const change = async action => {
    setBusy(true); setError("");
    try {
      const { data } = await api.post(`/rdv/gestion/${token}`, { action, creneau_id: selected || null });
      setRdv(data); setSelected("");
      setSlots(data.active ? await getCreneaux(data.agency) : []);
    } catch (e) { setError(apiError(e)); }
    finally { setBusy(false); }
  };
  return <div data-testid="rdv-management">
    <PageHero label="Votre rendez-vous" title="Gérer mon rendez-vous" text="Ce lien est personnel. Conservez-le sans le partager." />
    <Section>
      <div className="max-w-xl space-y-5">
        {error && <p role="alert" className="text-[#b4532a]">{error}</p>}
        {rdv && <>
          <p data-testid="management-status">{rdv.active ? `Créneau réservé : ${rdv.date} à ${rdv.time}` : "Votre rendez-vous est annulé."}</p>
          {rdv.active && <>
            <label htmlFor="new-slot" className="block text-sm">Choisir un autre créneau dans la même agence</label>
            <select id="new-slot" data-testid="management-slot" value={selected} onChange={e => setSelected(e.target.value)} className="w-full rounded-xl border border-[#25333D]/15 px-4 py-3">
              <option value="">Sélectionner un créneau</option>
              {slots.filter(s => s.remaining > 0).map(s => <option key={s.id} value={s.id}>{s.date} à {s.time}</option>)}
            </select>
            <button data-testid="management-move" disabled={busy || !selected} onClick={() => change("deplacer")} className="rounded-full bg-[#25333D] text-white px-6 py-3 disabled:opacity-50">Confirmer le déplacement</button>
            <p className="text-sm text-[#53616B]">Le bouton suivant annule le rendez-vous et libère sa place.</p>
            <button data-testid="management-cancel" disabled={busy} onClick={() => change("annuler")} className="rounded-full border border-[#25333D] px-6 py-3 disabled:opacity-50">Confirmer l’annulation</button>
          </>}
        </>}
      </div>
    </Section>
  </div>;
}
