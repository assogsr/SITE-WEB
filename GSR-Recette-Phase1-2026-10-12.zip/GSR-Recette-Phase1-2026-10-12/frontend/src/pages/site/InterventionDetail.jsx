import {useParams,Navigate} from 'react-router-dom';
import {PREVENTION} from '@/data/gsr';
import {PageHero,Section} from '@/components/site/Page';
import PublicBusinessForm from '@/components/site/PublicBusinessForm';
export default function InterventionDetail(){const {action}=useParams();const item=PREVENTION.find(x=>String(x.id)===action);if(!item)return <Navigate to="/securite-routiere" replace/>;return <div><PageHero label="Sécurité routière" title={item.title} image={item.image} text={item.text}/><Section><h2 className="font-clash text-2xl mb-6">Demander cette intervention</h2><PublicBusinessForm action={item.title}/></Section></div>;}
