import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { crm } from "@/crm/auth";
import { apiError } from "@/lib/api";
import { inputCls } from "@/crm/CrmLayout";

const EVENTS = [["accuse", "Accusé de réception"], ["annulation", "Annulation"], ["deplacement", "Déplacement"], ["rappel-rdv", "Rappel de rendez-vous"], ["intervention-j1", "Intervention sans réponse à J+1 (message neutre)"]];
const SERVICES = [["creteil", "Créteil"], ["bonneuil", "Bonneuil-sur-Marne"], ["asso", "Partenariats et formations IA"]];
export default function NotificationSettings() {
  const [config, setConfig] = useState(null);
  const [journal, setJournal] = useState([]);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [saved, setSaved] = useState(false);
  const load = () => {
    setError("");
    return Promise.all([crm.get("/administration/notifications"), crm.get("/administration/notifications/journal")])
      .then(([c, j]) => { setConfig(c.data); setJournal(j.data); })
      .catch(e => setError(apiError(e)));
  };
  useEffect(() => { load(); }, []);
  const field = (key, value) => setConfig({ ...config, [key]: value });
  const template = (event, key, value) => setConfig({ ...config, templates: { ...config.templates, [event]: { subject: "", body: "", approved: false, ...config.templates[event], [key]: value } } });
  const save = async e => {
    e.preventDefault(); setBusy(true); setError(""); setSaved(false);
    try {
      const { password_configured, sending_enabled, accounts_status, all_accounts_verified, testing_enabled, ...body } = config;
      for (const key of ["host", "username", "from_email", "creteil_email", "bonneuil_email"]) body[key] = body[key] || null;
      await crm.put("/administration/notifications", body); await load(); setSaved(true);
    } catch (e) { setError(apiError(e)); }
    finally { setBusy(false); }
  };
  return <main data-testid="notification-settings" className="min-h-screen bg-[#F6F3EE] text-[#25333D] font-satoshi p-6 lg:p-12">
    <div className="max-w-3xl mx-auto space-y-6">
      <Link to="/crm" className="text-sm hover:text-[#F29A58]">← CRM</Link>
      <h1 className="font-clash text-3xl">Emails et notifications</h1>
      <p className="text-sm text-[#53616B]">Les trois comptes doivent être configurés et testés avant tout envoi réel. Les secrets sont conservés séparément. Les modèles restent soumis à l’approbation de la Direction.</p>
      {error && <div role="alert"><p>{error}</p><button onClick={load}>Réessayer le chargement</button></div>}
      {config && <form onSubmit={save} className="bg-white p-6 space-y-5">
        <label className="flex gap-3"><input type="checkbox" checked={config.enabled} onChange={e => field("enabled", e.target.checked)} />Activer les modèles approuvés après configuration</label>
        {[["from_email", "Expéditeur partenariats / IA"], ["creteil_email", "Expéditeur Créteil"], ["bonneuil_email", "Expéditeur Bonneuil"]].map(([key, label]) => <label key={key} className="block text-sm">{label}<input type="email" data-testid={`smtp-${key}`} value={config[key] || ""} onChange={e => field(key, e.target.value)} className={`${inputCls} block w-full mt-2`} /></label>)}
        {SERVICES.map(([service,label]) => {
          const account = config.accounts?.[service] || { port: 587, tls: "starttls" };
          const update = (key,value) => field("accounts", { ...config.accounts, [service]: { ...account, [key]: value || null } });
          const status = config.accounts_status?.[service];
          return <fieldset key={service} className="border border-[#25333D]/15 p-4 space-y-3"><legend>SMTP — {label}</legend>
            {[["host","Serveur"],["username","Identifiant"]].map(([key,title]) => <label key={key} className="block text-sm">{title}<input data-testid={`smtp-${service}-${key}`} value={account[key] || ""} onChange={e => update(key,e.target.value)} className={`${inputCls} block w-full mt-1`} /></label>)}
            <label className="block text-sm">Port<input type="number" min="1" max="65535" value={account.port} onChange={e => update("port",Number(e.target.value))} className={`${inputCls} block mt-1`} /></label>
            <label className="block text-sm">Connexion chiffrée<select value={account.tls} onChange={e => update("tls",e.target.value)} className={`${inputCls} block mt-1`}><option value="starttls">STARTTLS</option><option value="ssl">TLS</option></select></label>
            <p className="text-sm">Secret : {status?.password_configured ? "configuré" : "non configuré"}. Compte : {status?.verified ? "connexion testée" : "à configurer et tester"}.</p>
            <button type="button" disabled={!config.testing_enabled || !status?.configured || busy} onClick={async () => {
              setBusy(true); setError("");
              try { await crm.post(`/administration/notifications/comptes/${service}/tester`); await load(); }
              catch(e) { setError(apiError(e)); } finally { setBusy(false); }
            }} className="text-sm underline disabled:opacity-50">Tester la connexion enregistrée</button>
          </fieldset>;
        })}
        <p className="text-sm">Envoi technique : {config.sending_enabled ? "activé" : "désactivé"}. Trois comptes validés : {config.all_accounts_verified ? "oui" : "non"}. Réponses dirigées vers l’expéditeur du service.</p>
        <p className="text-sm text-[#53616B]">Champs de modèle disponibles : {"{reference}, {agency}, {date}, {time}"}.</p>
        {EVENTS.map(([event, label]) => <fieldset key={event} className="border border-[#25333D]/15 p-4 space-y-3"><legend>{label}</legend>
          <label className="block text-sm">Objet<input value={config.templates[event]?.subject || ""} onChange={e => template(event, "subject", e.target.value)} className={`${inputCls} block w-full mt-1`} /></label>
          <label className="block text-sm">Message<textarea value={config.templates[event]?.body || ""} onChange={e => template(event, "body", e.target.value)} className={`${inputCls} block w-full mt-1`} rows={4} /></label>
          <label className="flex gap-2 text-sm"><input type="checkbox" checked={!!config.templates[event]?.approved} onChange={e => template(event, "approved", e.target.checked)} />Modèle validé par la Direction</label>
        </fieldset>)}
        <button data-testid="smtp-save" disabled={busy} className="rounded-full bg-[#25333D] text-white px-6 py-3 disabled:opacity-50">Enregistrer</button>
        {saved && <p role="status">Configuration enregistrée.</p>}
      </form>}
      <section className="bg-white p-6"><h2 className="font-clash text-xl">Journal des emails</h2><p className="mt-2 text-sm text-[#53616B]">Un envoi incertain exige une vérification humaine ; il n’est pas relancé automatiquement.</p>
        <ul className="mt-4 space-y-2 text-sm break-words">{journal.map(j => <li key={j.id}>{j.created_at} — {j.service || "agence"} — {j.event} — {j.status}{j.sender && ` — ${j.sender}`}{j.recipient && ` → ${j.recipient}`}{j.failure && ` — ${j.failure}`}</li>)}</ul>
      </section>
    </div>
  </main>;
}
