import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { crm } from "@/crm/auth";
import { apiError } from "@/lib/api";

const AGENCIES = [["creteil", "Créteil"], ["bonneuil", "Bonneuil-sur-Marne"]];

export default function WhatsAppSettings() {
  const [numbers, setNumbers] = useState({ creteil: "", bonneuil: "" });
  const [loading, setLoading] = useState(true);
  const [ready, setReady] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [saved, setSaved] = useState(false);
  useEffect(() => {
    const controller = new AbortController();
    crm.get("/administration/whatsapp", { signal: controller.signal })
      .then(({ data }) => { setNumbers({ creteil: data.creteil || "", bonneuil: data.bonneuil || "" }); setReady(true); })
      .catch((e) => { if (!controller.signal.aborted) setError(apiError(e, "Impossible de charger les réglages WhatsApp.")); })
      .finally(() => { if (!controller.signal.aborted) setLoading(false); });
    return () => controller.abort();
  }, []);
  const submit = async (e) => {
    e.preventDefault(); if (!ready) return;
    setBusy(true); setSaved(false); setError("");
    try {
      const { data } = await crm.patch("/administration/whatsapp", numbers);
      setNumbers({ creteil: data.creteil || "", bonneuil: data.bonneuil || "" });
      setSaved(true);
    } catch (e) { setError(apiError(e, "Les réglages n’ont pas pu être enregistrés.")); }
    finally { setBusy(false); }
  };
  return (
    <main data-testid="whatsapp-settings" className="min-h-screen bg-[#FFF4EA] px-6 py-12 font-satoshi text-[#25333D]">
      <div className="mx-auto max-w-xl">
        <Link to="/crm" className="text-sm underline underline-offset-4 focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#F29A58]">Retour au CRM</Link>
        <h1 className="mt-8 font-clash text-3xl font-semibold">WhatsApp des agences</h1>
        <p className="mt-4 text-sm text-[#53616B]">Réglage réservé à la Direction. Renseignez uniquement un numéro dont l’agence a confirmé l’utilisation sur WhatsApp.</p>
        <p id="whatsapp-number-help" className="mt-3 text-sm text-[#53616B]">Utilisez le format international avec son indicatif. Laissez le champ vide pour désactiver le lien de cette agence.</p>
        <form onSubmit={submit} className="mt-8 space-y-6">
          {AGENCIES.map(([id, label]) => (
            <div key={id}>
              <label htmlFor={`whatsapp-number-${id}`} className="block text-sm font-semibold">{label}</label>
              <input id={`whatsapp-number-${id}`} data-testid={`whatsapp-number-${id}`} type="tel" inputMode="tel" autoComplete="off" maxLength={32} aria-describedby="whatsapp-number-help" disabled={!ready || busy} value={numbers[id]} onChange={(e) => { setNumbers({ ...numbers, [id]: e.target.value }); setSaved(false); }} className="mt-2 w-full rounded-xl border border-[#25333D]/20 bg-white px-4 py-3 focus:outline-none focus:ring-2 focus:ring-[#F29A58] disabled:opacity-60" />
            </div>
          ))}
          {loading && <p role="status">Chargement des réglages…</p>}
          {error && <p role="alert" className="text-sm text-[#b4532a]">{error}</p>}
          {error && !ready && !loading && <button type="button" onClick={() => window.location.reload()} className="text-sm underline">Réessayer le chargement</button>}
          {saved && <p role="status" data-testid="whatsapp-settings-saved" className="text-sm">Réglages enregistrés. Ils seront appliqués à la prochaine ouverture du choix WhatsApp sur le site.</p>}
          <button data-testid="whatsapp-settings-save" disabled={!ready || busy} className="rounded-full bg-[#25333D] px-6 py-3 font-semibold text-white hover:bg-[#F29A58] hover:text-[#25333D] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#25333D] disabled:opacity-60">{busy ? "Enregistrement…" : "Enregistrer"}</button>
        </form>
      </div>
    </main>
  );
}
