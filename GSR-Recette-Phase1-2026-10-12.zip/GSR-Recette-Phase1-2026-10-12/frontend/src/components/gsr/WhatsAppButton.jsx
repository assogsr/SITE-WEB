import { useEffect, useRef, useState } from "react";
import { useLocation } from "react-router-dom";
import * as Dialog from "@radix-ui/react-dialog";
import { X } from "lucide-react";
import api from "@/lib/api";
import "./WhatsAppButton.css";

const AGENCIES = [["creteil", "Créteil"], ["bonneuil", "Bonneuil-sur-Marne"]];
const validUrl = (url) => typeof url === "string" && /^https:\/\/wa\.me\/[1-9][0-9]{7,14}$/.test(url);

// Keep a floating action clear of visible links, fields and other buttons.
function useClearPosition(button, pathname) {
  const base = pathname.startsWith("/proposition") ? 96 : 20;
  const [bottom, setBottom] = useState(base);
  useEffect(() => {
    let frame;
    const position = () => {
      frame = null;
      if (!button.current) return;
      const rect = button.current.getBoundingClientRect();
      const obstacles = [...document.querySelectorAll('a, button, input, select, textarea, [role="button"]')]
        .filter((element) => !element.closest("[data-whatsapp-root]") && element.getClientRects().length)
        .filter((element) => { const style = getComputedStyle(element); return style.visibility !== "hidden" && style.display !== "none"; })
        // A whole clickable image/card is not a compact action button.
        .filter((element) => element.tagName !== "A" || element.getBoundingClientRect().height <= 120)
        .map((element) => element.getBoundingClientRect());
      const safeArea = Math.max(0, parseFloat(getComputedStyle(button.current.parentElement).bottom) - bottom);
      let next = base;
      for (; next <= window.innerHeight - rect.height - safeArea - 24; next += rect.height + 12) {
        const top = window.innerHeight - next - safeArea - rect.height;
        if (!obstacles.some((other) => other.width && other.height && other.left < rect.right + 8 && other.right > rect.left - 8 && other.top < top + rect.height + 8 && other.bottom > top - 8)) break;
      }
      if (next > window.innerHeight - rect.height - safeArea - 24) next = base;
      setBottom((current) => current === next ? current : next);
    };
    const schedule = () => { if (frame == null) frame = requestAnimationFrame(position); };
    schedule();
    window.addEventListener("scroll", schedule, true);
    window.addEventListener("resize", schedule);
    const observer = new MutationObserver((records) => {
      if (records.some((record) => !record.target.closest?.("[data-whatsapp-root]"))) schedule();
    });
    // Include animated reveal styles, so a moving control cannot cross behind the button.
    observer.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ["style", "class"] });
    return () => { if (frame != null) cancelAnimationFrame(frame); window.removeEventListener("scroll", schedule, true); window.removeEventListener("resize", schedule); observer.disconnect(); };
  }, [button, pathname, base, bottom]);
  return bottom;
}

export default function WhatsAppButton() {
  const { pathname } = useLocation();
  const [open, setOpen] = useState(false);
  const [config, setConfig] = useState(null);
  const [error, setError] = useState(false);
  const trigger = useRef(null);
  const bottom = useClearPosition(trigger, pathname);
  useEffect(() => { setOpen(false); }, [pathname]);
  useEffect(() => {
    if (!open) return;
    const controller = new AbortController();
    setConfig(null); setError(false);
    api.get("/contact/whatsapp", { signal: controller.signal })
      .then(({ data }) => setConfig(Array.isArray(data.agencies) ? data.agencies : []))
      .catch(() => { if (!controller.signal.aborted) { setConfig([]); setError(true); } });
    return () => controller.abort();
  }, [open]);
  const privatePage = /^\/(crm|administration)(\/|$)/.test(pathname);
  if (privatePage) return null;
  return (
    <Dialog.Root open={open} onOpenChange={setOpen}>
      <div data-whatsapp-root className="gsr-whatsapp-position" style={{ bottom: `calc(${bottom}px + env(safe-area-inset-bottom, 0px))` }}>
        <Dialog.Trigger asChild>
          <button ref={trigger} data-testid="whatsapp-trigger" type="button" className="gsr-whatsapp-trigger" aria-label="Contacter une agence GSR sur WhatsApp" title="Contacter GSR sur WhatsApp">
            <img src="/assets/whatsapp-logo.svg" alt="" aria-hidden="true" width="32" height="32" />
          </button>
        </Dialog.Trigger>
      </div>
      <Dialog.Portal>
        <Dialog.Overlay className="gsr-whatsapp-overlay" />
        <Dialog.Content data-whatsapp-root data-testid="whatsapp-chooser" className="gsr-whatsapp-chooser font-satoshi">
          <Dialog.Title className="pr-8 font-clash text-2xl font-semibold text-[#25333D]">Choisissez votre agence</Dialog.Title>
          <Dialog.Description className="mt-3 text-sm text-[#53616B]">Contactez Créteil ou Bonneuil-sur-Marne sur WhatsApp. Un lien disponible s’ouvre dans un nouvel onglet.</Dialog.Description>
          <div className="mt-6 space-y-4" aria-busy={config === null}>
            {AGENCIES.map(([id, label]) => {
              const url = config?.find((agency) => agency.id === id)?.url;
              const available = validUrl(url);
              return (
                <div key={id}>
                  {available ? <a data-testid={`whatsapp-agency-${id}`} className="gsr-whatsapp-agency" href={url} target="_blank" rel="noopener noreferrer" aria-label={`Contacter l’agence de ${label} sur WhatsApp (nouvel onglet)`}>{label}</a> : <button data-testid={`whatsapp-agency-${id}`} className="gsr-whatsapp-agency" type="button" disabled aria-describedby={`whatsapp-unavailable-${id}`}>{label}</button>}
                  {!available && <p id={`whatsapp-unavailable-${id}`} className="mt-2 text-xs text-[#53616B]">{config === null ? "Vérification de la disponibilité…" : error ? "Disponibilité non vérifiée. Réessayez plus tard ou utilisez la page Contact." : "WhatsApp indisponible : aucun numéro n’est configuré pour cette agence."}</p>}
                </div>
              );
            })}
          </div>
          <p role="status" className="sr-only">{config === null ? "Chargement des agences." : error ? "Impossible de vérifier les numéros WhatsApp." : "Disponibilité des agences chargée."}</p>
          <Dialog.Close asChild><button type="button" className="gsr-whatsapp-close" aria-label="Fermer le choix des agences"><X size={20} aria-hidden="true" /></button></Dialog.Close>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
}
