import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { crm, useAuth } from "@/crm/auth";
import { PageTitle, StatusBadge, TYPE_LABEL, fmt, Card, AGENCY_LABEL, inputCls } from "@/crm/CrmLayout";
import { apiError } from '@/lib/api';

export default function Dashboard() {
  const { user } = useAuth();
  const [d, setD] = useState(null);
  const [filters, setFilters] = useState({agency:'', start:'', end:''});
  const [error, setError] = useState('');
  useEffect(() => {
    const controller = new AbortController();
    crm.get('/crm/dashboard', {params:Object.fromEntries(Object.entries(filters).filter(([,v]) => v)), signal:controller.signal})
      .then(r => {setD(r.data);setError('');})
      .catch(e => {if(!controller.signal.aborted)setError(apiError(e));});
    return () => controller.abort();
  }, [filters]);
  if (!d) return <p className="text-[#53616B]">{error || 'Chargement…'}</p>;
  const kpis = [["Demandes", d.total, "crm-kpi-total"], ["Nouvelles", d.by_status.nouveau, "crm-kpi-nouveau"], ["RDV à 7 jours", d.rdv_week, "crm-kpi-rdv"], ["Relances dues", d.relances_due, "crm-kpi-relances"]];
  return (
    <div data-testid="crm-dashboard">
      <PageTitle label={`Bonjour ${user.name.split(" ")[0]}`} title={user.agency ? `Agence de ${AGENCY_LABEL[user.agency]}` : "Vue d'ensemble"} />
      {user.role !== 'editeur' && <div className="grid sm:grid-cols-3 gap-3 mb-5">
        {user.role === 'direction' && <label className="text-sm">Agence<select aria-label="Agence des indicateurs" className={`${inputCls} w-full mt-1`} value={filters.agency} onChange={e => setFilters({...filters,agency:e.target.value})}><option value="">Toutes les agences</option><option value="creteil">Créteil</option><option value="bonneuil">Bonneuil</option></select></label>}
        <label className="text-sm">Dossiers reçus du<input aria-label="Début de période" type="date" className={`${inputCls} w-full mt-1`} value={filters.start} onChange={e => setFilters({...filters,start:e.target.value})}/></label>
        <label className="text-sm">Au<input aria-label="Fin de période" type="date" className={`${inputCls} w-full mt-1`} value={filters.end} onChange={e => setFilters({...filters,end:e.target.value})}/></label>
      </div>}
      {error && <p role="alert" className="mb-4 text-red-700">{error}</p>}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {kpis.map(([l, v, t], i) => (
          <div key={l} data-testid={t} className={`p-5 lg:p-6 ${i === 1 ? "bg-[#F29A58]" : i === 3 && v > 0 ? "bg-[#25333D] text-white" : "bg-white"}`}>
            <p className="text-[11px] uppercase tracking-widest opacity-70">{l}</p><p className="mt-2 font-clash text-4xl lg:text-5xl font-semibold">{v}</p>
          </div>
        ))}
      </div>
      <div className="grid md:grid-cols-3 gap-4 mt-4"><Card><h2>Conversions réelles</h2><p>{d.conversions?.verified||0} · {d.conversions?.rate||0}%</p><p className="text-xs">Inscriptions explicitement confirmées / dossiers actifs.</p></Card><Card><h2>Rendez-vous honorés</h2><p>{d.appointments?.honored||0} · {d.appointments?.rate??"—"}%</p><p className="text-xs">Parmi les résultats honorés ou absents renseignés.</p></Card><Card><h2>Délai moyen de réponse</h2><p>{d.response?.average_hours??"—"} h</p><p className="text-xs">Premier échange sortant effectué, {d.response?.count||0} dossiers.</p></Card></div><Card className="mt-4"><h2>Sources</h2><ul>{Object.entries(d.sources||{}).map(([s,n])=><li key={s}>{s} : {n}</li>)}</ul></Card>{!!d.alerts?.length&&<Card className="mt-4"><h2>Rappels non traités après 24 heures</h2><ul>{d.alerts.map(a=><li key={a.id}><Link to={`/crm/prospects/${a.demande_id}`} className="underline">{a.reference} · {a.name}</Link></li>)}</ul></Card>}
      <div className="mt-6 grid lg:grid-cols-12 gap-4">
        <Card className="lg:col-span-7" testId="crm-recent">
          <div className="flex justify-between items-center"><h2 className="font-clash text-xl font-semibold">Dernières demandes</h2><Link to="/crm/prospects" className="text-sm font-semibold hover:text-[#F29A58]">Tout voir →</Link></div>
          <ul className="mt-4 divide-y divide-[#25333D]/10">
            {d.recent.map((r) => (
              <li key={r.id} className="py-3 flex items-center gap-4 min-w-0">
                <div className="flex-1 min-w-0"><Link to={`/crm/prospects/${r.id}`} className="font-semibold hover:text-[#F29A58]">{r.name}</Link><p className="text-xs text-[#53616B] truncate">{r.reference} · {TYPE_LABEL[r.type]} · {AGENCY_LABEL[r.agency]} · {fmt(r.created_at)}</p></div>
                <span className="shrink-0"><StatusBadge status={r.status} label={d.status_labels[r.status]} /></span>
              </li>
            ))}
          </ul>
        </Card>
        <div className="lg:col-span-5 space-y-4 min-w-0">
          <Card testId="crm-by-status"><h2 className="font-clash text-xl font-semibold">Par statut</h2>
            <ul className="mt-4 space-y-2">{Object.entries(d.by_status).map(([s, n]) => (
              <li key={s} className="grid grid-cols-[1fr_auto] gap-3 items-center text-sm"><div className="flex items-center gap-3 min-w-0"><span className="w-24 shrink-0 truncate">{d.status_labels[s]}</span><div className="flex-1 h-2 bg-[#F6F3EE] min-w-0"><div className="h-2 bg-[#25333D]" style={{ width: `${d.total ? (n / d.total) * 100 : 0}%` }} /></div></div><span className="font-semibold">{n}</span></li>
            ))}</ul>
          </Card>
          <Card testId="crm-by-type"><h2 className="font-clash text-xl font-semibold">Par motif</h2>
            <ul className="mt-4 flex flex-wrap gap-2">{Object.entries(d.by_type).map(([t, n]) => <li key={t} className="border border-[#25333D]/15 px-3 py-1.5 text-sm">{TYPE_LABEL[t] || t} <b>{n}</b></li>)}</ul>
          </Card>
        </div>
      </div>
    </div>
  );
}
