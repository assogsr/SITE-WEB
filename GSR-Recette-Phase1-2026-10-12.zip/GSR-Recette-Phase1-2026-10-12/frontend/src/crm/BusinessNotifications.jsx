import {useCallback,useEffect,useState} from 'react';
import {Link} from 'react-router-dom';
import {crm} from '@/crm/auth';
import {Card,PageTitle,fmt} from '@/crm/CrmLayout';
import {apiError} from '@/lib/api';
const LABELS={demande_recue:'Nouvelle demande',affectation:'Dossier affecté',intervention_j1:'Intervention sans première réponse après J+1'};
export default function BusinessNotifications(){const [rows,setRows]=useState([]),[error,setError]=useState('');const load=useCallback(()=>crm.get('/crm/notifications').then(r=>setRows(r.data)).catch(e=>setError(apiError(e))),[]);useEffect(()=>{load();},[load]);return <div><PageTitle label="Suivi interne" title="Notifications métier"/>{error&&<p role="alert">{error}</p>}<Card><ul className="divide-y">{rows.map(x=><li key={x.id} className="py-4"><p className={x.read?'':'font-semibold'}>{LABELS[x.kind]||x.kind} · {fmt(x.created_at)}</p><Link className="underline" to={`/crm/prospects/${x.demande_id}`}>{x.reference}</Link>{!x.read&&<button className="ml-4 underline" onClick={async()=>{try{await crm.post(`/crm/notifications/${x.id}/lue`);load();}catch(e){setError(apiError(e));}}}>Marquer comme lu</button>}</li>)}</ul>{!rows.length&&<p>Aucune notification.</p>}</Card></div>;}
