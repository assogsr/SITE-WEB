import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { apiError } from "@/lib/api";
import { AlertTriangle } from "lucide-react";
import { crm, useAuth } from "@/crm/auth";
import { PageTitle, StatusBadge, TYPE_LABEL, fmt, Card, inputCls, AGENCY_LABEL } from "@/crm/CrmLayout";

const defaults={q:'',status:'',type:'',agency:'',assigned_to:'',start:'',end:'',due:'',archived:false};

export default function Prospects() {
  const { user } = useAuth();
  const [rows, setRows] = useState(null);
  const [listError,setListError]=useState("");
  const [meta, setMeta] = useState({ statuses: {} });

  const labels={reference:'Référence',name:'Nom',type:'Motif',agency:'Agence',contact:'Contact',created_at:'Reçue le',status:'Statut',assigned_to:'Responsable',next_action:'Prochaine action'};
  const [f,setF]=useState(defaults),[columns,setColumns]=useState(Object.keys(labels).slice(0,7)),[sort,setSort]=useState('created_at'),[order,setOrder]=useState('desc'),[ready,setReady]=useState(false),[message,setMessage]=useState(''),[assignees,setAssignees]=useState([]);
  useEffect(()=>{let alive=true;crm.get('/crm/preferences/prospects').then(r=>{if(alive){setF({...defaults,...r.data.filters});setColumns(r.data.columns);setSort(r.data.sort);setOrder(r.data.order);}}).catch(()=>{if(alive)setMessage('Préférences non chargées ; configuration par défaut.');}).finally(()=>{if(alive)setReady(true);});crm.get('/crm/assignees').then(r=>{if(alive)setAssignees(r.data);}).catch(()=>{});return()=>{alive=false;};},[user.id]);
  const save=async()=>{try{await crm.put('/crm/preferences/prospects',{filters:f,columns,sort,order});setMessage('Préférences enregistrées pour votre compte.');}catch{setMessage('Enregistrement impossible.');}};
  useEffect(() => { crm.get("/crm/meta").then((r) => setMeta(r.data)); }, []);
  useEffect(() => {
    if(!ready)return;
    const t = setTimeout(() => crm.get("/crm/demandes", { params: Object.fromEntries(Object.entries({...f,sort,order}).filter(([, v]) => v)) }).then((r) => {setRows(r.data);setListError("");}).catch(e=>setListError(apiError(e))), 250);
    return () => clearTimeout(t);
  }, [f,sort,order,ready]);
  return (
    <div data-testid="crm-prospects">
      <PageTitle label="Prospects" title="Demandes & dossiers">
        <Link to="/crm/prospects/nouveau" className="bg-[#25333D] text-white px-4 py-2 text-sm">Créer un prospect</Link><span className="text-sm text-[#53616B]">{rows ? `${rows.length} dossier${rows.length > 1 ? "s" : ""}` : ""}</span>
      </PageTitle>
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3 mb-5">
        <input data-testid="prospects-search" placeholder="Nom, référence, e-mail, téléphone…" value={f.q} onChange={(e) => setF({ ...f, q: e.target.value })} className={inputCls} />
        <select data-testid="prospects-status-filter" value={f.status} onChange={(e) => setF({ ...f, status: e.target.value })} className={inputCls}><option value="">Tous les statuts</option>{Object.entries(meta.statuses).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select>
        <select data-testid="prospects-type-filter" value={f.type} onChange={(e) => setF({ ...f, type: e.target.value })} className={inputCls}><option value="">Tous les motifs</option>{Object.entries(TYPE_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select>
        {["direction", "responsable", "accueil"].includes(user.role) && <select data-testid="prospects-agency-filter" value={f.agency} onChange={(e) => setF({ ...f, agency: e.target.value })} className={inputCls}><option value="">Toutes les agences</option><option value="creteil">Créteil</option><option value="bonneuil">Bonneuil</option></select>}
      </div>
      <details className="mb-4 text-sm"><summary>Personnaliser la liste et enregistrer mes filtres</summary>
        <div className="flex flex-wrap gap-3 my-3">{Object.entries(labels).map(([key,label])=><label key={key}><input type="checkbox" checked={columns.includes(key)} disabled={columns.length===1&&columns.includes(key)} onChange={e=>setColumns(e.target.checked?[...columns,key]:columns.filter(c=>c!==key))}/>{label}</label>)}</div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3"><label>Tri<select aria-label="Trier les prospects" className={inputCls} value={sort} onChange={e=>setSort(e.target.value)}>{['created_at','name','reference','agency','status','next_action_due'].map(k=><option key={k} value={k}>{labels[k]||'Échéance'}</option>)}</select></label><label>Ordre<select className={inputCls} value={order} onChange={e=>setOrder(e.target.value)}><option value="asc">Croissant</option><option value="desc">Décroissant</option></select></label><label>Responsable<select className={inputCls} value={f.assigned_to} onChange={e=>setF({...f,assigned_to:e.target.value})}><option value="">Tous</option>{assignees.map(a=><option key={a.id} value={a.id}>{a.name}</option>)}</select></label>{[['start','Reçus du'],['end','Au'],['due','Prochaine action avant le']].map(([key,label])=><label key={key}>{label}<input type="date" className={inputCls} value={f[key]} onChange={e=>setF({...f,[key]:e.target.value})}/></label>)}{user.role==='direction'&&<label><input type="checkbox" checked={f.archived} onChange={e=>setF({...f,archived:e.target.checked})}/>Dossiers archivés uniquement</label>}</div>
        <button className="mt-3 px-4 py-2 bg-[#25333D] text-white" onClick={save}>Enregistrer mes préférences</button><button className="ml-3 underline" onClick={()=>setF(defaults)}>Réinitialiser les filtres</button><p role="status">{message}</p>
      </details>
      {listError&&<p role="alert" className="text-red-800 mb-3">{listError}</p>}
      <Card className="p-0 overflow-x-auto">
        <table className="w-full text-sm min-w-[760px]">
          <thead className="text-left text-[11px] uppercase tracking-widest text-[#53616B] border-b border-[#25333D]/10"><tr>{columns.map(c=><th key={c} className="px-4 py-3 font-medium">{labels[c]}</th>)}{!columns.includes("name")&&!columns.includes("reference")&&<th>Dossier</th>}</tr></thead>
          <tbody className="divide-y divide-[#25333D]/5">{rows?.map(r=><tr key={r.id} data-testid={`prospect-row-${r.reference}`} className="hover:bg-[#FFF4EA] transition-colors">{columns.map(c=><td key={c} className="px-4 py-3">{c==='name'||c==='reference'?<Link to={`/crm/prospects/${r.id}`} className="hover:text-[#F29A58] font-semibold">{r[c]}{c==='name'&&r.duplicates_count>0&&<AlertTriangle data-testid="duplicate-flag" size={14} className="inline ml-2 text-[#F29A58]" title="Doublon potentiel"/>}</Link>:c==='status'?<StatusBadge status={r.status} label={r.status_label}/>:c==='type'?TYPE_LABEL[r.type]:c==='agency'?AGENCY_LABEL[r.agency]:c==='contact'?r.phone||r.email:c==='created_at'?fmt(r.created_at):c==='assigned_to'?assignees.find(a=>a.id===r.assigned_to)?.name||'Non renseigné':r.next_action||'—'}</td>)}{!columns.includes('name')&&!columns.includes('reference')&&<td className="px-4 py-3"><Link to={`/crm/prospects/${r.id}`} className="underline">Ouvrir le dossier</Link></td>}</tr>)}{rows&&rows.length===0&&<tr><td colSpan={columns.length} className="px-4 py-10 text-center text-[#53616B]">Aucun dossier.</td></tr>}</tbody>
        </table>
      </Card>
    </div>
  );
}
