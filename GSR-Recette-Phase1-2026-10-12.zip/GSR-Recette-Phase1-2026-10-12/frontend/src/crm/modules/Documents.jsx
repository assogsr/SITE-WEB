import { useEffect, useState } from 'react';
import { crm, useAuth } from '@/crm/auth';
import { apiError } from '@/lib/api';
import { Card, PageTitle, AGENCY_LABEL } from '@/crm/CrmLayout';

const cls = 'border border-[#25333D]/15 rounded-lg px-3 py-2 w-full bg-white';
const button = 'px-4 py-2 rounded-lg bg-[#F29A58] text-[#25333D] font-semibold disabled:opacity-50';
const fileBody = (file) => new Promise((resolve, reject) => {
  if (!file || file.size > 8 * 1024 * 1024) return reject(new Error('Choisissez un fichier de 8 Mio maximum.'));
  const reader = new FileReader();
  reader.onerror = () => reject(new Error('Lecture du fichier impossible.'));
  reader.onload = () => resolve({ filename: file.name, mime: file.type || ({pdf:'application/pdf',png:'image/png',jpg:'image/jpeg',jpeg:'image/jpeg',docx:'application/vnd.openxmlformats-officedocument.wordprocessingml.document'}[file.name.split('.').pop().toLowerCase()] || ''), content_base64: String(reader.result).split(',')[1] });
  reader.readAsDataURL(file);
});
const saveBlob = (response, filename) => {
  const url = URL.createObjectURL(new Blob([response.data]));
  const a = document.createElement('a'); a.href = url; a.download = filename; a.click(); URL.revokeObjectURL(url);
};

export default function Documents() {
  const { user } = useAuth();
  const [rows, setRows] = useState([]), [selected, setSelected] = useState(null), [error, setError] = useState(''), [busy, setBusy] = useState(false), [links, setLinks] = useState([]), [share, setShare] = useState('');
  const [form, setForm] = useState({ title: '', category: '', agency: user.agency || 'creteil', sensitivity: 'confidentiel', retention_until: '', formation_id: '' });
  const [assignees, setAssignees] = useState([]), [deleteConfirmation, setDeleteConfirmation] = useState('');
  const [courses, setCourses] = useState([]);
  const [categories, setCategories] = useState([]), [catName, setCatName] = useState(''), [catDays, setCatDays] = useState(''), [roles, setRoles] = useState([]);
  const [file, setFile] = useState(null), [versionFile, setVersionFile] = useState(null), [note, setNote] = useState(''), [permissionIds, setPermissionIds] = useState([]);
  const direction = user.role === 'direction';
  const load = async () => { const r = await crm.get('/crm/documents'); setRows(r.data); const c = await crm.get('/crm/documents/configuration/categories'); setCategories(c.data.categories); try { setCourses((await crm.get('/crm/formations/catalogue')).data); } catch { setCourses([]); } };
  useEffect(() => { load().catch(() => setError('Chargement impossible.')); }, []);
  const action = async (fn) => { setBusy(true); setError(''); try { await fn(); await load(); } catch (e) { setError(apiError(e, e.message || 'Opération impossible.')); } finally { setBusy(false); } };
  const open = async (id) => { const r = await crm.get(`/crm/documents/${id}`); setSelected(r.data); setPermissionIds(r.data.permitted_users); setDeleteConfirmation(''); if (direction) { const a = await crm.get('/crm/assignees', { params: { agency: r.data.agency } }); setAssignees(a.data.filter(x => x.role === 'direction' || x.agency === r.data.agency)); } setRoles(r.data.permitted_roles || []); setShare(''); if (direction) setLinks((await crm.get(`/crm/documents/${id}/links`)).data); };
  const create = (e) => { e.preventDefault(); action(async () => { const r = await crm.post('/crm/documents', { ...form, retention_until: form.retention_until || null, formation_id: form.formation_id || null, ...await fileBody(file) }); await open(r.data.id); }); };
  return <div data-testid="crm-documents">
    <PageTitle label="Documents privés" title="Gestion documentaire" />
    {error && <p role="alert" className="mb-4 text-red-700">{error}</p>}
    <p className="text-sm text-[#53616B] mb-4">Fichiers privés à l’agence. Chaque version reste en quarantaine jusqu’à une analyse antivirus saine et récente et un contrôle humain par la Direction. Un moteur indisponible ou des signatures périmées bloquent le téléchargement.</p>
    <div className="grid xl:grid-cols-2 gap-6">
      <Card><h2 className="font-semibold mb-4">Déposer un document</h2><form onSubmit={create} className="space-y-3">
        <label className="block">Titre<input required minLength={2} className={cls} value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} /></label>
        <label className="block">Catégorie<input list="document-categories" required minLength={2} className={cls} value={form.category} onChange={e => setForm({ ...form, category: e.target.value })} /></label>
        <label className="block">Agence<select className={cls} disabled={!direction} value={form.agency} onChange={e => setForm({ ...form, agency: e.target.value })}>{Object.entries(AGENCY_LABEL).map(([id, label]) => <option key={id} value={id}>{label}</option>)}</select></label>
        <label className="block">Support de formation (facultatif)<select className={cls} value={form.formation_id} onChange={e => setForm({ ...form, formation_id: e.target.value })}><option value="">Aucune formation</option>{courses.map(c => <option key={c.id} value={c.id}>{c.title}</option>)}</select></label>
        <label className="block">Sensibilité<select className={cls} value={form.sensitivity} onChange={e => setForm({ ...form, sensitivity: e.target.value })}><option value="confidentiel">Confidentiel — aucun lien externe</option><option value="interne">Interne — partage temporaire autorisable par la Direction</option></select></label>
        <label className="block">Date de rétention validée par GSR (facultative)<input type="date" className={cls} value={form.retention_until} onChange={e => setForm({ ...form, retention_until: e.target.value })} /></label>
        <label className="block">Fichier PDF, Word .docx, PNG ou JPEG (8 Mio)<input required type="file" accept=".pdf,.docx,.png,.jpg,.jpeg" className={cls} onChange={e => setFile(e.target.files[0])} /></label>
        <button disabled={busy} className={button}>Déposer</button>
      <datalist id="document-categories">{categories.map(c => <option key={c.name} value={c.name} />)}</datalist></form></Card>
      <Card><h2 className="font-semibold mb-4">Documents accessibles</h2><ul className="divide-y">{rows.map(d => <li key={d.id} className="py-3"><button className="text-left hover:text-[#F29A58]" onClick={() => action(() => open(d.id))}>{d.title} · {AGENCY_LABEL[d.agency]}<span className="block text-xs text-[#53616B]">{d.category} · {d.versions.length} version(s) · {d.sensitivity}</span></button></li>)}</ul>{!rows.length && <p>Aucun document.</p>}</Card>
    </div>
    {direction && <Card className="mt-6"><h2 className="font-semibold mb-3">Catégories et rétention</h2><p className="text-sm mb-3">Durées à compléter par la Direction. Une durée vide ne déclenche aucune suppression automatique.</p>{categories.map(c => <p key={c.name}>{c.name} · {c.retention_days ? c.retention_days + ' jours' : 'Durée non définie'} <button className="underline" onClick={() => action(async () => { await crm.put('/crm/documents/configuration/categories', { categories: categories.filter(x => x.name !== c.name) }); })}>Retirer</button></p>)}<div className="grid sm:grid-cols-2 gap-3 my-3"><label>Nom de catégorie<input className={cls} value={catName} onChange={e => setCatName(e.target.value)} /></label><label>Durée en jours (facultative)<input className={cls} type="number" min="1" max="36500" value={catDays} onChange={e => setCatDays(e.target.value)} /></label></div><button className={button} disabled={busy || catName.length < 2} onClick={() => action(async () => { await crm.put('/crm/documents/configuration/categories', { categories: [...categories.filter(c => c.name !== catName.trim()), { name: catName.trim(), retention_days: catDays ? Number(catDays) : null }] }); setCatName(''); setCatDays(''); })}>Enregistrer la catégorie</button></Card>}
    {selected && <Card className="mt-6"><h2 className="font-semibold text-xl">{selected.title}</h2>
      <ul className="divide-y my-4">{selected.versions.map(v => <li key={v.id} className="py-3 space-y-2"><p>{v.filename} · {v.author_name} · {new Date(v.created_at).toLocaleString('fr-FR')} · {v.review_status} · Antivirus : {{clean:'Sain', infected:'Détection — bloqué', unavailable:'Indisponible — quarantaine', pending:'En attente'}[v.antivirus?.status] || 'Non analysé — quarantaine'}</p>{v.antivirus?.engine && <p className="text-xs">{v.antivirus.engine} · Signatures {v.antivirus.signature_version} · Analyse {new Date(v.antivirus.scanned_at).toLocaleString('fr-FR')}</p>}<p className="text-sm">{v.comment}</p>
        <button disabled={busy || v.review_status !== 'valide' || v.antivirus?.status !== 'clean'} className={button} onClick={() => action(async () => saveBlob(await crm.get(`/crm/documents/${selected.id}/versions/${v.id}/download`, { responseType: 'blob' }), v.filename))}>Télécharger cette version</button>
        {direction && <div className="flex flex-wrap gap-2"><button disabled={busy} className={button} onClick={() => action(async () => { await crm.post(`/crm/documents/${selected.id}/versions/${v.id}/scan`); await open(selected.id); })}>Analyser avec l’antivirus</button><button disabled={busy || note.length < 2} className={button} onClick={() => action(async () => { await crm.post(`/crm/documents/${selected.id}/versions/${v.id}/review`, { decision: 'valide', note }); await open(selected.id); })}>Valider le contrôle humain</button><button disabled={busy || note.length < 2} className={button} onClick={() => action(async () => { await crm.post(`/crm/documents/${selected.id}/versions/${v.id}/review`, { decision: 'rejete', note }); await open(selected.id); })}>Rejeter</button></div>}
      </li>)}</ul>
      <label className="block mb-3">Commentaire / motif<input className={cls} value={note} onChange={e => setNote(e.target.value)} maxLength={1000} /></label>
      <label className="block">Nouvelle version<input type="file" className={cls} accept=".pdf,.docx,.png,.jpg,.jpeg" onChange={e => setVersionFile(e.target.files[0])} /></label>
      <button className={button + ' mt-2'} disabled={busy || !versionFile} onClick={() => action(async () => { await crm.post(`/crm/documents/${selected.id}/versions`, { ...await fileBody(versionFile), comment: note }); await open(selected.id); })}>Ajouter une version</button>
      {direction && <div className="space-y-3 mt-6"><h3 className="font-semibold">Permissions et partage</h3><p className="text-sm">Une liste vide autorise les rôles CRM de l’agence. Une liste nominative restreint cet accès ; la Direction conserve son contrôle.</p><label className="block">Utilisateurs autorisés (sélection multiple)<select multiple className={cls} value={permissionIds} onChange={e => setPermissionIds(Array.from(e.target.selectedOptions, x => x.value))}>{assignees.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}</select></label><button className="underline text-sm" onClick={() => setPermissionIds([])}>Retirer la restriction nominative</button><fieldset className="flex gap-4"><legend>Restreindre aux rôles (aucun = rôles CRM de l’agence)</legend>{[['responsable', 'Responsable'], ['accueil', 'Accueil']].map(([id, label]) => <label key={id}><input type="checkbox" checked={roles.includes(id)} onChange={e => setRoles(e.target.checked ? [...roles, id] : roles.filter(x => x !== id))} /> {label}</label>)}</fieldset><button className={button} disabled={busy} onClick={() => action(async () => { await crm.patch(`/crm/documents/${selected.id}/permissions`, { permitted_roles: roles, permitted_users: permissionIds, sensitivity: selected.sensitivity }); await open(selected.id); })}>Enregistrer les permissions et révoquer les liens</button>
        <p className="text-sm">Un lien interne permet à toute personne possédant le lien de télécharger la version validée pendant 60 minutes. Ne partagez aucun document sensible.</p><button className={button} disabled={busy || selected.sensitivity !== 'interne' || note.length < 2} onClick={() => action(async () => { const r = await crm.post(`/crm/documents/${selected.id}/links`, { version_id: selected.current_version, minutes: 60, purpose: note }); setShare(window.location.origin + r.data.url); setLinks((await crm.get(`/crm/documents/${selected.id}/links`)).data); })}>Préparer un lien temporaire</button>
        {share && <label className="block">Lien affiché une seule fois<input readOnly className={cls} value={share} onFocus={e => e.target.select()} /></label>}
        {links.map(l => <p key={l.id} className="text-sm">Expiration : {new Date(l.expires_at).toLocaleString('fr-FR')} · {l.revoked ? 'Révoqué' : 'Actif'} {!l.revoked && <button className="underline" onClick={() => action(async () => { await crm.delete(`/crm/documents/${selected.id}/links/${l.id}`); await open(selected.id); })}>Révoquer</button>}</p>)}
        <label className="block">Confirmer le titre pour supprimer définitivement<input className={cls} value={deleteConfirmation} onChange={e => setDeleteConfirmation(e.target.value)} placeholder={selected.title} /></label><button className={button} disabled={busy || note.length < 2 || deleteConfirmation !== selected.title} onClick={() => { action(async () => { await crm.delete(`/crm/documents/${selected.id}`, { data: { confirmation: selected.id, reason: note } }); setSelected(null); }); }}>Supprimer définitivement</button>
      </div>}
    </Card>}
  </div>;
}

export function SharedDocument() {
  const [error, setError] = useState(''), [busy, setBusy] = useState(false);
  const [token] = useState(() => window.location.hash.slice(1));
  useEffect(() => { window.history.replaceState(null, '', window.location.pathname); }, []);
  const download = async () => { setBusy(true); setError(''); try { const response = await crm.post('/crm/documents/shared/download', { token }, { responseType: 'blob' }); saveBlob(response, 'document'); } catch { setError('Lien expiré, révoqué ou non autorisé.'); } finally { setBusy(false); } };
  return <main className="max-w-xl mx-auto p-8"><h1 className="text-2xl font-semibold mb-4">Document GSR partagé</h1><p className="mb-4">Ce lien temporaire ne donne accès qu’au document autorisé.</p><button className={button} disabled={busy || !token} onClick={download}>Télécharger le document</button>{error && <p role="alert" className="mt-4">{error}</p>}</main>;
}
