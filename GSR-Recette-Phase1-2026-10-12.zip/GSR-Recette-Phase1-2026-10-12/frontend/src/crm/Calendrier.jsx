import AgendaSettings from "@/crm/AgendaSettings";
import { useCallback, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { toast } from "sonner";
import { crm, useAuth, can } from "@/crm/auth";
import { PageTitle, TYPE_LABEL, fmtD, Card, inputCls, AGENCY_LABEL } from "@/crm/CrmLayout";
import { apiError } from "@/lib/api";

export default function Calendrier() {
  const { user } = useAuth();
  const [agency, setAgency] = useState(user.agency || "creteil");
  const [view,setView]=useState("all"),[selected,setSelected]=useState(new Date().toLocaleDateString("en-CA")),[kind,setKind]=useState("");
  const [slots, setSlots] = useState([]);
  const load = useCallback(() => crm.get("/crm/calendrier", { params: { agency } }).then((r) => setSlots(r.data)), [agency]);
  useEffect(() => { load(); }, [load]);
  const end=new Date(selected+"T12:00:00");end.setDate(end.getDate()+6);
  const until=end.toLocaleDateString("en-CA");
  const visible=slots.filter(s=>(!kind||(s.appointment_type||"information")===kind)&&(view==="all"||(s.date>=selected&&s.date<=(view==="day"?selected:until))));
  const days = [...new Set(visible.map((s) => s.date))];
  const update = async (s, body) => { try { await crm.patch(`/crm/calendrier/${s.id}`, body); toast.success("Créneau modifié"); load(); } catch (e) { toast.error(apiError(e)); } };
  const setCap = (s, cap) => update(s, { capacity: cap });
  return (
    <div data-testid="crm-calendrier">
      <PageTitle label="Calendrier" title={`Rendez-vous · ${AGENCY_LABEL[agency]}`}>
        {!user.agency && <select data-testid="calendar-agency-select" value={agency} onChange={(e) => setAgency(e.target.value)} className={inputCls}><option value="creteil">Créteil</option><option value="bonneuil">Bonneuil</option></select>}
      </PageTitle>
      <AgendaSettings agency={agency} onChange={load}/>
      <div className="flex flex-wrap gap-3 mb-4"><label>Vue<select aria-label="Vue du calendrier" className={inputCls} value={view} onChange={e=>setView(e.target.value)}><option value="all">Tous les créneaux</option><option value="day">Jour</option><option value="week">Semaine</option></select></label><label>Date<input aria-label="Date du calendrier" type="date" className={inputCls} value={selected} onChange={e=>setSelected(e.target.value)}/></label><label>Type<select aria-label="Type du calendrier" className={inputCls} value={kind} onChange={e=>setKind(e.target.value)}><option value="">Tous</option><option value="information">Information</option><option value="inscription">Inscription</option><option value="evaluation_initiale">Évaluation initiale</option></select></label></div>
      <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-4">
        {days.map((day) => (
          <Card key={day} testId={`calendar-day-${day}`}>
            <h2 className="font-clash text-lg font-semibold capitalize">{fmtD(day)}</h2>
            <ul className="mt-3 space-y-2">
              {visible.filter((s) => s.date === day).map((s) => (
                <li key={s.id} data-testid={`calendar-slot-${s.id}`} className={`p-3 text-sm ${s.booked ? "bg-[#FFF4EA]" : "bg-[#F6F3EE]"}`}>
                  <div className="flex items-center justify-between">
                    <span className="font-semibold">{s.time}{s.duration_minutes && <small className="block font-normal">{s.duration_minutes} min · {s.appointment_type}</small>}</span>
                    <span className="text-xs text-[#53616B]">{s.booked}/{s.capacity} {s.remaining === 0 && <b className="text-[#b4532a]">· complet</b>}</span>
                    {can(user, "direction", "responsable") && <div className="flex gap-1"><button data-testid="slot-cap-minus" onClick={() => setCap(s, Math.max(s.booked, s.capacity - 1))} className="w-6 h-6 border text-xs hover:bg-[#25333D] hover:text-white">−</button><button data-testid="slot-cap-plus" onClick={() => setCap(s, s.capacity + 1)} className="w-6 h-6 border text-xs hover:bg-[#25333D] hover:text-white">+</button></div>}
                  </div>
                  <label className="mt-2 flex gap-2 text-xs"><input type="checkbox" checked={!!s.closed} onChange={e => update(s, { closed: e.target.checked })} />Fermé aux nouvelles réservations</label>
                  {s.closed && s.booked > 0 && <p className="mt-2 text-xs text-[#b4532a]">Des rendez-vous sont déjà réservés : contactez les personnes concernées. Aucune annulation automatique.</p>}
                  {s.demandes.map((d) => <Link key={d.id} to={`/crm/prospects/${d.id}`} className="block mt-2 text-xs hover:text-[#F29A58]"><b>{d.name}</b> · {TYPE_LABEL[d.type]} · <span className="font-mono">{d.reference}</span></Link>)}
                </li>
              ))}
            </ul>
          </Card>
        ))}
      </div>
    </div>
  );
}
