# Bilan de conformité phase 1 — 11 octobre 2026

**Actualisation du lot de finalisation : les sept priorités demandées sont implémentées et préparées pour recette locale. La phase 1 globale reste sous réserves et ne constitue pas une livraison de production.** Les tests automatisés réussis prouvent les parcours couverts ; ils ne prouvent pas la réalisation de chaque exigence du cahier ni la validation fonctionnelle par GSR. Ce bilan complète et précise `RAPPORT_PHASE1_MODULES_GSR.md`, qui portait sur le lot des huit modules et les huit fonctionnalités CRM demandées.

Sources : `docs/references/Manifeste_GSR_V1_5.md` (annexe A prioritaire sur ses formulations historiques) et `Cahier_des_charges_GSR_V2.pdf`, notamment chapitres 2, 5–9 et addendum 45–48. Les anciennes mentions « aucun développement autorisé » sont le statut de conception des pièces ; les autorisations ultérieures de GSR dans cette conversation permettent le travail local, sans permettre la production. Aucun arbitrage métier validé n'est changé.

## Vérification des huit modules

**Livré** signifie présent dans le code et couvert par une recette technique locale. **Partiel** signifie que l'exigence ne peut pas être déclarée entièrement conforme. La recette humaine GSR reste à faire dans tous les cas.

| Module / exigences | Livré et preuves | Écarts, réserves ou compléments phase 1 |
|---|---|---|
| Documents — DOC-001 à 005 | Stockage Mongo privé, permissions serveur/rôle/utilisateur, formats contrôlés, versions, liens temporaires/révocables, suppression Direction avec références bloquantes ; `business_documents.py`, `Documents.jsx`, 16 tests API | ClamAV privé intégré avec quarantaine et blocage ; signatures actuelles non qualifiées dans cet environnement ; formats actuellement PDF/DOCX/PNG/JPEG, 8 Mio, à confirmer techniquement par GSR (O-11). Catégories/rétention configurables mais non renseignées ; pas de purge automatique. Politique de partage à valider. Sauvegarde indépendante non activée |
| Organismes — INT-001 et 006 | Fiche par agence, plusieurs contacts, coordonnées/type, échanges, pièces, prochaine action/échéance, historique ; liens stables depuis les interventions et candidatures ; 5 tests | Unicité dans l'agence, pas une fiche globale interagences. La Direction voit les deux agences ; aucun rapprochement global ne doit être supposé autorisé. La fiche ne présente pas encore les onglets/listes de demandes liés décrits dans la maquette E : les relations existent dans leurs modules |
| Solidarité — SOL-001 à 009 | Dispositifs configurables, prescripteur lié, critères humains, huit statuts, étapes/résultats/preuves, financeurs/conventions/périodes/objectifs, corrections auditées ; 20 tests | Paramètres réels à fournir ; socle d'indicateurs configurable mais aucune liste commune GSR validée. Formulaire public solidaire dédié livré, demande détaillée conservée atomiquement dans le CRM ; qualification humaine et création/rapprochement de candidature depuis le module, sans admission automatique. Aucun bilan consolidé automatique revendiqué |
| Formations — FORM-001 à 007 | Catalogue central permis/IA, personnes multi-inscriptions par agence, sessions/capacité/intervenant, attente, contrôle humain des prérequis/pièces, admission liée au CRM ; 7 tests | FORM-002 : unicité par agence seulement, à qualifier pour la notion de fiche unique globale ; migration IA non faite. FORM-006 : contrat versionné de données préparé pour présences/absences, preuves/émargements et évaluations initiales/finales, références et dates validées ; aucun écran ni endpoint pédagogique phase 2. Tarif/programme/modalités du catalogue public et gestion éditoriale complète restent des exigences distinctes |
| Intervenants — RH-001 à 003 | Coordonnées, compétences/domaines, justificatifs, validité globale du dossier, disponibilités connues, affectations/conflits de sessions, supports documentaires associés formation/rôle ; 15 tests | Unicité par agence ; aucun rapprochement global. `validity_date` est globale, sans registre détaillé de validité de chaque justificatif. Paramètres métier à fournir. Planning avancé exclu conformément à RH-P2-01 |
| Équipements — RES-001 et 002 | Salles/véhicules/simulateur/matériel, identifiants, agence/états, plages connues, immobilisation et événements de maintenance manuels, pièces ; 6 tests | Aucun moteur de réservation ou de maintenance automatisée demandé en phase 1. Référentiel réel à fournir. Les fermetures sont représentées par des indisponibilités, pas un calendrier avancé |
| Échéances — RES-003 et 004 | Catégorie/responsable/date/statut/pièce, alertes internes paramétrables, renouvellement humain sur pièce validée, historique et date suivante facultative ; 7 tests | Renouvellement Direction seulement en attendant une habilitation différente ; pas de date/périodicité inventée. Filtres de la maquette H non complets. Alertes réglementaires automatiques réservées à RES-P2-02 |
| Sécurité routière — INT-002 à 005 et 007 | Organisme/contact/prospect, public/effectif/action/lieu/dates, huit statuts, affectation, suivi, PDF externe approuvé par Direction pour sa version exacte ; 7 tests | Six pages dédiées et formulaires préremplis par action livrés (WEB-005), avec organisme/contact/public/effectif/lieu/dates/commentaire ; demande conservée au CRM puis qualifiée humainement avant rapprochement d’organisme et création du dossier métier. Aucun envoi réel ; devis calculés/bilans automatiques hors phase 1 |

## CRM : réalisé et écarts toujours en phase 1

Les huit fonctionnalités expressément demandées au lot CRM sont présentes : création/modification, réaffectation auditée, statuts, motif de non-inscription, relances J+1/J+3/J+7, alerte 24 h, archivage/suppression Direction et indicateurs. Neuf tests dédiés, plus tests de sécurité et intégration. L'accès transversal Accueil/Responsable reste limité aux prospects, selon la décision validée ; les modules/documents/calendriers/relances restent cloisonnés.

| Exigence | Évaluation précise |
|---|---|
| CRM-001/002 | Contact téléphone OU email, référence et formulaires dédiés intervention/solidarité/partenariat couverts, information confidentialité et protections communes ; aucune admission automatique |
| CRM-003/004 | Affectation/réaffectation et détection de doublons présentes. Aucune fusion automatique ; pas d'interface de fusion manuelle livrée |
| CRM-005 | Recherche des quatre clés et filtres agence/type/statut/responsable/période/échéance présents, validés côté serveur |
| CRM-006 | **Livré** : tri utilisateur, colonnes masquables, préférences et filtres privés persistés par utilisateur |
| CRM-007 | Informations, notes, historique, RDV et relances disponibles en cartes. Rattachement documentaire direct livré avec versions, auteur/dates, permissions privées, association/retrait audités et historique. Présentation en cartes conservée ; onglets/résumé permanent restent un complément de maquette phase 1 |
| CRM-008/009/010 | Chronologie des changements, contacts, motifs obligatoires et relances internes présentes ; mails journalisés dans l'administration dédiée, sans vue unifiée complète sur la fiche |
| CRM-011 | Conversions vérifiées, RDV honorés/absents saisis, sources, délai de première réponse, filtres agence/période et rappels 24 h présents. Liste priorisée unifiant tâches/urgence/échéance et ventilations détaillées par formation encore partielles |
| CRM-012 | CSV filtré ouvrable dans Excel, réservé Direction et audité. Aucun fichier XLSX natif revendiqué ; listes et exports bornés, recette de charge à grands volumes non faite |
| Archives | API/export et filtre de consultation des archives depuis la liste réservés Direction présents |

Ces écarts ne sont pas reportés en phase 2 par ce bilan. Les corriger reste un travail phase 1 ; toute exclusion demanderait une décision explicite GSR.

## Fonctions globales de phase 1 à ne pas confondre avec les huit modules

| Domaine | Livré | Réserves et manques phase 1 |
|---|---|---|
| Site/agences — WEB-001 à 004 | Pages actuelles, coordonnées, design et CTA conservés ; adresses/horaires de l'addendum V2 retenus | Offres/tarifs/financements/mentions et droits des photos à valider ; administration complète des pages/FAQ/offres/coordonnées non livrée, plusieurs contenus encore statiques/démonstration |
| Médias — WEB-007/008, manifeste §10 | Articles texte et workflow brouillon → Direction | Magazine avec filtres combinés année/mois/thème/format/agence/programme/recherche, vue chronologique, storyboards ordonnés, droits et sélection de trois contenus publiés livrés. Publication Direction bloquée sans droits documentés ; images limitées à leur version exacte validée et analysée. Vidéos/radio : lien vers source officielle, sans chargement tiers automatique |
| IA — IA-001 à 004 | Sous-espace direct séparé, aucune promotion principale, formulaires/sessions et validation humaine | Programmes/tarifs/financements/qualité officiels à vérifier ; architecture publique de démonstration ne vaut pas validation documentaire |
| Agenda — RDV-001 à 004 | Réservation atomique, capacité, fermeture, annulation/report par lien sécurisé, Europe/Paris | Vues jour/semaine, filtres types, règles de récurrence/durées/capacités/confirmation, fermetures et exceptions configurables livrés ; réservations sérialisées avec la configuration et rendez-vous existants conservés. Paramètres non fournis laissés vides ; aucune durée ou expiration métier inventée |
| Emails — MAIL-001 à 009 | Trois expéditeurs validés, SMTP séparés, modèles Direction, outbox/antidoublons, accusé/annulation/report/rappel 24 h préparés, journaux/échecs | Réels désactivés par décision. Notifications internes à l’affectataire et événement intervention J+1 idempotent livrés ; modèle J+1 administrable vide à valider Direction, annulation de l’événement avant envoi si réponse/clôture/archivage. Aucun envoi réel ; autres modèles métier à renseigner par GSR |
| Sécurité — ADM-001 à 005/009 | JWT expiration/révocation, limitation tentatives, permissions serveur, comptes Direction et audit ; protections des formulaires et cookie settings existants | Audit spécifique des refus de permission (notamment T16) non systématique ; qualification des signatures antivirus actuelles, conservation opérationnelle et revue RGPD/droits à finaliser. Tests techniques distincts d'une qualification réglementaire. Mot de passe seul conservé, aucun MFA imposé |
| Sauvegarde — ADM-006 | Dump chiffré quotidien local et restauration testée ; transport SFTP désormais préparé/testé en simulation | Copie réellement indépendante et récupération réelle du fournisseur non exécutées ; comptes/rétention/protection des versions nécessaires |
| Migration/hébergement — ADM-007/008/011 | Documentation et tests locaux ; aucun WordPress/LWS modifié | Inventaire réel, redirections 301, audit de compatibilité LWS, préproduction protégée, rollback et PV GSR non accomplis. React/FastAPI/Mongo ne démontre pas la compatibilité de la cible prioritaire Laravel/MySQL conditionnelle |
| Accessibilité/performance — WEB-010 | Tests mobile/clavier ciblés et absence d'erreur JS sur parcours vérifiés | Audit WCAG 2.2 AA exhaustif, performances/charge et mesures terrain non réalisés |

## Présences, évaluations et autres fonctions de phases 2/3

**Aucun report décidé par le développement n'a été identifié pour les présences et évaluations avancées.** Le cahier V2 les place déjà en phase 2 : chapitre 2, maquette G, FORM-006 (« Données futures prévues sans module avancé phase 1 »), FORM-P2-01 et FORM-P2-02. Le manifeste V1.5 ne précise pas ces opérations pédagogiques. Votre mission précédente les mentionnait tout en imposant les documents et la phase 1 ; la livraison a suivi ce découpage. Leur réalisation maintenant demanderait un changement de périmètre explicite ; ce bilan ne le décide pas.

| Fonction | Phase prescrite / référence | Ce qui reste exigé en phase 1 |
|---|---|---|
| Présences, absences, justificatifs, émargements | 2 — FORM-P2-01 | Contrat de données versionné livré (états, références, dates, pièces, émargement), sans opération pédagogique active |
| Évaluations initiales/finales, acquis/résultats | 2 — FORM-P2-02 | Schéma versionné livré avec critères/observations/preuves et validation humaine explicite, aucune certification automatique |
| Planning interventions, devis/conventions avancés, pièces d'intervention | 2 — INT-P2-01 à 03 | Demandes, statuts, pièces privées et devis PDF externe validé |
| Réservations, maintenance automatisée, planning intervenants | 2 — RES-P2-01/02, RH-P2-01 | Référentiels, disponibilités connues, maintenance manuelle et échéances |
| Suivi solidaire approfondi | 2 — SOL-P2-01 | Étapes/résultats/proofs et financeurs de base |
| Rapports Word/PDF, statistiques enrichies, bilans financeurs | 3 — INT-P3-01/02, SOL-P3-01 | Données sources, preuves et validation humaine |

Point à arbitrer : le manifeste annexe A prévoit les SMS transactionnels, mais le cahier V2 O-06 les qualifie de reportés/non bloquants phase 1. Ne pas modifier silencieusement ce choix : faire confirmer par GSR le traitement de cette divergence avant une clôture globale. Aucun SMS livré ni fournisseur engagé.

## Corrections techniques et preuves de cette revue

Les cinq avertissements ESLint ont été corrigés dans Calendrier, ProspectDetail, Relances, SessionsIA et RoadSafety par des fonctions de chargement `useCallback` et dépendances explicites, sans désactivation de règle ni changement de permissions/design. Compilation finale réussie **sans avertissement ESLint** ; restent des messages d'outil Node/Yarn, distincts de l'ESLint applicatif.

Antivirus : ClamAV privé intégré, test moteur réel EICAR réussi, libération applicative bloquée tant que les signatures restent anciennes ; voir `ANTIVIRUS_DOCUMENTS.md`. Copie extérieure : helper SFTP désactivé, tests simulés et procédure de restauration ; voir `SAUVEGARDE_HORS_SERVEUR.md`. Recette humaine : `RECETTE_FONCTIONNELLE_GSR.md`. Décisions et recommandations : `DECISIONS_GSR_RESTANTES.md`. Résultats actualisés : `RESULTATS_REVUE_CONFORMITE.md`.

## Conditions pour clôturer la phase 1

1. Corriger/retester les manques phase 1 identifiés, sans les déplacer implicitement en phase 2.
2. Fournir/valider les configurations et contenus officiels ; ne pas remplacer par des valeurs fictives.
3. Qualifier antivirus, sauvegarde indépendante/restauration et architecture cible avant utilisation réelle.
4. Exécuter et signer la recette GSR des cinq profils agence/rôle, retester les anomalies ; zéro anomalie critique et exigences essentielles satisfaites.

Les tests passés ne constituent donc **ni clôture de phase 1, ni autorisation de mise en production**. Les adresses email, la transversalité des seuls prospects, la liste vide de motifs à compléter, le départ de l'alerte rappel et l'interdiction de publication restent inchangés.

## Lot de finalisation actuel

Voir `RAPPORT_FINALISATION_PHASE1.md` pour les fichiers, contrôles du lot et la distinction entre intégration ClamAV et qualification opérationnelle des signatures. Les chiffres des rapports précédents sont historiques ; seuls les résultats identifiés comme finaux dans ce nouveau rapport correspondent au code actuel. Les autres compléments de maquette et d’administration générale cités ci-dessus restent explicitement phase 1, jamais reportés en phase 2.
