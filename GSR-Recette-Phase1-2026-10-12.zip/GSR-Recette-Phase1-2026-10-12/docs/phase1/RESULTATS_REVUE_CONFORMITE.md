# Vérifications de la revue de conformité — 11 octobre 2026

Les résultats ci-dessous concernent le code après correction des cinq avertissements ESLint. Ils complètent la recette technique antérieure à 321 tests et ne constituent pas la recette humaine finale ni une certification de conformité du cahier.

## Backend et transport préparé

**328 tests backend réussis, aucun échec**, en 131,73 s, bases locales fictives et MongoDB replica set. Ce total comprend les 321 tests précédents et **7 nouveaux tests du transport de sauvegarde extérieure simulé**. Treize avertissements de dépréciation pytest restent ouverts.

Commande : `/workspace/gsr-tools/venv/bin/python -m pytest backend/tests -q -n 2 --dist loadscope --junitxml=/workspace/gsr-conformite/phase1/revue/backend.xml`.

La relance initiale a exposé une fixture TestClient réutilisant une connexion Motor sur une boucle fermée, et un chemin d'import dépendant du répertoire de lancement. La suite CRM utilise désormais l'API locale du runner comme les tests d'intégration ; le test de transport résout son import indépendamment du répertoire. Aucune assertion métier supprimée. Le résultat retenu est celui de la relance complète réussie.

## Frontend

Compilation complète réussie en 27,74 s : **zéro avertissement ESLint**, sans désactivation de règle. Les avertissements Node de dépréciation et Yarn de cache non accessible sont distincts ; le cache de repli a fonctionné. Copie compilée locale et image du site actualisées, aucun déploiement public.

Changements fonctionnellement équivalents : fonctions de chargement stabilisées par `useCallback`, dépendances explicites de `useEffect` dans Calendrier, ProspectDetail, Relances, SessionsIA et RoadSafety. Le contrôle navigateur de l'export attend désormais son affichage avant de vérifier sa présence ; aucune vérification retirée.

## Recettes navigateur relancées

- Huit modules + CRM : **99 contrôles réussis**, 1440/390 px, sans exception JavaScript.
- Site public et anciens parcours CRM/connexion : **60 contrôles réussis**, sans exception JavaScript.
- Expéditeurs et administration emails : **38 contrôles réussis**, comptes officiels conservés, SMTP réels/tests de connexion réels désactivés.
- WhatsApp : **64 contrôles réussis** (24 pages publiques aux deux largeurs, soit 48 parcours, et 16 cas complémentaires), sans exception JavaScript, aucun numéro réel écrit ni envoi externe.

**Total de la relance navigateur : 261 contrôles réussis, aucun échec ni exception JavaScript.**

Les accès externes sont bloqués ou simulés : les messages console `net::ERR_FAILED` de ressources externes volontairement bloquées sont conservés dans les logs, sans être présentés comme des exceptions JavaScript applicatives. Ces tests ne valident pas la disponibilité réelle de ces ressources externes ni leur conformité/licence.

## Chaîne de récupération et restauration

Une **véritable archive chiffrée** de la base fictive a été transférée par un adaptateur SFTP **simulé, sans réseau**, relue et comparée SHA-256, récupérée puis restaurée avec le vrai `backup.restore` : **28 collections, 787 enregistrements et 13 versions documentaires**. Données, octets privés et index identiques ; base source inchangée. Worker temporairement arrêté puis redémarré. Les refus de corruption/écrasement de restauration restent couverts par la recette précédente et les tests backend ; transport corrompu/écrasement local couverts par les nouveaux tests.

Ce test valide l'interopérabilité de la préparation avec le format existant ; il **ne valide pas un fournisseur extérieur réel**. Choix du stockage, accès/empreinte SSH, rétention, snapshots protégés et récupération réelle sont encore requis.

## Artefacts

- `/workspace/gsr-conformite/phase1/frontend-conformite-build.log`
- `/workspace/gsr-conformite/phase1/revue/backend.log` et `backend.xml`
- `/workspace/gsr-conformite/phase1/revue/modules/browser.json`
- `/workspace/gsr-conformite/phase1/revue/general/browser-general.json`
- `/workspace/gsr-conformite/phase1/revue/emails/browser.json`
- `/workspace/gsr-conformite/phase1/revue/whatsapp/browser-results.json`
- `/workspace/gsr-conformite/phase1/revue/offsite-restore.log`

Antivirus : proposition uniquement, aucun scan ClamAV exécuté. Recette humaine : **155 fiches préparées et toutes « non exécuté »**, dans `PV_RECETTE_A_COMPLETER.csv`. Les exigences manquantes restent des scénarios bloqués, pas des succès automatisés. Aucune donnée réelle, modification WordPress/LWS, activation SMTP ou publication.
