# Sauvegarde chiffrée indépendante — préparation et restauration

## État et recommandation

La sauvegarde MongoDB chiffrée quotidienne et la restauration dans une base nouvelle ont été testées localement. Le transport hors serveur est maintenant préparé dans `backend/backup_offsite.py`, **désactivé par défaut**. Aucun compte distant, clé externe, connexion ou dépôt réel n'a été créé.

Recommandation : stockage chez un fournisseur indépendant de l'hébergement applicatif, avec localisation et contrat RGPD adaptés, compte SFTP dédié, snapshots protégés et restauration administrée séparément. Une simple copie sur un autre répertoire ou volume du même serveur ne répond pas à GSR-ADM-006. SFTP seul ne garantit pas l'immutabilité : exiger une protection des snapshots/versions que le compte d'envoi ne puisse ni supprimer ni modifier. Une alternative S3 avec verrouillage des objets est possible après choix du fournisseur, mais aucun connecteur S3 n'est livré ici.

Le transfert ne porte que sur l'enveloppe `.gsrbackup` déjà chiffrée AES-256/PBKDF2 et authentifiée HMAC par `backup.py`. La clé de déchiffrement reste séparée du stockage distant, dans le gestionnaire de secrets et une copie de secours accessible uniquement aux personnes GSR habilitées. Clé SSH de transport et clé de déchiffrement distinctes ; aucun secret en dépôt Git ou en conversation.

## Configuration à fournir dans le gestionnaire de secrets

| Variable | Usage |
|---|---|
| `GSR_OFFSITE_ENABLED` | Laisser `false` jusqu'à validation du fournisseur, des accès et de la recette |
| `GSR_OFFSITE_HOST`, `GSR_OFFSITE_PORT`, `GSR_OFFSITE_USER` | Compte extérieur dédié, aucun accès au CRM |
| `GSR_OFFSITE_DIRECTORY` | Répertoire absolu préparé sur le fournisseur |
| `GSR_OFFSITE_SSH_KEY_FILE` | Fichier de clé SSH privé, mode `0600`, monté hors source |
| `GSR_OFFSITE_KNOWN_HOSTS_FILE` | Empreinte serveur obtenue par canal de confiance, vérifiée indépendamment |
| `GSR_BACKUP_KEY_FILE` | Clé de déchiffrement de `backup.py`, conservée séparément |
| `MONGO_URL`, `DB_NAME` | Base source ou environnement de restauration contrôlé, hors source |

Prérequis : Python, OpenSSH `sftp`, outils MongoDB, OpenSSL ; le conteneur actuel ne garantit pas la présence de `sftp`. Préparer un exécuteur dédié après choix de l'hébergement. SSH en mode batch, validation stricte de l'empreinte ; aucun `StrictHostKeyChecking=no`. Le helper vérifie les permissions de clé, les noms/chemins et refuse les fichiers sans enveloppe chiffrée GSR.

## Job quotidien proposé, non activé

Dans un exécuteur isolé, avec configuration injectée par le gestionnaire de secrets :

```python
from backup import backup
from backup_offsite import upload
archive = backup()  # refuse un dump incohérent si la base écrit pendant la capture
upload(archive)     # put temporaire, relecture distante SHA-256, publication par renommage
```

Planifier une exécution quotidienne en Europe/Paris après validation technique ; surveiller séparément réussite du dump et réussite de la copie. Ne jamais annoncer « sauvegarde extérieure réussie » au seul succès du dump local. En cas d'échec, conserver le fichier local et retenter sans supprimer une copie antérieure ; une archive `.partial` n'est pas une sauvegarde validée. Aucune rétention/prune automatique livré : GSR doit valider les durées. Propositions à arbitrer : RPO 24 h et objectif de restauration à mesurer ; test mensuel de récupération extérieure et exercice périodique de perte du serveur principal.

## Procédure de restauration après récupération extérieure

1. Direction autorise l'exercice ; désigner l'opérateur et ouvrir un procès-verbal. Utiliser des données fictives/anonymisées tant que la recette réelle n'est pas autorisée.
2. Créer une machine de test séparée, sans emails réels, accès public ni automatisme d'envoi. Préparer MongoDB replica set et la configuration `DB_NAME` du dump d'origine pour le remappage des collections.
3. Récupérer une archive datée dans un nouveau fichier privé : `python backup_offsite.py download NOM.gsrbackup /chemin/prive/recu.gsrbackup`. Le fichier local existant ne sera pas écrasé. Conserver son empreinte et les preuves du job de copie.
4. Récupérer la clé de déchiffrement depuis le canal de secours indépendant, jamais depuis le fournisseur de fichiers ; mode `0600`. Ne pas imprimer la clé ou les variables secrètes.
5. `python backup.py restore /chemin/prive/recu.gsrbackup gsr_restore_test_IDENTIFIANT_UNIQUE`. Le helper vérifie format et HMAC AVANT restauration, exige une base nouvelle avec ce préfixe et refuse d'écraser la source ou une base existante. Aucun `--drop`.
6. Comparer collections, nombres de dossiers, métadonnées, octets/empreintes des versions privées et index au manifeste de la sauvegarde. Tester connexions/rôles/agences, CRM, inscriptions, documents et journaux ; SMTP réel toujours désactivé.
7. Mesurer durée et date de la dernière donnée restaurée ; noter anomalies et retest. Tester aussi clé manquante/incorrecte, archive corrompue et base cible existante : refus attendu.
8. Direction valide le PV et la procédure de secours. **Aucune bascule en production dans cette procédure** : récupération opérationnelle et remappage de production nécessitent une procédure séparée et son autorisation explicite.

## Preuves et limites

Sept tests du helper passent avec un transport SFTP **simulé**, sans réseau : aller/retour, empreinte, interdiction du texte clair, clé/empreinte obligatoires, corruption, chemins dangereux, refus d'écrasement. Cela ne prouve pas une copie chez un fournisseur réel ni une restauration depuis un fournisseur réel. La restauration chiffrée locale existante est une preuve séparée. La copie indépendante effective reste bloquée par le choix du fournisseur, ses accès, sa politique de rétention/protection et le test réel autorisé.
