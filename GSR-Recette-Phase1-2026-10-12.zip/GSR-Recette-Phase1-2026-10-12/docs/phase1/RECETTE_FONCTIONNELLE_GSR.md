# Recette fonctionnelle finale à exécuter par GSR

Version du 11 octobre 2026. **Plan préparé, non signé et non exécuté par les équipes GSR.** Les résultats techniques sont séparés dans `RESULTATS_FINALISATION_PHASE1.md`. Aucun scénario manuel n'est marqué réussi par anticipation. Certaines exigences manquantes sont signalées : leur scénario sera bloqué jusqu'à correction, et ne doit pas être supprimé pour obtenir un PV artificiellement positif.

## Profils, agences et préparation

Créer des comptes fictifs distincts dans l'environnement local de recette : **D** Direction ; **RC** Responsable Créteil ; **RB** Responsable Bonneuil ; **AC** Accueil Créteil ; **AB** Accueil Bonneuil. Comptes nominatifs de recette, sans partager ni afficher un mot de passe existant. Ajouter Éditeur **E** et anonyme **X** pour les contrôles négatifs. Ne pas modifier de compte réel pour le convertir en profil de test.

Jeu fictif minimal : un prospect/document privé/organisme/dispositif/apprenant/intervenant/ressource/échéance/intervention dans chaque agence ; une session fictive avec une place ; un prospect homonyme/contact identique pour doublon ; document PDF sain, nouvelle version, pièce rejetée et pièce confidentielle. Toutes les coordonnées de recette utilisent `example.com`, aucune personne/structure réelle. Les motifs/critères fictifs éventuellement nécessaires restent dans la base de recette isolée et ne deviennent jamais une configuration métier GSR.

Horodatage **Europe/Paris**, essais desktop et mobile, navigation clavier, zoom 200 %, messages d'erreur. SMTP réel/SMS désactivés ; WhatsApp et email interceptés/simulés. Figer un identifiant de version et sauvegarder avant l'exercice. Ne pas modifier WordPress/LWS ni les données réelles.

## Matrice de droits attendus

| Action | D | RC / AC | RB / AB |
|---|---|---|---|
| Consulter/modifier prospect Créteil ou Bonneuil | Oui | Oui, les deux agences | Oui, les deux agences |
| Pièces privées et huit modules Créteil | Vue globale, contrôle humain de pièce requis | Agence Créteil seulement, habilitation de pièce | Refus |
| Pièces privées et huit modules Bonneuil | Vue globale, contrôle humain de pièce requis | Refus | Agence Bonneuil seulement, habilitation de pièce |
| Calendrier, relances, alertes propres à l'agence | Les deux | Créteil | Bonneuil |
| Configuration sensible, catalogue, motifs, validation de pièce/devis/renouvellement | Direction | Refus | Refus |
| Archivage/suppression prospect, exports CRM | Direction avec confirmation | Refus | Refus |

Les restrictions documentaires nominatives/par rôle s'ajoutent aux agences pour Accueil/Responsable ; la Direction conserve sa vue globale. D ne peut pas associer une pièce d'une autre agence à un dossier. Le test d'accès se fait aussi en tentant l'URL directe et la requête API, pas seulement en observant le menu. Éditeur et anonyme refusés sur tous les dossiers privés.

## Scénarios par module

Appliquer **chaque scénario d'agence dans Créteil ET Bonneuil**, en alternant Responsable et Accueil ; D contrôle les deux puis valide les opérations sensibles. Pour chaque scénario autorisé, répéter la tentative depuis l'autre agence : refus attendu, sans mutation ni fuite du nom/contenu.

| ID | Profils | Étapes et résultat attendu | Situation avant recette GSR |
|---|---|---|---|
| C01 | RC/AC/RB/AB | Créer prospect téléphone seul puis email seul ; référence affichée, agence correcte, trois tâches internes | Livré, à exécuter |
| C02 | Tous | Refuser dossier sans contact ; rechercher par nom/téléphone/email/référence ; doublon signalé sans fusion automatique | Livré, à exécuter |
| C03 | Tous | Modifier prospect de l'autre agence, réaffecter avec historique ; aucune pièce privée transférée | Livré, à exécuter |
| C04 | Tous/D | Non-inscription sans motif/commentaire refusée ; liste initialement vide ; D configure motif de recette puis clôture valide | Livré, à exécuter |
| C05 | Agences | Tâches J+1/J+3/J+7 uniques ; terminer une tâche ; fermeture/archivage les annule ; pas d'email commercial | Livré, à exécuter |
| C06 | Agences | Rappel demandé dépassé de 24 h ; sinon création comme départ ; échange sortant effectué traite le rappel, note seule non | Livré, à exécuter |
| C07 | D et négatifs | Archive avec motif/référence exacte ; suppression bloquée par dépendance ; Accueil/Responsable refusés ; export Direction tracé | Livré, filtre archives Direction ; à exécuter |
| C08 | Tous | Préinscription ne crée pas conversion ; admission humaine oui ; révocation remet les indicateurs en cohérence ; RDV honoré saisi humainement | Livré, à exécuter |
| C09 | Tous | Filtres d'indicateurs agence/période, sources et délai réel ; aucun dossier privé hors périmètre | Livré, à exécuter |
| C10 | Tous | Masquer colonne, trier, enregistrer/recharger préférences après reconnexion | Livré, contrôlé techniquement ; recette humaine à exécuter |
| C11 | Tous | Fiche avec onglets/résumé permanent et rattachement documentaire direct autorisé | Documents directs livrés ; onglets/résumé permanent de maquette encore partiels |
| D01 | Agences/D | Déposer pièce, contrôle humain D, téléchargement autorisé ; autre agence/E/X refusés | Livré, à exécuter |
| D02 | D | Nouvelle version conservée, empreinte/historique ; rejet révoque diffusion ; permissions nominatives plus restrictives | Livré, à exécuter |
| D03 | D/X | Partage interne temporaire, expiration/révocation, jeton absent des journaux ; confidentiel non partageable | Livré, à exécuter |
| D04 | D | Suppression refusée si référence métier ; suppression pièce fictive non liée avec motif/confirmation | Livré, à exécuter |
| D05 | D | EICAR, panne moteur, signatures périmées : aucun téléchargement avant résultat sain puis validation humaine | Intégré, contrôlé techniquement ; qualification moteur avec signatures fraîches restant bloquée |
| O01 | Agences | Organisme, deux contacts, échanges/documents/échéance ; demande et prescripteur restent liés après changement de nom | Livré, à exécuter |
| O02 | Agences/D | Deux créations concurrentes même identité dans agence : un succès/un conflit ; agence distincte ne fusionne pas automatiquement | Livré, règle globale à qualifier |
| S01 | D puis agences | Configurer dispositif de recette, critères et pièces ; créer candidature liée, conserver prescripteur/date/source | Livré, configuration réelle attendue |
| S02 | Agences | Parcourir huit statuts ; admission humaine, refus/abandon motivés ; aucun formulaire ne vaut admission | Livré, à exécuter |
| S03 | Agences | Étapes datées, résultat sans preuve non vérifié ; ajouter pièce et confirmation humaine ; correction visible dans audit | Livré, à exécuter |
| S04 | X puis agences | Demande solidaire publique dédiée acheminée dans candidature avec origine conservée | Formulaire dédié livré → CRM ; qualification humaine vers candidature, à exécuter |
| F01 | D | Catalogue permis/IA et exigences séparées ; aucune offre/prix non validé publiée | Catalogue interne livré ; public à qualifier |
| F02 | Agences | Une personne, deux inscriptions dans l'agence ; changement contact sans doublon ; identité interagences non fusionnée | Livré localement ; unicité globale à qualifier |
| F03 | Agences | Session date/heure/lieu/intervenant/capacité ; conflit connu signalé ; capacité complète produit attente | Livré, à exécuter |
| F04 | Agences | Prérequis et pièce manquants bloquent confirmation ; admission humaine de la dernière place concurrente sans surcapacité | Livré, à exécuter |
| F05 | Agences/D | Présences/évaluations préparatoires identifiables dans contrat de données, sans écran phase 2 | Contrat versionné livré ; sans fonctionnalités actives phase 2 |
| I01 | Agences | Compétences/validité globale/justificatifs ; disponibilité puis session conflictuelle ; accès à support selon formation/rôle | Livré, à exécuter |
| I02 | Agences/D | Validité indépendante de chaque justificatif | **Partiel : validité globale seulement** |
| R01 | Agences | Créer salle/véhicule/simulateur/matériel ; indisponibilité/immobilisation visible ; maintenance manuelle et pièce | Livré, à exécuter |
| E01 | Agences | Échéance/responsable/pièce/délais configurés ; alertes et retard visibles seulement dans l'agence | Livré, à exécuter |
| E02 | D/négatifs | Renouvellement sans pièce validée/refus de rôle ; D clôture avec preuve et date suivante explicite ; répétition bloquée | Livré, à exécuter |
| E03 | Agences | Filtres catégorie/responsable/date/statut | **Partiel : filtres de maquette H** |
| P01 | Agences | Demande intervention complète liée organisme/contact ; huit statuts, responsable/prochaine action/échéance et pièces | Livré dans CRM, à exécuter |
| P02 | D/négatifs | Devis PDF non approuvé bloqué ; approbation liée à version ; remplacement de PDF invalide approbation | Livré, à exécuter |
| P03 | X puis agences | Cliquer l'une des six actions, formulaire conserve cette action et toutes coordonnées de structure/public/dates | Six pages/formulaires dédiés livrés ; à exécuter |

## Référentiel des 28 tests du cahier V2

| Tests V2 | Scénario / résultat requis |
|---|---|
| T01–03 | C01/02 ; accusé sur écran et email **simulé** seulement si contact email ; sans les deux refus |
| T04–06 | C02/03 ; doublon sans fusion, affectation Créteil, changement Bonneuil audité |
| T07–09 | Réserver libre, plein refusé, reporter libère ancien créneau ; notifications simulées, Europe/Paris et changement d'heure |
| T10–12 | C04–06, relance interne, clôture motivée et prospect transversal autorisé |
| T13–14 | E rédige/soumet ; publication par E refusée, D approuve ; aucun déploiement réel de la recette |
| T15 | Photo sans droits : publication bloquée ; contrôle dédié livré et testé ; validation des droits réels GSR attendue |
| T16 | C07 ; refus de suppression Accueil livré, absence de mutation ; **audit spécifique du refus non implémenté**, reste à compléter |
| T17–18 | SMTP fictif : journal/statut, échec puis renvoi contrôlé ; aucun compte Gmail réel sollicité |
| T19 | Ancienne URL vers nouvelle par 301 ; **bloqué sans inventaire/table de migration** |
| T20–21 | Pas de mention/lien IA sur principal ; URL IA directe accessible/indexable conformément au projet ; environnement de test protégé séparément |
| T22 | Restauration depuis copie extérieure, base neuve ; **preuve locale acquise, fournisseur réel à tester** |
| T23–25 | Rappel RDV simulé 24 h, confirmé/unique ; export non habilité refusé ; fichier privé sans authentification refusé hors lien explicitement autorisé |
| T26–28 | S02/F03/P02 ; admission humaine, attente capacité et devis approuvé |

Compléments globaux : horaires/fermetures par agence, règles de confirmation RDV, médiathèque/storyboard/filtres combinés, droits médias, SEO/canonical/sitemap et migration, cookies, clavier/lecteur d'écran/contrastes, charge, expiration/logout/révocation, sauvegarde corrompue/clés de secours, rollback. Les fonctions manquantes ne peuvent être certifiées par une simple navigation réussie.

## Fiche de résultat et signature

Consigner **pour chaque scénario et chacun des cinq profils** : ID/version/date Europe/Paris, rôle/agence, référence fictive, préconditions, étapes, attendu, observé, capture/log sans secrets, résultat (réussi/échoué/bloqué/non exécuté), gravité, correctif, retest, nom du validateur. Un scénario bloqué n'est pas un succès. Archiver le PV privé ; ne pas publier les captures CRM.

Critère de clôture : exigences phase 1 satisfaites, zéro anomalie critique, 100 % des scénarios critiques réussis, décisions/configurations et mesures de secours validées. Signature finale Direction ; validation agence RC/RB et retours AC/AB. Ce plan ne constitue aucune signature, aucune activation SMTP ni autorisation de mise en production.

## Scénarios complémentaires du lot de finalisation

Pour chacun des cinq profils (D/RC/RB/AC/AB), vérifier les préférences personnelles après reconnexion, l’accès documentaire direct autorisé et le refus des pièces de l’autre agence. Tester fermeture d’une période, exception d’ouverture, capacité inférieure aux réservations refusée, report sur date fermée refusé sans perte de la réservation initiale. Horaires récurrents et génération réservés Direction ; aucune réservation existante réécrite.

Direction/Éditeur/Agences : brouillon média privé, droits absents bloquant publication, séquences réordonnées, filtres combinés et chronologie, trois mises en avant maximum, remplacement d’image imposant nouvelle approbation, dépublication retirant la diffusion. Les vidéos restent des liens officiels sans chargement tiers automatique.

Public : chaque agence pour intervention (y compris action de la carte), solidarité et partenariat ; téléphone seul puis email seul, consentement de lecture absent/refus, référence affichée et suivi sans détails personnels ; aucune admission. Agents : qualifier et rapprocher humainement sans doublon automatique. Notifications : affectataire seul et Direction, lecture personnelle, intervention J+1 unique, dossier traité empêchant un envoi ultérieur. SMTP reste désactivé ; les contrôles d’envoi utilisent uniquement un transport fictif.

Antivirus : EICAR, scanner arrêté, timeout, signature ancienne, empreinte incohérente et nouvelle version bloquent téléchargement/partage/publication. Seul un verdict sain récent avec signatures actuelles, puis contrôle humain, autorise la restitution. Qualification réelle avec signatures fraîches à faire dans l’environnement retenu. Sauvegarde extérieure : configuration désactivée, aucun fournisseur fictivement choisi et aucun transfert ; procédure à tester sur futur service validé.

Les résultats automatisés ne remplissent pas le PV humain : conserver « non exécuté » jusqu’à l’essai réel du validateur GSR.
