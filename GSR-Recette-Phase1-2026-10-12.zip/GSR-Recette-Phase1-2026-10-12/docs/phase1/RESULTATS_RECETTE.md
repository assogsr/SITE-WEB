# Recette phase 1 — huit modules et CRM

> Revue post-livraison : voir `docs/phase1/BILAN_CONFORMITE_FINAL.md` et `docs/phase1/RESULTATS_REVUE_CONFORMITE.md` pour les écarts de phase 1, les avertissements ESLint corrigés et les résultats actualisés. Les chiffres ci-dessous conservent la trace du lot initial.

Recette finale locale du 11 octobre 2026, uniquement avec des données fictives. L'API utilise MongoDB en replica set pour les transactions ; les suites backend utilisent des bases de test isolées. Les navigateurs n'accèdent à aucun service externe : les navigations externes sont interceptées ou bloquées. Les résultats intermédiaires des agents sont remplacés par cette recette intégrée.

## Backend

Commande : `/workspace/gsr-tools/venv/bin/python -m pytest backend/tests -q -n 2 --dist loadscope --junitxml=/workspace/gsr-conformite/phase1/backend-complete.xml` depuis la racine du dépôt.

| Suite | Réussis |
|---|---:|
| Documents | 16 |
| Organismes | 5 |
| Solidarité | 20 |
| Formations | 7 |
| Intervenants | 15 |
| Équipements | 6 |
| Échéances | 7 |
| Sécurité routière | 7 |
| CRM phase 1 | 9 |
| Intégration croisée | 36 |
| Suites existantes : sécurité JWT/RBAC, formulaires, réservations, IA, emails, exports et WhatsApp | 193 |
| **Total** | **321** |

Aucun échec, 128,08 s, 13 avertissements de dépréciation pytest. Les conflits attendus (403/409/422) sont testés comme refus corrects, pas comptabilisés comme anomalies. Les tests vérifient aussi la concurrence réelle des créations, de la dernière place, du rattachement/suppression des pièces et de la réaffectation d'agence.

Artefacts : `/workspace/gsr-conformite/phase1/backend-complete.log` et `.xml`.

## Navigateur : huit modules et CRM

Commande : `GSR_PLAYWRIGHT_MODULE=/workspace/gsr-tools/node/node_modules/playwright GSR_OUTPUT_DIR=/workspace/gsr-conformite/phase1/browser node tests/phase1-browser.cjs`.

**99 vérifications réussies**, ordinateur 1440 px et mobile 390 px, aucune exception JavaScript : navigation des huit interfaces, absence de débordement horizontal, filtres agence/période des indicateurs, filtre d'export des archives, création prospect et trois relances, dépôt PDF même sans MIME fourni par le navigateur, contrôle humain, lien temporaire et téléchargement, organisme, intervenant, ressource, échéance et renouvellement avec pièce, dispositif/candidature, intervention, catalogue/apprenant/session/préinscription/admission humaine.

Artefacts : `/workspace/gsr-conformite/phase1/browser.log`, `browser/browser.json`, captures des huit interfaces aux deux largeurs. Les captures utilisent les données fictives de la recette et les composants du design existant.

## Compilation

Build final réussi en 23,40 s, copie `local-test/frontend/` actualisée et image locale du site reconstruite. Cinq avertissements ESLint non bloquants de dépendances de hooks : Calendrier, ProspectDetail, Relances, SessionsIA et RoadSafety. Aucune erreur de compilation. Artefact : `/workspace/gsr-conformite/phase1/frontend-final-build.log`.

## Sauvegarde et restauration réelles en environnement fictif

Sauvegarde chiffrée exécutée, restaurée dans une nouvelle base distincte : **28 collections, 568 enregistrements**, octets documentaires, données et index comparés à l'identique ; **8 versions documentaires privées** restaurées avec un contenu binaire non vide. Base source inchangée, archive corrompue rejetée, écrasement d'une base existante refusé, fichier mode `0600`. Le worker local a été arrêté temporairement pendant cette comparaison, puis redémarré. Aucun dossier existant supprimé.

Artefact : `/workspace/gsr-conformite/phase1/backup-restore.log`. Cette vérification locale ne remplace pas une copie de sauvegarde sur une destination indépendante, qui reste à configurer.

## Réserves

Aucune mesure de charge à grands volumes ni qualification de production. Antivirus documentaire, rétention, politique de partage, paramètres SMTP/modèles et configurations métier restent à valider. Les présences/évaluations avancées et fonctions explicitement placées dans les phases 2/3 ne sont pas développées.

## Non-régression finale

| Parcours | Vérifications réussies | Résultat |
|---|---:|---|
| Huit modules, filtres CRM et export des archives | 99 | Ordinateur/mobile, aucune exception JavaScript |
| Site public, anciennes pages CRM et connexions des quatre rôles | 60 | Ordinateur/mobile, aucun échec ni exception JavaScript |
| WhatsApp sur 24 pages publiques aux deux largeurs et cas complémentaires | 64 | 48 parcours de pages et 16 contrôles complémentaires ; aucune erreur ; aucun numéro réel configuré par la recette |
| Trois expéditeurs et administration emails | 38 | Adresses officielles conservées, SMTP vierges, tests/envois réels désactivés, aucun secret affiché |
| **Total navigateur** | **261** | **Aucun échec ni exception JavaScript** |

Artefacts supplémentaires : `/workspace/gsr-conformite/phase1/general/browser-general.json`, `whatsapp/browser-results.json`, `emails/browser.json` et leurs logs/captures. Les simulations WhatsApp remplacent les réponses dans le navigateur, sans écrire de numéro en base ni envoyer de message. Les anciens parcours de connexion réutilisent les boutons de démonstration sans reproduire de mot de passe dans les rapports.

La recette `tests/phase1-browser.cjs` refuse aussi une URL distante avant toute création de données ; ce garde-fou a été vérifié. `git diff --check` ne signale aucune erreur de formatage. Les services locaux ont été vérifiés en fonctionnement après la recette ; le worker interne a été rétabli. Aucune publication ni activation d'envoi réel.
