# Fichiers de la revue de conformité

Les changements préexistants des lots précédents sont conservés. Cette liste couvre la revue post-livraison, sans modification de données métier validées.

| Groupe | Fichiers |
|---|---|
| Correction ESLint | `frontend/src/crm/Calendrier.jsx`, `ProspectDetail.jsx`, `Relances.jsx`, `SessionsIA.jsx`, `modules/RoadSafety.jsx` |
| Préparation copie indépendante | `backend/backup_offsite.py` ; aucun job extérieur activé |
| Tests | `backend/tests/test_backup_offsite.py`, `backend/tests/test_crm_phase1.py` (fixture API locale), `tests/phase1-browser.cjs` (attente affichage export) |
| Configuration/recette compilée locale | `local-test/frontend/` : manifeste/index et bundle JavaScript renouvelés ; design/CSS conservés |
| Conformité/décisions | `docs/phase1/BILAN_CONFORMITE_FINAL.md`, `DECISIONS_GSR_RESTANTES.md` |
| Antivirus/sauvegarde | `docs/phase1/ANTIVIRUS_DOCUMENTS.md`, `SAUVEGARDE_HORS_SERVEUR.md` |
| Recette/PV | `docs/phase1/RECETTE_FONCTIONNELLE_GSR.md`, `PV_RECETTE_A_COMPLETER.csv`, `RESULTATS_REVUE_CONFORMITE.md` |
| Repères historiques | `RAPPORT_PHASE1_MODULES_GSR.md`, `docs/phase1/RESULTATS_RECETTE.md` : ajout du lien vers la revue actuelle, résultats initiaux conservés |

Aucun changement dans les décisions d'expéditeurs, SMTP désactivé, droits transversaux limités aux prospects, motifs initialement vides ou calcul de l'alerte rappel. Aucun secret ajouté au code, aucune publication ni modification WordPress/LWS.
