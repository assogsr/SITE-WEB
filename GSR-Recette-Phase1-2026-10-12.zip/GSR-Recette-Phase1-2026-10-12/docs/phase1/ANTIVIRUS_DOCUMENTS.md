# Antivirus privé ClamAV — documents privés

## Choix validé et intégration

**ClamAV**, avec `clamd` sur un service privé et `freshclam` pour les signatures, sans soumettre les documents à un service public d'analyse. Documentation officielle : https://docs.clamav.net/. Le stockage des justificatifs doit rester dans l'environnement maîtrisé par GSR ; ne pas utiliser VirusTotal ou un équivalent public pour des dossiers personnels.

La demande GSR de finalisation valide ClamAV privé. L’intégration et le moteur réel sont testés localement ; les documents anciens ne sont jamais déclarés sains sans analyse de leur version. La libération applicative reste bloquée dans cet environnement faute de signatures actuelles. Contrôles de formats et validation humaine sont conservés. Le choix d'hébergement reste dépendant de l'audit LWS : si Starter ne peut pas exécuter `clamd`, utiliser un service privé séparé avec transport chiffré et contrat de traitement, ou faire arbitrer l'hébergement. Ne rien installer sur le WordPress actuel.

## Principes de contrôle

1. Toute nouvelle version entre en quarantaine privée, permissions inchangées ; aucun lien de partage ni téléchargement tant que le scan n'est pas réussi.
2. Analyser les octets de cette version précise, après les contrôles MIME, signature et taille déjà existants. Limiter temps, mémoire et taille décompressée ; rejeter les archives chiffrées/non analysables.
3. Enregistrer SHA-256, date, moteur/version, version/date des signatures et résultat (`en_attente`, `sain`, `infecte`, `erreur`). Le résultat ne concerne que l'empreinte effectivement analysée.
4. `sain` permet seulement le contrôle humain Direction déjà requis : il ne remplace aucune décision métier ni habilitation. `infecte` interdit la diffusion ; `erreur`, moteur absent ou signatures trop anciennes interdisent également la diffusion.
5. Une nouvelle version repart en quarantaine ; les autorisations et liens doivent vérifier le résultat de leur version exacte. Scanner les anciennes versions avant tout premier téléchargement après activation.
6. Journaliser les résultats sans octets, secrets ni contenu sensible. Afficher une alerte interne si le moteur est indisponible ; définir une procédure de traitement par un responsable habilité, sans suppression automatique des preuves.

Un délai maximal proposé de 24 heures pour la fraîcheur des signatures et un plafond de 30 secondes par fichier sont des paramètres techniques à éprouver et à valider, pas des règles déjà approuvées. Le plafond actuel de dépôt reste 8 Mio ; aucune modification silencieuse.

## Recette préalable à l'activation

Fichiers fictifs PDF/DOCX/images sains ; fichier de test officiel EICAR ; archives imbriquées ; fichiers chiffrés ; signature moteur périmée ; panne et dépassement de temps ; remplacement de version pendant le scan ; tentatives téléchargement/lien temporaire avant scan ; refus interagence ; absence de données dans les logs. Vérifier que seule une version saine ET validée humainement est diffusée, même en concurrence.

Décisions nécessaires : moteur/prestataire, capacité et emplacement privé, responsabilité de mise à jour, SLA technique, traitement des détections, accès aux pièces en quarantaine. Une analyse antivirus réduit le risque sans garantir l'absence de tout contenu malveillant ; les autres contrôles doivent être conservés.

## Intégration privée de phase 1 — 11 octobre 2026

Le client `backend/document_antivirus.py` utilise le protocole ClamAV INSTREAM sur un socket UNIX protégé ou une adresse privée uniquement. Limite d'envoi : 8 Mio ; délai borné ; empreinte SHA-256 liée exactement à la version. Chaque téléversement et nouvelle version reçoit un verdict. Les versions anciennes sans preuve d'analyse restent bloquées. La Direction peut relancer l'analyse depuis Documents privés. Une validation humaine ne remplace jamais l'analyse antivirus.

Aucun téléchargement privé, lien temporaire ou image publiée dans la médiathèque ne restitue des octets sans une analyse saine et récente et un moteur actuellement disponible avec signatures fraîches. Infection, moteur arrêté, réponse invalide, empreinte modifiée ou signatures périmées entraînent la quarantaine ; les liens existants sont révoqués après un résultat suspect. Les fichiers en quarantaine restent dans le stockage documentaire privé, sans URL publique ; aucune règle de déplacement vers un service tiers.

Configuration reproductible : `config/phase1.env.example`. L'extension `local-test/compose.antivirus.yaml` ajoute un moteur privé, image officielle fixée par digest, sans port publié. Seul le moteur rejoint un réseau de mise à jour des définitions ; aucun fichier n'est envoyé à un antivirus extérieur. L'exploitant doit restreindre les sorties de ce réseau à la distribution officielle des signatures, prévoir la mémoire nécessaire et surveiller leur âge. Le réseau Docker seul ne constitue pas un filtrage de destinations.

Commande pour une **pile locale de données fictives**, après revue de la configuration :

```sh
docker compose -f local-test/compose.yaml -f local-test/compose.antivirus.yaml up -d --build backend clamav
```

Contrôle réel dans cet environnement : ClamAV 1.5.4 détecte EICAR et accepte un texte fictif sain. Les définitions disponibles datent du 27 septembre 2026, donc le client applicatif refuse de libérer les fichiers. Mise à jour Freshclam bloquée par résolution DNS ; téléchargement HTTPS officiel refusé (403). Aucun seuil de fraîcheur n'a été abaissé. Ce contrôle prouve le fonctionnement du moteur et du blocage, **pas la qualification d'une installation avec signatures actuelles**. Celle-ci reste une réserve technique avant activation.

Contrôles automatisés : moteur privé simulé au niveau du protocole pour cas sain, EICAR, panne, timeout, réponse incorrecte, signatures périmées, versions, téléchargement, partage et révocation. Le moteur simulé est exclusivement dans les fixtures de test, jamais dans le code applicatif ou la pile locale.
