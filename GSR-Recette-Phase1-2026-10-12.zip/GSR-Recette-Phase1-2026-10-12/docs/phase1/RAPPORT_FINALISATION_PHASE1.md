# Finalisation phase 1 — compte rendu du lot

Travail exclusivement local, sur données fictives. Aucun déploiement, transfert de sauvegarde extérieur ou envoi SMTP réel ; WordPress/LWS inchangés. Design, palette orange abricot et parcours existants conservés.

## Fonctionnalités du lot

| Priorité | Réalisation | Limite / validation restante |
|---|---|---|
| Préférences CRM | Colonnes masquables, tri ascendant/descendant, filtres responsable/période/échéance, préférences privées persistantes, archives Direction | Grandes listes bornées : qualification de charge et pagination à grands volumes non faite |
| Documents sur prospect | Association directe de pièces autorisées, commentaire privé, versions/auteurs/dates, téléchargement contrôlé, retrait et historique audités ; aucune extension des droits privés par accès transversal | Catégories/rétention et destinataires officiels à renseigner ; pièces réaffectées ne deviennent pas automatiquement accessibles à la nouvelle agence |
| Médiathèque | Presse/vidéo/photo/radio/événement/terrain/storyboard, métadonnées réelles, sources HTTPS, droits explicites, séquences ordonnées, brouillon/validation/publication Direction/archives, trois mises en avant, filtres combinés et chronologie | Aucun contenu réel inventé. Vidéos et radio par lien officiel ; aucun lecteur tiers chargé automatiquement. Image publique liée à la version exacte approuvée, saine, récente et interne autorisée |
| Formulaires dédiés | Intervention par action (six pages), solidarité et partenariat ; champs métier, agence, téléphone OU email, confidentialité, honeypot, quotas communs, contrôle origine/taille, référence minimale | Qualification humaine dans le CRM avant création/rapprochement d’organisme, candidature ou intervention ; aucun devis/admission automatique. Textes juridiques officiels à valider |
| Agenda | Vues jour/semaine, filtre type, fermetures, exceptions date/heure, capacités, horaires récurrents/durée/type/confirmation, génération future bornée et idempotente ; contrôle transactionnel réservation/report | Aucun horaire/durée/capacité métier ajouté sans configuration. Créneaux déjà existants et réservations conservés. Paramètres/éventuelle expiration d’attente à valider |
| Notifications métier | Réception interne, affectataire seul + Direction, lecture personnelle, alerte intervention J+1 idempotente ; événement email neutre personnalisable, suppression avant envoi si dossier traité | Modèle J+1 vide, à approuver Direction ; emails réels toujours désactivés. Les relances CRM J+1/J+3/J+7 et alerte rappel 24 h validées restent distinctes et inchangées |
| Schéma pédagogique | Contrat versionné strict : présences/absences/excusées, périodes, liens session/personne/inscription, justificatifs et émargement, critères/observations/preuves d’évaluations initiales/finales, validation humaine | Aucun écran ou API pédagogique phase 2 ; aucune migration ou réécriture des données existantes |
| Antivirus | Client ClamAV privé INSTREAM, analyse des versions, quarantaine et blocage des fichiers suspects/non analysés, rescan Direction, contrôle disponibilité/fraîcheur/empreinte avant restitution/partage/publication | Moteur réel testé, EICAR détecté. Signatures disponibles anciennes et mise à jour officielle bloquée dans l’environnement ; libération applicative refusée. Qualification avec signatures fraîches obligatoire |
| Sauvegardes extérieures | Exemple sans secret et sans fournisseur, désactivation par défaut, clé/empreinte SSH séparées, chiffrement et HMAC existants, procédure de récupération/restauration documentée | Aucun transfert réel ; fournisseur/emplacement, contrats, accès, rétention/RPO/RTO, gardiens de clé et recette extérieure à valider |

## Décisions conservées

- Trois expéditeurs : Créteil `creteil.gsr@gmail.com`, Bonneuil `accueil.gsr@gmail.com`, service/IA/partenariats `asso.gsr@gmail.com` ; Reply-To du service, SMTP distincts hors source, envois réels désactivés.
- Accueil/Responsable : transversalité des **prospects uniquement** ; documents, calendriers, modules et notifications restent limités à leurs habilitations/agence.
- Motifs de non-inscription : liste vide administrable Direction, aucune valeur fictive ajoutée.
- Alerte rappel après 24 h : heure demandée, sinon création du dossier.
- Présences/évaluations actives en phase 2 ; rapports automatiques enrichis en phase 3.

## Tests et preuves

| Exécution finale | Résultat |
|---|---|
| Backend complet, MongoDB replica set réel dédié, deux workers isolés | **358 tests réussis, aucun échec ni erreur** ; JUnit conservé |
| Huit modules existants, ordinateur/mobile | **99 contrôles réussis**, aucune exception JavaScript |
| Nouveaux parcours, ordinateur/mobile, cinq profils et deux agences | **113 contrôles réussis**, aucune exception JavaScript |
| Navigation générale publique/CRM | **60 contrôles réussis**, aucune exception JavaScript |
| Sécurité navigateur : sessions, révocation, expiration, prospects transversaux, documents/agendas privés | **11 contrôles réussis**, aucune exception JavaScript |
| WhatsApp, 30 routes publiques sur deux tailles, droits, clavier et absence de chevauchement | **60 passages de page + 16 contrôles complémentaires réussis** |
| Trois expéditeurs, SMTP séparés vierges, envois/tests réels bloqués, administration responsive | **38 contrôles réussis** |
| Total navigateur recensé par les six suites | **397 contrôles réussis** |
| Compilation finale frontend | Réussie, **aucun avertissement ESLint** ; messages Node/Yarn d’outillage distincts |
| Images Docker backend/site et démarrage de la pile locale fictive | Réussis, backend sain et API HTTP 200 |
| Configuration Compose antivirus privé | Validation réussie, aucun port publié dans cette extension |
| Moteur ClamAV réel | ClamAV 1.5.4 : texte fictif sain accepté, EICAR détecté ; signatures du 27 septembre 2026, client applicatif refuse la libération (`unavailable`) |

Les 11 avertissements backend concernent des dépréciations FastAPI/AnyIO/Pytest, pas des échecs ; leur modernisation reste une réserve d’entretien technique. La navigation générale bloque volontairement les images/ressources extérieures pendant la recette : messages de chargement attendus, aucune exception JavaScript. Les contrôles « zéro exception JavaScript » ne prétendent pas que toutes les ressources tierces ont été téléchargées.

Preuves locales privées : `/workspace/gsr-conformite/phase1/finalisation-backend.xml`, `finalisation-results.json`, logs finaux, captures et JSON de `finalisation-browser/`. Les premières tentatives du dispositif de recette ont nécessité adaptation du proxy de test au verrou d’agenda, regroupement des contrôles TestClient dans leur module pour ne pas réutiliser une boucle fermée, corrections de sélecteurs et emails fictifs acceptés. La non-régression WhatsApp a trouvé puis vérifié la correction d’un chevauchement mobile : marge réservée dans les nouveaux formulaires. Les tentatives échouées ne sont pas comptées comme réussites.

Le moteur ClamAV simulé est exclusivement une fixture privée des environnements de test isolés ; il ne remplace jamais le moteur réel dans la pile applicative locale. Aucun transfert de sauvegarde réel ou envoi SMTP réel n’a été réalisé. Les tests de sauvegarde extérieure inclus dans la suite backend utilisent un transport SFTP simulé. Le PV humain GSR demeure **non exécuté/non signé**.

## Fichiers du lot

Backend : `crm_personalization.py`, `business_media.py`, `public_business_intake.py`, `business_agenda.py`, `internal_notifications.py`, `training_schema.py`, `document_antivirus.py`, intégrations dans `server.py`, `crm.py`, `bookings.py`, `notifications.py`, `business_training.py`, `business_documents.py`.

Frontend : `Prospects.jsx`, `ProspectDetail.jsx`, `ProspectDocuments.jsx`, `AgendaSettings.jsx`, `Calendrier.jsx`, `BusinessNotifications.jsx`, modules `Documents.jsx` et `Media.jsx`, `MediaPublic.jsx`, `PublicBusinessForm.jsx`, `InterventionDetail.jsx`, pages Home/Actualites/SecuriteRoutiere/Mobilite/Misc, `RdvForm.jsx`, `NotificationSettings.jsx`, App/CrmLayout et export du client API.

Tests : `test_finalization_crm.py`, `test_finalization_media.py`, `test_finalization_agenda_intake.py`, `test_training_schema.py`, `test_document_antivirus.py`, adaptations documentaires et rollback, sécurité des nouveaux formulaires dans `test_security_regressions.py`, fixtures isolées `conftest.py`, `tests/finalization-browser.cjs`, extension des pages WhatsApp.

Configuration/documentation : `config/phase1.env.example`, `local-test/compose.antivirus.yaml`, build de test local actualisé, présent rapport, bilan de conformité, décisions GSR, procédure antivirus, contrat JSON pédagogique, recette et résultats.

## Réserves globales de conformité

Le lot ne vaut pas clôture de phase 1. Outre signatures ClamAV fraîches, SMTP, sauvegarde indépendante, contenus et recette humaine, le bilan global conserve les compléments d’administration générale des contenus statiques et de maquette (onglets/résumé permanent, liens métier sur organismes, certaines ventilations et filtres). Identités interagences et validité détaillée par justificatif restent à qualifier sans fusion ou ouverture automatique. Architecture cible conditionnée par la compatibilité LWS, arbitrage SMS du manifeste/V2 et revue légale restent ouverts. Aucun de ces écarts phase 1 n’est transféré silencieusement en phase 2.

Consulter `BILAN_CONFORMITE_FINAL.md`, `DECISIONS_GSR_RESTANTES.md`, `ANTIVIRUS_DOCUMENTS.md`, `SAUVEGARDE_HORS_SERVEUR.md`. La recette GSR doit être exécutée et signée par les cinq profils : Direction, Responsable Créteil/Bonneuil, Accueil Créteil/Bonneuil.
