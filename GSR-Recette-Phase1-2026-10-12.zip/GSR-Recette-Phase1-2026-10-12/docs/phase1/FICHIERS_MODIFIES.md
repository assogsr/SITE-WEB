# Fichiers du lot huit modules + CRM, phase 1

Les changements des lots antérieurs (sécurité, WhatsApp, blocages et emails) étaient déjà présents : cette liste distingue les nouveaux modules et leur intégration. Aucun fichier WordPress/LWS modifié.

## documents

- `backend/business_documents.py`
- `backend/tests/test_business_documents.py`
- `frontend/src/crm/modules/Documents.jsx`
- `MODULE_DOCUMENTS.md`

## organismes

- `backend/business_organizations.py`
- `backend/business_road_safety.py`
- `backend/tests/test_business_organizations.py`
- `backend/tests/test_business_road_safety.py`
- `frontend/src/crm/modules/Organizations.jsx`
- `frontend/src/crm/modules/RoadSafety.jsx`
- `MODULE_ORGANISMES.md`
- `MODULE_SECURITE_ROUTIERE.md`

## solidarite

- `backend/business_solidarity.py`
- `backend/tests/test_business_solidarity.py`
- `frontend/src/crm/modules/Solidarity.jsx`
- `MODULE_SOLIDARITE.md`

## formations

- `backend/business_training.py`
- `backend/tests/test_business_training.py`
- `frontend/src/crm/modules/Training.jsx`
- `MODULE_FORMATIONS.md`

## ressources

- `backend/business_speakers.py`
- `backend/business_resources.py`
- `backend/business_deadlines.py`
- `backend/tests/test_business_speakers.py`
- `backend/tests/test_business_resources.py`
- `backend/tests/test_business_deadlines.py`
- `frontend/src/crm/modules/Speakers.jsx`
- `frontend/src/crm/modules/Resources.jsx`
- `frontend/src/crm/modules/Deadlines.jsx`
- `MODULE_INTERVENANTS.md`
- `MODULE_EQUIPEMENTS.md`
- `MODULE_ECHEANCES.md`

## crm

- `backend/crm.py`
- `backend/crm_workflow.py`
- `backend/tests/test_crm_phase1.py`
- `frontend/src/crm/Prospects.jsx`
- `frontend/src/crm/ProspectDetail.jsx`
- `frontend/src/crm/Dashboard.jsx`
- `frontend/src/crm/Relances.jsx`
- `frontend/src/crm/ProspectForm.jsx`
- `frontend/src/crm/WorkflowSettings.jsx`
- `RAPPORT_LOT_CRM_GSR.md`

## Intégration commune et vérification

- `backend/server.py`
- `backend/sessions.py`
- `backend/bookings.py`
- `backend/notifications.py`
- `frontend/src/App.js`
- `frontend/src/crm/CrmLayout.jsx`
- `frontend/src/crm/Dashboard.jsx`
- `frontend/src/crm/Exports.jsx`
- `backend/tests/conftest.py`
- `backend/tests/test_crm_api.py`
- `backend/tests/test_security_regressions.py`
- `backend/tests/test_phase1_integration.py`
- `tests/phase1-browser.cjs`
- `local-test/nginx.conf`
- `local-test/frontend/`
- `docs/phase1/DEPENDANCES.md`
- `docs/phase1/RESULTATS_RECETTE.md`
- `RAPPORT_PHASE1_MODULES_GSR.md`

`local-test/frontend/` est la copie compilée de test local : manifests et fichiers JS/CSS remplacés par la compilation finale, sans publication. Les modifications communes conservent les mécanismes de réservation, mails et authentification des lots précédents.
