# Vérification des interfaces Docker — 12 octobre 2026

Pile locale reconstruite et démarrée avec `docker compose -f local-test/compose.yaml up -d --build --wait --wait-timeout 180`. Cinq services démarrés, contrôles de santé réussis ; frontend compilé courant utilisé. Site lié à 127.0.0.1 uniquement, aucun port API/Mongo publié. SMTP réel, tests SMTP réels et transfert extérieur vérifiés désactivés.

**127 contrôles navigateur réussis, aucune exception JavaScript**, aux largeurs 1440 et 390 pixels. Vérification sur la vraie pile Docker, sans faux antivirus :

- Pages publiques, espace Formation IA et trois formulaires métier dédiés visibles.
- Huit modules ouverts depuis la navigation CRM pour Direction puis Responsable/Accueil dans chacune des deux agences ; écrans/actions disponibles, listes éventuellement vides.
- Préférences des prospects, réglages d’agenda, médiathèque, notifications métier et administration emails accessibles depuis les interfaces.
- Création de huit comptes fictifs supplémentaires via le formulaire Utilisateurs (quatre profils agence/rôle sur deux tailles), sans remplacement des comptes existants ; mots de passe générés aléatoirement, non reproduits dans les résultats.
- Dépôt par l’interface d’un PDF fictif pour chaque taille ; verdict indisponible/quarantaine affiché et téléchargement désactivé. Aucune libération artificielle d’un document.
- Navigation de gestion des comptes et exports absente pour les rôles d’agence ; sélecteur de changement d’agence du calendrier absent pour ces profils.

Preuves privées dans `/workspace/gsr-conformite/recette-docker/interfaces.json`, `interfaces.log`, `containers.json` ; démarrage dans `phase1/recette-docker-start.log`. Ces contrôles prouvent l’accessibilité des écrans et les opérations explicitement citées ; ils ne remplacent pas une recette humaine exhaustive de chaque opération métier. Les résultats 358 backend/397 navigateur du lot de développement précédent ne sont pas présentés comme une nouvelle exécution aujourd’hui.

Aucun code applicatif ni règle métier modifié pour cette préparation. Guide et instructions de démarrage actualisés ; instructions cloud `start_skill` enregistrées en brouillon, sans publication/activation de configuration. La recette sur le PC de GSR et le téléchargement par le navigateur de l’utilisateur ne peuvent pas être vérifiés depuis ce cloud.
