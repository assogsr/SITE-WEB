# Phase 1 — contrats communs

Références : Manifeste GSR V1.5 et cahier maître V2, conservés dans `docs/references`. Aucune modification ni publication WordPress/LWS.

## Permissions

- Direction : vue transversale, configuration et décisions sensibles.
- Responsable et Accueil : accès transversal aux seuls prospects, conformément à la décision GSR. Les documents et les huit modules restent limités à leur agence.
- Éditeur : aucun accès aux dossiers métier privés. Ses fonctions de contenu existantes sont conservées.
- Les relations entre dossiers vérifient le périmètre et la cohérence des agences côté serveur. Aucun droit documentaire ne découle du simple accès à un prospect.

## Relations

| Socle | Utilisateurs |
|---|---|
| Authentification JWT, expiration, révocation | Tous les modules privés |
| Agences et permissions serveur | Tous les dossiers et pièces |
| Documents privés/versionnés | Organismes, dispositifs, inscriptions, intervenants, équipements, échéances, interventions |
| Organismes/interlocuteurs | Prescripteurs solidaires et interventions routières |
| Prospects | Qualification CRM et candidatures/demandes liées |
| Catalogue/personnes/sessions | Inscriptions, affectations intervenants |
| Intervenants/disponibilités connues | Vérification des conflits d’affectation |
| Notifications internes | Relances CRM, rappels non traités et échéances |
| SMTP | Configuration séparée ; expéditeurs validés conservés ; envois réels désactivés |
| Sauvegarde chiffrée MongoDB | Métadonnées et contenus documentaires privés stockés en base |

## Organisation du développement

Six espaces de travail distincts, cinq groupes de modules et un lot CRM. Chaque groupe possède ses nouveaux fichiers ; le coordinateur intègre seul les routes, la navigation, les notifications et les configurations communes. Les branches ne sont ni poussées ni déployées.

## Limite des phases

Le cahier GSR-FORM-006 demande la compatibilité future des présences et évaluations sans module avancé en phase 1. Les plannings avancés, réservations de ressources et maintenance automatisée relèvent de la phase 2 ; la génération avancée des bilans de la phase 3. La phase 1 comprend les champs préparatoires, les disponibilités connues, les opérations manuelles autorisées et les devis PDF produits hors CRM soumis à validation Direction.

Aucune valeur commerciale, liste de critères, délai réglementaire, numéro WhatsApp, secret SMTP ou contenu juridique n’est inventé. Les configurations non validées restent vides.
