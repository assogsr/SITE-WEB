# Références GSR reçues le 11 octobre 2026

Les deux fichiers sont les originaux fournis par l’utilisateur, conservés sans modification.

| Fichier | Version observée | SHA-256 |
|---|---|---|
| Manifeste_GSR_V1_5.md | 1.5, 9 octobre 2026 | 74c8cc089639ff21ea4774fc0e52232b8f18c572aee200230ea451ef1274f6ad |
| Cahier_des_charges_GSR_V2.pdf | Couverture 1.0 ; pieds de page et addendum 2.0, 9 octobre 2026 | c7fd79b37471b2d829b9c908f5de622e73058f274f0de8b3a51766efc482ce2e |

Les annexes et addenda récents précisent les informations historiques : l’adresse de Bonneuil est confirmée ; les horaires fournis sont ceux du secrétariat, pas ceux des cours ; aucun numéro WhatsApp n’est fourni. Le manifeste donne priorité à son annexe A sur ses formulations historiques, et l’annexe D actualise l’adresse et ajoute l’application mobile candidate en phase 3.

Le partage transversal des prospects est prévu par le manifeste A.1/A.22 et le cahier §4/GSR-CRM-003. L’utilisateur a confirmé le 11 octobre : Accueil et Responsable consultent et modifient tous les prospects ; exports Direction uniquement, sans élargissement automatique des autres modules. Le fichier `backend/crm.py` conserve une séparation entre scope général et scope prospects.

Périmètre phase 1 du cahier §2/§6 : socles site/IA, CRM, formulaires, agendas et emails, contenus, documents privés, organismes, dispositifs, formations/sessions, intervenants, ressources et échéances. Les phases 2/3 du §7 restent différées. L’extension mobile du manifeste est candidate et non une application native livrée.

Points de divergence à conserver dans le registre d’arbitrages : SMS reportés et non bloquants P1 dans le cahier O-06, mais recette SMS attendue avant lancement global dans le manifeste ; menus publics formulés différemment ; couverture PDF à harmoniser. Aucune règle métier manquante n’est inventée pour résoudre ces différences.

Les textes de conception ne sont pas des autorisations supplémentaires : la mission utilisateur commande la correction locale du projet React/FastAPI/MongoDB existant. Aucune migration Laravel, intervention WordPress/LWS, publication, engagement de fournisseur ou purge n’en découle. Les données tarifaires, droits médias, références réglementaires et configurations externes restent à vérifier.
