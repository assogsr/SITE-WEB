# MANIFEST — Nouveau site GSR

**Projet :** assogsr.com  
**Version :** 1.5 — ajout du module application mobile iOS/Android et rappels des arbitrages ultérieurs  
**Date :** 9 octobre 2026  
**Statut :** cadrage fonctionnel validé sur 60 décisions ; informations pratiques de l’étape 12 renseignées partiellement ; détails d’exécution et choix techniques conditionnels. Aucun développement ni déploiement autorisé par ce document.

**Règle de priorité :** les 60 décisions numérotées de l’annexe A prévalent sur les formulations historiques de la V1.0 ; les exigences réglementaires et de sécurité restent applicables.

## 1. Vision et principes
Créer un nouveau site pour **Génération Sécurité Routière (GSR)**, une auto-école de qualité accessible à tous, pour les agences de **Créteil** et **Bonneuil-sur-Marne**. Le site doit inspirer confiance, démontrer le sérieux pédagogique, rendre les offres compréhensibles et favoriser des **rendez-vous honorés puis des inscriptions réelles**. L'engagement social et solidaire reste visible dans un espace dédié, sans être le message dominant de l'accueil commercial.

**Signature de travail :** « GSR — Votre permis, notre engagement. »  
**Piliers :** prix accessibles sans comparaison non justifiée ; moniteurs qualifiés et accompagnement personnalisé ; proximité ; délais d'examen généralement de 1 à 2 mois **pour les élèves prêts**, selon les disponibilités et sans garantie. Ne jamais annoncer de réussite ou de date garantie.

## 2. Décisions validées — source de vérité
1. Refonte complète du site, sans réutilisation aveugle de l'ancien design ni des anciens modèles Elementor.
2. **Site sur mesure avec espace d'administration** ; la technologie exacte reste conditionnée par les capacités d'hébergement.
3. **Logo GSR original fourni**, non redessiné. Identité de travail : orange/doré, anthracite, blanc et gris clair ; valeurs exactes à extraire de l'original.
4. Deux agences : Créteil et Bonneuil-sur-Marne, pages locales et accès distincts dans une **administration unique**.
5. **Formulaire de rappel ET calendrier de réservation**, exclusivement pour les rendez-vous d'information / inscription en V1, pas pour le planning des leçons.
6. **WhatsApp pour chaque agence avec deux numéros distincts** ; numéros à renseigner ultérieurement. Choix de l'agence avant ouverture de WhatsApp.
7. **Mini-CRM intégré**, suivi de la demande jusqu'à l'inscription confirmée, avec statistiques de direction.
8. Catalogue de formations, pages, FAQ, avis autorisés, actualités, documents et contenus SEO administrables.
9. **Médiathèque et storyboards** : presse, télévision, vidéos, événements, actions de terrain, classement par année, mois, thématique, format et agence ; sélection de contenus à la une.
10. Hébergement existant **LWS Starter** à privilégier, sans modifier le site en production avant validation de l'architecture.
11. Migration SEO documentée et maintien de l'ancien site jusqu'à recette et bascule autorisée.

## 3. Publics et parcours
- Futurs élèves finançant eux-mêmes leur permis ; candidats en boîte manuelle ou automatique ; parents et proches.
- Publics des dispositifs solidaires ; partenaires, prescripteurs et collectivités, via des pages dédiées.
- Quatre parcours principaux : **préinscription en ligne**, **réserver un rendez-vous**, **demander un rappel pendant les horaires d’ouverture**, **contacter par WhatsApp ou téléphone**.
- Les prospects doivent être qualifiés et suivis, sans assimiler un clic ou un formulaire à une inscription.

## 4. Arborescence publique cible
**Menu principal validé :** Accueil | Formations & tarifs | Nos agences | À propos | Actualités & médias | Contact. Les pages financement, préinscription, FAQ, engagements et informations légales restent accessibles depuis les rubriques, les pages contextuelles et le pied de page.
- **Accueil** : promesse, preuve de qualité, formations, équipe, avis autorisés, délais conditionnels, agences, presse à la une, actions et appels à l'action.
- **Formations** : permis B manuel, automatique, code, conduite accélérée si confirmée ; autres offres validées ; détail par formation.
- **Agences** : page générale ; **Créteil** ; **Bonneuil-sur-Marne** (coordonnées, horaires, accès, moniteurs, photos authentiques, formulaire et prise de rendez-vous).
- **Pourquoi GSR ?** : méthode, équipe, équipements, témoignages et éléments de qualité vérifiables.
- **Rendez-vous et contact** : calendrier, rappel, téléphone et WhatsApp.
- **GSR dans les médias et sur le terrain** : storyboards, presse, télévision, vidéos, actions et chronologie.
- **Engagement social et solidaire** : programmes, actions, partenaires et réalisations.
- **Actualités et conseils** ; **FAQ** ; **Documents utiles**.
- **Informations légales** : mentions légales, confidentialité, cookies, informations réglementaires auto-école et accessibilité selon obligations applicables.

## 5. Design et expérience utilisateur
**Orientation validée :** moderne, premium, professionnelle, couleurs du logo original GSR ; page d’accueil priorisant formations, tarifs et prise de rendez-vous. Sur mobile, accès rapides **Appeler / WhatsApp / RDV**. La direction valide les maquettes des pages principales **et de l’administration avant développement**.
- Interface **mobile-first**, sobre, professionnelle et chaleureuse ; typographies lisibles, contrastes vérifiés, boutons clairement identifiables.
- Respect strict du logo original ; photographies réelles autorisées des agences, véhicules et équipes.
- En-tête : logo, formations, agences, médias, contact, CTA « Prendre rendez-vous ».
- Sur mobile : accès rapide au téléphone, rendez-vous et WhatsApp, sans superpositions gênantes.
- Design system documenté : couleurs, polices sous licence, espacements, boutons, champs, cartes, états d'erreur, menus, composants médias.
- Aucune donnée, photo, avis ou preuve sociale inventés.

## 6. Formulaire de rappel, préinscription et demandes de devis
- Choix obligatoire de l'agence, moyen de contact, nom, formation recherchée ; message facultatif ; collecte minimale.
- Type de demande : rappel, renseignements, devis. Accusé de réception distinct d'une confirmation de rendez-vous.
- Protection anti-spam, validation serveur, limitation des tentatives, journalisation des échecs, politique de confidentialité accessible.
- Attribution à l'agence choisie ; notification interne, suivi du statut et historique des échanges autorisés.
- Les devis sont **des demandes à traiter par l'équipe** en V1, pas un calculateur automatique de prix.

## 7. Calendrier de rendez-vous
- Disponibilités, horaires, exceptions et jours de fermeture gérés **par agence**.
- Types validés : **renseignements, inscription, évaluation initiale**. Durées et plages configurables ; chaque agence gère son propre calendrier, ses absences et fermetures.
- Réservation atomique pour empêcher les doubles réservations ; vérification des conflits ; **confirmation automatique ou manuelle configurable selon le type** (blocage temporaire et expiration des demandes en attente à spécifier). Le visiteur peut annuler ou déplacer son rendez-vous via un **lien sécurisé**.
- Notifications au visiteur et à l'accueil ; rappels par e-mail si l'envoi est configuré ; SMS seulement après arbitrage.
- États : demandé, confirmé, annulé, absent, honoré ; horodatage et audit des modifications.
- Gestion des fuseaux horaires Europe/Paris et changements d'heure.
- Le calendrier **ne gère pas les heures de conduite ni les examens**.

## 8. WhatsApp
- Bouton flottant accessible sur le site ; choix entre **Créteil** et **Bonneuil-sur-Marne**.
- Boutons contextuels sur les pages agences ; messages préremplis neutres, sans données personnelles sensibles dans l'URL.
- Deux numéros professionnels **à fournir plus tard** ; pas de numéros fictifs ni de liens actifs tant qu'ils ne sont pas vérifiés.
- Un échange WhatsApp n'est pas automatiquement importé au CRM sans intégration autorisée et information adéquate.

## 9. Mini-CRM et administration
**CRM :** **les deux agences consultent et modifient toutes les fiches prospects** ; chaque prospect conserve une agence de rattachement selon le formulaire. **Suppression réservée à la direction**, avec confirmation, traçabilité et respect de la conservation. Motif de non-inscription choisi dans une liste et commentaire. Relances internes J+1/J+3/J+7, sans automatiser les messages externes. Fiche prospect (identité, contact, agence, formation, source si connue, statut, historique utile, consentements/informations, responsable, dates, rendez-vous). Statuts : nouveau, à rappeler, contacté, rendez-vous fixé, venu, inscrit, sans réponse, non intéressé, annulé. Éviter les doublons ; traçabilité des modifications ; export limité aux habilités ; suppression et archivage selon politique validée.

**Administration unique :** pages et SEO, formations, agences, horaires, calendrier, prospects, demandes de devis, médias, storyboards, FAQ, témoignages, documents et paramètres de notifications.

**Rôles à définir précisément :** direction (vue transversale), responsable d'agence (son agence), accueil (contacts et rendez-vous de son agence), éditeur (contenus autorisés), administrateur technique (maintenance). Principe du moindre privilège ; authentification renforcée, journal d'audit et révision périodique des droits.

**Tableau de bord complet :** prospects, rendez-vous pris/honorés, inscriptions confirmées, taux de conversion, sources, agences, formations et délais de réponse ; filtres par période/agence ; indicateurs issus de données réelles, définitions documentées.

## 10. Storyboards, presse, vidéos et mémoire de GSR
**Nom de travail :** « GSR dans les médias et sur le terrain ».

**Interfaces validées :** **double vue magazine et chronologie interactive**, frise chronologique, storyboards en séquences (contexte → action → photos/vidéos → retombées), fiches détaillées et sélection « À la une ». Filtres combinables **année + mois + thématique**, plus format (presse, TV, vidéo, radio, événement, terrain), agence et programme ; recherche textuelle ; réinitialisation des filtres.

**Thématiques initiales validées :** Women Permis, sécurité routière, permis, insertion, événements, partenariats, vie de GSR. **Trois contenus mis à la une sur l’accueil, sélectionnés manuellement**. **Workflow :** accueil rédige → direction valide et publie → archivage/dépublication sans effacement systématique.

**Exemples à documenter avant publication :** article du *Parisien*, passage éventuel dans *Télématin*, actions Women Permis. Vérifier systématiquement date, source et existence de chaque contenu.

**Modèle éditorial :** titre, slug, résumé, texte original, média/source, URL officielle, date réelle de publication/diffusion/événement, date de mise en ligne GSR, catégories et thématiques multiples, agence, programme, image de couverture, crédits, droits, statut brouillon/en validation/publié/archivé, SEO, mise en avant. Les séquences de storyboard ont un ordre, un type, des médias, des légendes, alternatives textuelles et autorisations.

**Droits et accessibilité :** ne pas recopier les articles sans autorisation ; privilégier résumé original + lien ; lecteurs vidéo officiels autorisés ou lien vers replay ; photos/vidéos de personnes avec autorisations adaptées, particulièrement pour les mineurs ; retrait sur demande recevable ; sous-titres/transcriptions quand disponibles ; chargement différé ; consentement pour traceurs tiers si nécessaire.

## 11. SEO et visibilité locale
**Choix validés :** deux pages agences distinctes avec adresse, horaires, photos, avis et contact ; sélection d’avis Google authentiques avec leur source ; priorité SEO aux pages formations et agences. L’administration permet de modifier titres SEO, descriptions, URL et images de partage. Actualités communes filtrables par agence et thématique. Mesure combinée **outils Google (avec consentement applicable) + conversions CRM**. Les changements d’URL exigent des redirections contrôlées.
- Pages locales réellement distinctes, contenus utiles, cohérence avec Google Business Profile des deux agences.
- Titres/meta uniques, H1 pertinent, URLs stables, canonical, sitemap XML, robots.txt, données structurées conformes et véridiques, maillage interne.
- Pour les médias : pages indexables lorsque pertinentes, métadonnées `Article`, `VideoObject` ou `Event` seulement si justifiées, dates réelles et liens sources.
- Inventaire exhaustif des anciennes URL, table de redirections 301, analyse des pages performantes et contrôle Search Console après migration.
- Environnement de test protégé de l'indexation ; ne pas publier de pages de démonstration.

## 12. Architecture et hébergement — décision conditionnelle
**Constaté sur LWS Starter :** PHP proposé en plusieurs versions, MySQL/phpMyAdmin, accès SSH/terminal affichés, tâches cron, sous-domaines disponibles, stockage annoncé 200 Go, fonctions de sauvegarde et SSL. **PHP 7.4 apparaît comme valeur par défaut sur la capture** ; ne pas modifier le site actuel sans analyse.

**Architecture prioritaire validée sous condition :** Laravel + MySQL + administration intégrée, **uniquement si LWS Starter est techniquement compatible**. Si les tests échouent, revenir à un arbitrage documenté avant de changer de technologie ou d’hébergement. **Non validé définitivement** : vérifier PHP CLI et extensions, Composer, accès SSH réel, cron, déploiement du répertoire public, envoi d'e-mails, tâches asynchrones, sauvegardes, limites CPU/RAM et politique LWS. L'ancien scénario Next.js/Directus/PostgreSQL reste une option historique, non retenue comme cible ferme.

**Environnements :** développement local ; préproduction protégée ; production. Aucun sous-domaine ni changement DNS/PHP n'est effectué au seul titre de ce manifeste.

## 13. Sécurité, RGPD et maintenance
**Décisions validées :** sauvegarde quotidienne automatisée sur LWS **et copie chiffrée sur un stockage externe indépendant** ; accès administrateur par identifiant/mot de passe uniquement (sans MFA obligatoire) ; prospects non inscrits conservés **3 ans après dernier contact, sous réserve des règles applicables** ; sauvegardes quotidiennes automatisées avec copie indépendante de LWS et restauration testée ; bandeau cookies avec refus aussi simple que l’acceptation ; LWS Starter conservé si compatible ; environnement de test protégé, recette, sauvegarde et retour arrière avant bascule.
- HTTPS, mises à jour, contrôle des dépendances, mots de passe robustes et authentification par identifiant/mot de passe sans MFA imposée, limitation des tentatives, protection CSRF et des entrées, autorisations vérifiées côté serveur.
- Pas de secrets dans le code source ; sauvegardes chiffrées si nécessaire, stockées séparément, avec **restauration testée**.
- Politique de conservation et purge des prospects à valider ; minimisation des données ; journal des accès sensibles ; modalités d'exercice des droits.
- Consentement cookies/mesure d'audience selon les traceurs réellement utilisés ; mesures respectueuses de la vie privée.
- Erreurs détaillées non affichées publiquement en production ; journalisation privée et alertes sur pannes de formulaires, calendrier ou notifications.
- Maintenance documentée : responsables, fréquence des mises à jour, sauvegardes, vérification des liens, des médias et des droits utilisateurs.

## 14. Performance, accessibilité et qualité
- Cibles indicatives Core Web Vitals sur données terrain lorsque disponibles : **LCP ≤ 2,5 s ; INP ≤ 200 ms ; CLS ≤ 0,1** au 75e percentile.
- Images redimensionnées et compressées ; vidéos non bloquantes ; cache, ressources limitées, contrôle mobile.
- Accessibilité : viser WCAG 2.2 AA et vérifier les obligations applicables ; clavier, contrastes, formulaires, textes alternatifs, sous-titres.
- Tests fonctionnels, sécurité, mobile, navigateur, SEO, envoi des e-mails, protection des données et restauration.

## 15. Mise en production et migration
**Stratégie validée :** lancement global après validation de toutes les fonctions essentielles ; pas de mise en ligne publique progressive sans nouvelle décision.
1. **Audit complet du site existant assogsr.com** : inventaire des contenus, URL, médias, performances et données ; reprise sélective des contenus utiles avec vérification des droits et licences ; tableau des redirections 301 des anciennes URL.
2. Validation de l'architecture compatible LWS, puis conception de maquettes et modèle de données.
3. Développement et tests dans un environnement isolé ; protection des données de test.
4. **Recette complète** par les équipes GSR : formulaires, préinscription, CRM, calendrier, SMS, e-mails, SEO, sécurité, mobile, médias, administration et restauration des sauvegardes. Consigner résultats et anomalies.
5. Sauvegarde complète et plan de retour arrière ; validation des redirections et des mentions réglementaires.
6. Bascule **uniquement après accord explicite de GSR** ; contrôle SEO, formulaires, rendez-vous, médias et statistiques.

## 16. Périmètre V1 / hors V1
**V1 :** pages publiques, deux agences, **catalogue commun et tarifs identiques aux deux agences**, prix TTC et détail de chaque forfait, catégories permis B/boîte automatique/code/accéléré/AM/autres, page financements CPF/aides/dispositifs et éligibilité, **préinscription en ligne**, promotions à dates de validité approuvées par la direction, SEO, administration, rappel, devis manuel, calendrier des trois types de rendez-vous, WhatsApp, mini-CRM, tableau de bord, FAQ, avis autorisés, documents, storyboards, revue de presse, vidéos, filtres, trois mises en avant et conformité vérifiée.

**Hors V1 sans décision nouvelle :** paiement en ligne, espace élève pédagogique, gestion des leçons, synchronisation Klaxo/EasySystem, moteur automatique de devis, collecte automatique des conversations WhatsApp, import automatique d'articles de presse et transcriptions automatiques non vérifiées.

## 17. Critères d'acceptation
- Création/modification de chaque contenu par un éditeur habilité sans code ; aperçu et publication contrôlée.
- Droits d'accès testés entre Créteil et Bonneuil ; absence d'accès transversal non autorisé.
- Formulaire rappel/devis testé de bout en bout ; notifications reçues ou échec détecté.
- Aucun créneau réservable deux fois ; annulation/report et fuseau horaire testés.
- Prospect suivi jusqu'à « inscrit » sans confondre formulaire et inscription.
- WhatsApp pointe vers la bonne agence après renseignement des numéros officiels.
- Filtres média **année + mois + thématique** combinables ; storyboard éditable ; contenus non autorisés non publiés.
- Aucune information réglementaire manquante, aucun faux avis, aucune promesse de délai garanti.
- Site mobile et clavier testés ; performances mesurées ; anciennes URL redirigées ; sauvegarde restaurée lors d'un test.

## 18. Questions ouvertes — sans annuler les décisions validées
1. Vérification technique détaillée de l'offre LWS Starter et architecture finale.
2. Numéros WhatsApp professionnels distincts et coordonnées exactes des agences.
3. Catalogue définitif, **horaires propres à chaque agence**, pièces utiles, numéros d’agrément et informations réglementaires à publier.
4. Durée des rendez-vous, règles d’annulation, plages de réservation et notifications **e-mail + SMS** (confirmation, rappel, annulation, modification), choix du prestataire SMS après comparaison des offres.
5. Adresse professionnelle d’envoi GSR, paramètres du **SMTP authentifié** (délivrabilité SPF/DKIM/DMARC à vérifier), responsables de traitement des demandes.
6. Application opérationnelle de la règle de conservation 3 ans après dernier contact pour prospects non inscrits, exceptions légales, suppression/archivage, consentements et documents légaux validés.
7. Liste nominative des comptes, matrice détaillée des permissions, et modalités de traçabilité et d’export.
8. Inventaire des avis, photos, vidéos, articles et autorisations de diffusion.
9. Nom définitif de la rubrique média et détails de navigation des **deux vues validées** (magazine et chronologie).
10. Validation des textes publicitaires et présentation réglementaire des tarifs.

## 19. Livrables de réalisation à produire ensuite
- `SPECIFICATIONS_FONCTIONNELLES.md` : écrans, règles, parcours, notifications, permissions et modèle de données.
- `ARCHITECTURE_TECHNIQUE.md` : décision d'hébergement, installation, sécurité, sauvegardes et déploiement.
- `PLAN_DE_TESTS.md` : cas de recette détaillés et critères de bascule.
- Maquettes du site public et de l'administration **après validation du manifeste**.

---
**Principe directeur :** qualité et confiance visibles, démarches simples, mémoire des actions de GSR, données protégées et inscriptions mesurables. Les décisions validées ci-dessus priment sur les annexes historiques de la version 0.7, conservées séparément.



## 20. Règles opérationnelles complémentaires — étapes 10 et 11

### 20.1 Horaires et fermetures
- Horaires indépendants par agence, paramétrables par jour et par plage horaire, avec fuseau Europe/Paris. Les horaires du secrétariat sont précisés à l’annexe C ; les horaires des leçons de conduite ne sont pas présumés identiques.
- Direction et accueil peuvent gérer les fermetures exceptionnelles. Les réservations nouvelles sont bloquées sur ces périodes ; les rendez-vous existants déclenchent une alerte pour traitement et notification adaptée, sans annulation silencieuse.
- Le formulaire de rappel n'est disponible que pendant les horaires d'ouverture de l'agence sélectionnée, y compris prise en compte des fermetures exceptionnelles. Hors ouverture, afficher téléphone, adresse et autres canaux de contact.

### 20.2 Notifications SMS et e-mail
- Événements SMS : confirmation, rappel, annulation, déplacement de rendez-vous ; distinguer SMS transactionnels et prospection commerciale.
- Fournisseur SMS à sélectionner après comparaison : tarifs France, coût d'expéditeur, API, compatibilité hébergement, journalisation, délivrabilité, RGPD et gestion des échecs. Aucun prestataire n'est encore choisi.
- E-mails envoyés via SMTP authentifié depuis une adresse professionnelle GSR ; vérifier SPF, DKIM, DMARC, journaux d'échec et reprises. Les coordonnées et modèles de messages seront administrables selon les droits.
- Aucun SMS n'est déclaré opérationnel avant test réel et validation du budget.

### 20.3 Architecture et sauvegardes
- Laravel + MySQL est une **préférence conditionnelle**, non une faisabilité acquise. Vérifier versions PHP web/CLI, extensions, Composer, cron, accès SSH, dossier public, tâches différées, limites de ressources, politique d'hébergement et compatibilité des bibliothèques SMS/SMTP.
- Maintenir assogsr.com en production inchangé pendant les tests ; préproduction protégée par authentification et non-indexation.
- Sauvegardes quotidiennes automatisées LWS + copie **chiffrée hors de l'infrastructure LWS** ; accès restreint, durée de rétention à définir, supervision des échecs et test documenté de restauration.

### 20.4 Migration et recette
- Réaliser un audit de l'existant : URL, pages, SEO, contenus, images, téléchargements, formulaires, licences, données utiles et droits de diffusion ; conserver les éléments pertinents, ne pas recopier aveuglément.
- Établir une table ancienne URL → nouvelle URL (301), vérifier absence de chaînes de redirection et pages importantes conservées.
- Exiger une recette complète avec résultats consignés, corrections des anomalies bloquantes, sauvegarde préalable, procédure de retour arrière et accord explicite de la direction avant mise en production.

### 20.5 Données administrables
- Les coordonnées, horaires, agréments, labels, mentions légales et documents réglementaires sont modifiables via l'administration, avec validation de la direction avant publication et historique des changements.
- Vérifier les références officielles et leur actualité ; aucune valeur fictive ne doit être publiée.

## Annexe A — Registre exhaustif des 60 décisions validées (11 étapes)

### Étape 1 — CRM
1. Les deux agences voient tous les prospects.
2. Le prospect est attribué selon l’agence choisie dans le formulaire.
3. Relances internes proposées à J+1, J+3 et J+7.
4. Motif de non-inscription par liste de motifs et commentaire.

### Étape 2 — Calendrier
5. Rendez-vous : renseignements, inscription et évaluation initiale.
6. Chaque agence gère son propre calendrier.
7. Confirmation automatique ou manuelle configurable selon le type de rendez-vous.
8. Annulation ou déplacement par lien sécurisé côté visiteur.
9. Confirmation et rappels par e-mail et SMS, sous réserve d’un service SMS compatible.

### Étape 3 — WhatsApp et rappel
10. Bouton WhatsApp flottant avec choix Créteil/Bonneuil.
11. Formulaire : nom, téléphone, agence, motif, créneau souhaité et commentaire.
12. Demandes de rappel uniquement pendant les horaires d’ouverture.
13. Création automatique de fiche CRM et notification à l’accueil.
14. Alerte interne après 24 heures si rappel non traité.

### Étape 4 — Médias
15. Présentation double : chronologie interactive et vue magazine.
16. Classement par année, mois et thématique.
17. Thématiques : Women Permis, sécurité routière, permis, insertion, événements, partenariats, vie de GSR.
18. Vidéo intégrée si autorisée, sinon lien officiel vers replay/article.
19. L’accueil prépare, la direction valide et publie.
20. Trois contenus choisis manuellement sur la page d’accueil.

### Étape 5 — Administration
21. Profils : direction, responsable d’agence, accueil et éditeur de contenus.
22. Les deux accueils peuvent modifier toutes les fiches prospects ; direction supervise.
23. Suppression de fiches : direction uniquement, confirmation et traçabilité.
24. Tableau de bord complet : prospects, inscriptions, conversion, sources, agences, formations, délais de réponse.
25. Direction valide toutes les modifications de pages, tarifs et formations avant publication.
26. Historique des actions : utilisateur, date, modification et ancienne valeur si pertinente.

### Étape 6 — Formations
27. Afficher les prix et le détail de chaque forfait.
28. Catalogue par catégorie : permis B, boîte automatique, code, accéléré, permis AM, autres formations.
29. Même catalogue et mêmes tarifs obligatoires pour les deux agences.
30. Préinscription en ligne avec coordonnées.
31. Page dédiée CPF, aides et dispositifs avec conditions d’éligibilité.
32. Promotions avec dates de validité et validation par la direction.

### Étape 7 — SEO
33. Page Créteil et page Bonneuil, chacune avec adresse, horaires, photos, avis et contact.
34. Sélection d’avis Google authentiques, avec leur source.
35. Pages formations et agences optimisées pour Google.
36. Administration SEO : titres, descriptions, URL et images de partage.
37. Mesure par outils Google et conversions CRM.
38. Actualités communes GSR, filtrables par agence et thématique.

### Étape 8 — Sécurité et hébergement
39. Accès administration par identifiant et mot de passe uniquement.
40. Prospects non inscrits : conservation 3 ans après dernier contact, sous réserve des règles applicables.
41. Sauvegarde quotidienne automatisée et copie indépendante de l’hébergement.
42. Bandeau de consentement avec refus aussi simple que l’acceptation.
43. Conserver LWS Starter si les tests de compatibilité sont concluants.
44. Site de test protégé, recette complète, bascule avec sauvegarde et retour arrière.

### Étape 9 — Design et lancement
45. Style moderne, premium et professionnel, aux couleurs du logo GSR.
46. Accueil centré sur formations, tarifs et prise de rendez-vous.
47. Menu : Accueil, Formations & tarifs, Nos agences, À propos, Actualités & médias, Contact.
48. Mobile : navigation simple, accès rapide Appeler, WhatsApp et RDV.
49. Direction valide les maquettes des pages principales et de l’administration.
50. Lancement global après validation complète des fonctions essentielles.

### Étape 10 — Horaires, SMS et informations officielles
51. Chaque agence définit ses propres horaires d’ouverture.
52. Direction et accueil peuvent enregistrer les congés et fermetures exceptionnelles ; les créneaux fermés ne sont pas réservables.
53. SMS pour confirmation, rappel, annulation et modification des rendez-vous.
54. Comparer les offres de prestataires SMS avant toute sélection ou engagement financier.
55. Coordonnées, horaires, agréments, labels, mentions légales et documents réglementaires administrables.

### Étape 11 — Derniers choix techniques
56. **Laravel + MySQL** est l’architecture prioritaire, sous réserve de compatibilité démontrée avec LWS Starter.
57. Envoi des e-mails via une adresse professionnelle GSR et un service **SMTP authentifié**.
58. Sauvegarde quotidienne sur LWS et **copie chiffrée sur un stockage externe indépendant**.
59. Audit complet de l’ancien site assogsr.com, récupération sélective des contenus utiles et redirections des anciennes URL.
60. Recette complète obligatoire avant lancement : formulaires, CRM, calendrier, SMS, SEO, sécurité, mobile et sauvegardes.

## Annexe B — Arbitrages résiduels et risques à ne pas confondre avec des décisions validées

- **LWS :** la faisabilité PHP/Laravel, les tâches programmées, la délivrabilité du SMTP authentifié, le SMS, les limites d’hébergement et la sécurité des sauvegardes restent à tester. Aucun changement de PHP sur le site actuel sans validation.
- **SMS :** les quatre événements transactionnels sont validés, mais leur réalisation dépend du choix d’un fournisseur après comparaison, d’un budget et d’un mécanisme de reprise sur erreur. Ne pas promettre son fonctionnement avant validation.
- **Formulaire de rappel :** sa restriction aux horaires propres à chaque agence, fermetures comprises, est validée ; prévoir des coordonnées visibles hors horaires. Préciser le comportement des jours fériés et des créneaux souhaités.
- **CRM :** les deux accueils peuvent modifier toutes les fiches, malgré le rattachement par agence ; les permissions d’export, les conflits de modification et la déduplication restent à détailler.
- **Conservation :** trois ans est une règle de cadrage pour les prospects non inscrits, à confirmer selon le traitement et les obligations légales ; aucune purge aveugle.
- **Mot de passe seul :** décision explicite ; renforcer contrôles de session, limitation des essais, stockage sécurisé des mots de passe et révocation des accès. MFA non obligatoire en V1.
- **Préinscription :** ne vaut ni contrat ni paiement ; minimiser les données, prévoir la gestion des mineurs et les mentions applicables.
- **Catalogue commun :** tarifs et catalogue identiques pour les deux agences, mais les créneaux et disponibilités de rendez-vous restent propres à chaque agence.
- **Médias :** droits d’auteur, droit à l’image, liens officiels, dates et sources à vérifier ; aucun reportage de Télématin présumé existant.
- **SEO :** conserver les URL pertinentes, préparer les redirections, distinguer mesure des leads et inscriptions confirmées.
- **Recette :** aucune mise en production tant que les parcours essentiels (dont SMS et sauvegardes) et le plan de retour arrière ne sont pas validés par la direction.

**Prochaine étape documentaire :** rédiger les spécifications fonctionnelles détaillées et la matrice de permissions, puis les maquettes soumises à validation de la direction. Aucune mise en œuvre technique n’est lancée par cette consolidation.

**Contrôle de version :** 60 décisions validées (50 des étapes 1–9, 5 de l’étape 10 et 5 de l’étape 11). Les coordonnées et horaires du secrétariat reçus à l’étape 12 figurent à l’annexe C ; numéros WhatsApp, adresse de Bonneuil à confirmer, prestataire SMS, budgets et compatibilité LWS restent à documenter.


## Annexe C — Étape 12 : coordonnées, horaires et données opérationnelles (9 octobre 2026)

**Nature :** informations déclarées par GSR, à utiliser dans le cadrage. Elles ne constituent pas une vérification externe. Les horaires ci-dessous sont ceux du **secrétariat** ; ne pas les présenter comme horaires des leçons de conduite.

### C.1 Agence de Créteil
- Adresse déclarée : **33 allée de la Toison d’Or, 94000 Créteil**.
- Téléphone : **09 56 40 84 54**.
- E-mail de contact : **creteil.gsr@gmail.com**.
- Secrétariat : **du lundi au vendredi, de 13 h à 18 h ; samedi fermé**.
- Dimanche : **à confirmer explicitement** (ne pas afficher un horaire inventé).
- WhatsApp : **numéro non communiqué**.

### C.2 Agence de Bonneuil-sur-Marne
- Adresse de référence issue du cadrage précédent : **2 place des Libertés, 94380 Bonneuil-sur-Marne** ; **à confirmer**, car non renseignée dans la réponse de l’étape 12.
- Téléphone : **09 54 98 20 77**.
- E-mail de contact : **accueil.gsr@gmail.com**.
- Secrétariat : **lundi 13 h–17 h ; mardi à vendredi 9 h–13 h et 14 h–17 h ; samedi 10 h–13 h**.
- Dimanche : **à confirmer explicitement**.
- WhatsApp : **numéro non communiqué**.

### C.3 Règles fonctionnelles associées
- Les horaires sont **distincts par agence** et administrables ; une fermeture exceptionnelle enregistrée par la direction ou l’accueil bloque les créneaux de rendez-vous et la disponibilité du formulaire de rappel pour l’agence concernée.
- Les périodes de pause du secrétariat de Bonneuil (13 h–14 h du mardi au vendredi) sont considérées comme hors horaires de rappel, sauf décision contraire.
- Ne pas assimiler automatiquement horaires de secrétariat, horaires de conduite et plages de rendez-vous : les disponibilités des trois types de rendez-vous restent à paramétrer séparément.
- Le bouton WhatsApp conserve le choix entre les deux agences ; ne pas activer de liens WhatsApp avant validation des numéros.
- Les adresses **Gmail** communiquées sont retenues comme contacts d’agence. La décision 57 impose un **SMTP authentifié** pour les messages automatiques : vérifier le service et les méthodes d’authentification autorisées, la délivrabilité et les quotas. Une adresse sur domaine assogsr.com n’a **pas** été fournie et n’est donc pas supposée existante.
- **SMS : prestataire non sélectionné**, comparaison et budget à venir ; les événements prévus restent confirmation, rappel, annulation et modification de rendez-vous.
- **Informations réglementaires :** audit de l’ancien site assogsr.com, reprise uniquement des données vérifiées (agréments, labels, mentions légales, documents). Les données publiées doivent être approuvées par la direction.
- **LWS Starter :** caractéristiques techniques non connues ; audit en lecture seule avant de confirmer Laravel + MySQL. Ne pas modifier la version PHP ni le site en production pendant cet audit.

### C.4 Informations manquantes et vérifications avant développement
1. **Confirmer l’adresse exacte de Bonneuil** et les indications d’accès des deux agences.
2. **Fournir les deux numéros WhatsApp** et confirmer leur usage professionnel.
3. **Confirmer le statut du dimanche** et des jours fériés pour chaque secrétariat ; distinguer les plages de réservation des horaires d’accueil.
4. **Valider les adresses d’expédition** des e-mails automatiques et la configuration SMTP (ne jamais consigner de mots de passe dans le manifeste).
5. **Choisir le prestataire SMS** après comparaison des tarifs, de la conformité et des fonctions d’envoi/retour d’erreur.
6. **Vérifier les références réglementaires** et les pièces officielles sur l’ancien site et/ou auprès de GSR.
7. **Relever les caractéristiques LWS** : PHP web/CLI, MySQL, Composer, SSH, cron, extensions PHP, structure web, stockage, quotas, SSL, sauvegardes, capacité de restauration, et possibilité de site de test protégé.
8. **Tester le parcours complet** de prise de rendez-vous, notifications, CRM, annulations et sauvegardes en environnement de recette avant toute bascule.

**État de la version :** 60 décisions validées (étapes 1–11), étape 12 renseignée partiellement. Aucune décision de développement ou de déploiement prise.


---

## Annexe D — Extension du périmètre : application mobile GSR (9 octobre 2026)

**Statut :** ajout demandé par GSR au manifeste. Le principe d'une application mobile téléchargeable est retenu dans le périmètre cible ; les fonctionnalités et le financement restent à arbitrer lors du cadrage détaillé. **Phase recommandée : phase 3**, après stabilisation du site public et du CRM Laravel. Aucune application n'est développée ni publiée à ce stade.

### D.1 Objectif et plateformes

- Concevoir une **application mobile GSR** destinée aux élèves et bénéficiaires, distribuable sur **Apple App Store (iOS)** et **Google Play Store (Android)**, sous réserve de satisfaire les règles de publication des plateformes.
- Utiliser le **même référentiel métier** que le CRM Laravel via une **API sécurisée**, sans duplication indépendante des dossiers, rendez-vous ou documents.
- Étudier une solution **multiplateforme** (Flutter ou React Native, à comparer) plutôt que supposer d'emblée deux développements natifs distincts. Une PWA seule ne vaut pas engagement de publication sur les deux boutiques.
- Conserver l'identité visuelle GSR et une interface accessible, adaptée aux smartphones.

### D.2 Périmètre fonctionnel candidat (à valider avant développement)

1. **Compte personnel** de l'élève, avec activation sécurisée et récupération de compte.
2. **Tableau de bord** : agence de rattachement, informations utiles et état du parcours selon données disponibles.
3. **Rendez-vous** : consultation, confirmation, demande de modification ou d'annulation, selon les règles du CRM. Ne pas promettre le planning complet des leçons de conduite en phase initiale si cette donnée n'est pas intégrée.
4. **Notifications** : rappels de rendez-vous et messages de service ; notifications push soumises au consentement et à la configuration des plateformes ; solution email de secours.
5. **Documents** : consultation et téléchargement des documents autorisés, avec contrôle des droits, sans exposition d'URL permanentes publiques.
6. **Contact agences** : coordonnées officielles, téléphone et WhatsApp après validation des numéros.
7. **Suivi de parcours** : jalons de formation, code/conduite et actions solidaires uniquement si des données fiables sont présentes dans le CRM ; aucun résultat ou date d'examen inventé.
8. **Demandes de support** : formulaire ou messagerie simple reliée au CRM, avec politique de réponse clairement affichée.

**Hors périmètre initial par défaut :** paiement in-app, réservation automatique de toutes les leçons, géolocalisation continue, suivi de conduite en temps réel, examen en ligne, accès hors ligne aux dossiers sensibles, messagerie instantanée temps réel. Ces fonctions nécessiteraient une étude spécifique.

### D.3 Sécurité, données personnelles et conformité

- API HTTPS authentifiée, autorisations contrôlées **côté serveur**, séparation des accès élèves/personnel, limitation des requêtes et journalisation pertinente.
- Minimisation des données synchronisées sur le téléphone ; stockage local des secrets via mécanismes sécurisés du système ; pas de justificatifs sensibles mis en cache sans nécessité démontrée.
- Respect des droits RGPD, politique de confidentialité adaptée à l'application, gestion des notifications, durée de conservation, procédure de suppression/désactivation de compte et traitement des demandes.
- Examen des exigences **Apple App Store** et **Google Play** : comptes développeur, déclarations de confidentialité, fiches de boutique, captures, vérification, maintenance et mises à jour. L'acceptation en boutique n'est pas garantie.
- Tests d'accessibilité, de compatibilité iOS/Android, de sécurité, de connexion dégradée et de synchronisation avant publication.

### D.4 Architecture et dépendances

- Le **CRM Laravel reste la source de vérité** ; les droits d'accès doivent être vérifiés pour chaque requête mobile.
- API versionnée et documentée, gestion des sessions/tokens, renouvellement et révocation ; aucune clé secrète embarquée dans l'application.
- Notifications push via services des plateformes, uniquement après choix et validation des services nécessaires.
- Prévoir les impacts sur l'hébergement LWS : requêtes API supplémentaires, charge, stockage, sécurité et limites d'exécution ; ne pas présumer que l'offre Starter suffit.
- Environnements de développement, recette et production séparés, avec comptes et données de test.

### D.5 Phasage, budget et recette

- **Phase 1 :** concevoir les API et modèles métier de manière compatible avec une future application, sans lancer le développement mobile.
- **Phase 2 :** si pertinent, préparer les parcours mobiles et l'authentification, sans publication automatique.
- **Phase 3 (recommandée) :** conception UX, développement multiplateforme, connexion API, tests, dépôt en boutiques et maintenance, sous réserve d'un budget et d'une décision écrite de la direction.
- **Budget distinct à chiffrer** : conception, développement, API, tests appareils, comptes développeur, publication, notifications, maintenance et évolutions ; aucun montant n'est validé à ce jour.
- **Recette minimale** : connexion sécurisée ; droits d'accès ; synchronisation avec CRM ; rendez-vous ; notifications opt-in ; documents privés ; déconnexion/révocation ; suppression ou désactivation selon règles applicables ; tests iOS/Android ; procédure de support et mises à jour.

### D.6 Cohérence avec les décisions ultérieures du projet

Cette annexe ne remplace pas les décisions validées après la version 1.4 du manifeste. En particulier :
- **L'espace formation IA** demeure indexable par Google, mais **sans aucun lien depuis le site public principal GSR**, y compris l'accueil et sa navigation. L'application mobile ne doit pas devenir un moyen de contourner cette séparation sans décision expresse de la direction.
- Les tarifs et informations légalement obligatoires doivent être accessibles sur les supports publics concernés, après vérification.
- L'adresse de Bonneuil-sur-Marne **2 place des Libertés, 94380** a été confirmée ultérieurement ; la mention « à confirmer » de l'annexe C est donc périmée.
- LWS Starter reste une option privilégiée **sous réserve de preuves techniques** ; aucun développement, installation, migration ou déploiement n'est autorisé par le présent document.
