import uuid
import re
from datetime import datetime, timezone, timedelta, date
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field, EmailStr
from auth import get_current_user, require_roles, public_user, hash_password, ROLE_LABELS, log_action

router = APIRouter(prefix="/crm")
_db = {}
import crm_workflow as workflow
STATUSES = list(workflow.STATUS_LABELS)
STATUS_LABELS = workflow.STATUS_LABELS



def init(db):
    _db["db"] = db


def db():
    return _db["db"]


def now_iso():
    return datetime.now(timezone.utc).isoformat()


def scope(user, q: dict):
    q = dict(q)
    if user["role"] in ("responsable", "accueil"):
        if user.get("agency") not in ("creteil", "bonneuil"):
            raise HTTPException(403, "Aucune agence autorisée pour ce compte")
        q["agency"] = user["agency"]
    elif user["role"] != "direction":
        raise HTTPException(403, "Accès aux dossiers non autorisé")
    return q


def prospect_scope(user, q: dict):
    """Shared prospect access only; calendars, sessions and other scopes stay local."""
    q = {'archived': {'$ne': True}, **q}
    scoped = scope(user, q)  # Validate role and agency even for shared access.
    if user["role"] in ("responsable", "accueil"):
        scoped["agency"] = {"$in": ["creteil", "bonneuil"]}
    return scoped


def norm_phone(p):
    return "".join(c for c in (p or "") if c.isdigit())[-9:]


async def find_duplicates(d, user):
    ors = []
    if norm_phone(d.get("phone")):
        # Existing historical records need not have a materialized phone_norm field.
        digits = norm_phone(d["phone"])
        pattern = r"\D*".join(re.escape(c) for c in digits) + r"\D*$"
        ors.append({"phone": {"$regex": pattern}})
    if (d.get("email") or "").strip():
        ors.append({"email": {"$regex": f"^{re.escape(d['email'].strip())}$", "$options": "i"}})
    if not ors:
        return []
    cur = db().demandes.find(prospect_scope(user, {"$or": ors, "id": {"$ne": d["id"]}}), {"_id": 0, "id": 1, "reference": 1, "name": 1, "type": 1, "status": 1, "created_at": 1, "agency": 1})
    return await cur.to_list(20)


async def attach(d):
    slot = await db().creneaux.find_one({"id": d.get("creneau_id")}, {"_id": 0}) if d.get("creneau_id") else None
    d.pop("rdv_token_hash", None)
    d.pop("rdv_token_expires", None)
    d["creneau"] = slot
    d["session"] = await db().sessions_ia.find_one({"id": d["session_id"]}, {"_id": 0, "id": 1, "title": 1, "date_start": 1, "time_start": 1, "location": 1}) if d.get("session_id") else None
    d.setdefault("history", [])
    d.setdefault("status", "nouveau")
    d["status_label"] = STATUS_LABELS.get(d["status"], d["status"])
    return d


# ---------- dashboard ----------
@router.get('/dashboard')
async def dashboard(agency:Optional[str]=None,start:Optional[str]=None,end:Optional[str]=None,user=Depends(get_current_user)):
    empty={'total':0,'by_status':{s:0 for s in STATUSES},'by_type':{},'rdv_week':0,'relances_due':0,'recent':[],'status_labels':STATUS_LABELS,'conversions':{'verified':0,'rate':0},'appointments':{'honored':0,'absent':0,'rate':None},'sources':{},'response':{'count':0,'average_hours':None},'alerts':[]}
    if user['role']=='editeur':return empty
    q=scope(user,workflow.active_query())
    if agency:
        if agency not in ('creteil','bonneuil'):raise HTTPException(422,'Agence inconnue')
        if user['role']!='direction' and agency!=user['agency']:raise HTTPException(403,'Agence non autorisée')
        q['agency']=agency
    if start or end:
        try:
            bounds={}
            if start:bounds['$gte']=datetime.combine(date.fromisoformat(start),datetime.min.time(),workflow.PARIS).astimezone(timezone.utc).isoformat()
            if end:bounds['$lt']=datetime.combine(date.fromisoformat(end)+timedelta(days=1),datetime.min.time(),workflow.PARIS).astimezone(timezone.utc).isoformat()
            if start and end and start>end:raise ValueError()
            q['created_at']=bounds
        except ValueError:raise HTTPException(422,'Période invalide')
    docs=await db().demandes.find(q,{'_id':0}).to_list(10000)
    by_status={s:0 for s in STATUSES};by_type={};sources={};delays=[];verified=honored=absent=0
    for d in docs:
        status=d.get('status','nouveau');by_status[status]=by_status.get(status,0)+1
        kind=d.get('type','informations');by_type[kind]=by_type.get(kind,0)+1
        source=d.get('source') or 'Non renseignée';sources[source]=sources.get(source,0)+1
        verified+=bool(status=='inscrit' and d.get('enrollment_verified'))
        honored+=d.get('appointment_outcome')=='honore';absent+=d.get('appointment_outcome')=='absent'
        if d.get('first_response_at') and d.get('created_at'):
            delay=(workflow.parse_time(d['first_response_at'])-workflow.parse_time(d['created_at'])).total_seconds()/3600
            if delay>=0:delays.append(delay)
    today=workflow.instant().astimezone(workflow.PARIS).date();slotq=scope(user,{'date':{'$gte':today.isoformat(),'$lte':(today+timedelta(days=7)).isoformat()},'booked':{'$gt':0}})
    if agency:slotq['agency']=agency
    slots=await db().creneaux.find(slotq).to_list(500)
    relq=scope(user,{'done':False,'cancelled':{'$ne':True},'due_date':{'$lte':today.isoformat()}})
    if agency:relq['agency']=agency
    recent=sorted(docs,key=lambda d:d.get('created_at',''),reverse=True)[:6]
    total=len(docs)
    return {**empty,'total':total,'by_status':by_status,'by_type':by_type,'sources':sources,'rdv_week':sum(s.get('booked',0) for s in slots),'relances_due':await db().relances.count_documents(relq),'recent':[await attach(d) for d in recent],'conversions':{'verified':verified,'rate':round(100*verified/total,2) if total else 0},'appointments':{'honored':honored,'absent':absent,'rate':round(100*honored/(honored+absent),2) if honored+absent else None},'response':{'count':len(delays),'average_hours':round(sum(delays)/len(delays),2) if delays else None},'alerts':await workflow.alerts(db(),scope(user,workflow.active_query()))}


# ---------- prospects ----------
@router.get("/demandes")
async def list_demandes(status: Optional[str] = None, type: Optional[str] = None, agency: Optional[str] = None, q: Optional[str] = None, archived: bool = False, assigned_to: Optional[str] = None, start: Optional[str] = None, end: Optional[str] = None, due: Optional[str] = None, sort: str = "created_at", order: str = "desc", user=Depends(require_roles("direction", "responsable", "accueil"))):
    f = prospect_scope(user, {})
    if archived:
        if user["role"]!="direction":raise HTTPException(403,"Archives réservées à la Direction")
        f["archived"]=True
    if agency:
        if agency not in ("creteil", "bonneuil"):
            raise HTTPException(422, "Agence inconnue")
        f["agency"] = agency
    if status:
        f["status"] = status
    if type:
        f["type"] = type
    if assigned_to:f['assigned_to']=assigned_to
    try:
        for v in (start,end,due):
            if v:date.fromisoformat(v)
        if start and end and end<start:raise ValueError()
    except ValueError:raise HTTPException(422,'Période invalide')
    if start or end:
        f['created_at']={}
        if start:f['created_at']['$gte']=start
        if end:f['created_at']['$lt']=(date.fromisoformat(end)+timedelta(days=1)).isoformat()
    if due:f['next_action_due']={'$lt':(date.fromisoformat(due)+timedelta(days=1)).isoformat()}
    if sort not in ('created_at','name','reference','agency','status','next_action_due') or order not in ('asc','desc'):raise HTTPException(422,'Tri invalide')
    if q:
        if len(q) > 120:
            raise HTTPException(422, "Recherche trop longue")
        q = re.escape(q)
        f["$or"] = [{"name": {"$regex": q, "$options": "i"}}, {"reference": {"$regex": q, "$options": "i"}}, {"email": {"$regex": q, "$options": "i"}}, {"phone": {"$regex": q, "$options": "i"}}]
    docs = await db().demandes.find(f, {"_id": 0}).sort([(sort,1 if order=="asc" else -1),("id",1)]).to_list(500)
    out = []
    for d in docs:
        d = await attach(d)
        d["duplicates_count"] = len(await find_duplicates(d, user))
        out.append(d)
    return out


@router.get("/demandes/{id}")
async def get_demande(id: str, user=Depends(require_roles("direction", "responsable", "accueil"))):
    d = await db().demandes.find_one(({"id":id} if user["role"]=="direction" else prospect_scope(user, {"id": id})), {"_id": 0})
    if not d:
        raise HTTPException(404, "Dossier introuvable")
    d = await attach(d)
    d["duplicates"] = await find_duplicates(d, user)
    d["relances"] = await db().relances.find(scope(user, {"demande_id": id}), {"_id": 0}).sort("due_date", 1).to_list(50)
    return d


class DemandeUpdate(workflow.ProspectFields):
    pass


@router.post('/demandes', status_code=201)
async def create_demande(body: workflow.ProspectCreate, request: Request, user=Depends(require_roles('direction','responsable','accueil'))):
    from transactions import run
    prospect_scope(user,{})
    d=body.model_dump(exclude_none=True,exclude={'note','confirm_enrollment','detach_links'})
    if body.creneau_id or body.appointment_outcome:
        raise HTTPException(422, 'Les réservations et résultats de rendez-vous utilisent leur parcours dédié')
    d.update(id=str(uuid.uuid4()),reference='CRM-'+uuid.uuid4().hex[:12].upper(),created_at=now_iso(),history=[],archived=False)
    d['activity']=workflow.activity_for(d)
    async def operation(session):
        await workflow.validate_business(db(),d,body,session)
        await db().demandes.insert_one(dict(d),session=session)
        await workflow.schedule(db(),d,session)
        from internal_notifications import assignment
        await assignment(db(),d,d["id"]+":assignment:created",session)
        await log_action('demande_create',request,user,target=d['reference'],mongo_session=session)
    await run(db(),operation)
    return await get_demande(d['id'],user)


async def detach_reservations(d, user, session):
    if user['role']!='direction' and user.get('agency')!=d['agency']:
        raise HTTPException(403,'Modification des réservations réservée à leur agence')
    if d.get('creneau_id'):
        from bookings import cancel
        await cancel(db(),d,session)
        if d.get('reservation_active',d.get('status')!='annule'):
            from notifications import queue
            slot=await db().creneaux.find_one({'id':d['creneau_id']},session=session)
            await queue(db(),d,'annulation',d['id']+':crm-annulation',session,slot)
    if d.get('session_id'):
        await db().sessions_ia.update_one({'id':d['session_id']},{'$inc':{'capacity_revision':1}},session=session)
    return {'creneau_id':None,'session_id':None,'reservation_active':False,'rdv_token_hash':None,'rdv_token_expires':None,'inscription_status':'annulee'}


@router.patch('/demandes/{id}')
async def update_demande(id: str, body: DemandeUpdate, request: Request, user=Depends(require_roles('direction','responsable','accueil'))):
    from transactions import run
    async def operation(session):
        d=await db().demandes.find_one(prospect_scope(user,{'id':id}),{'_id':0},session=session)
        if not d:raise HTTPException(404,'Dossier introuvable')
        changes=body.model_dump(exclude_unset=True,exclude={'note','confirm_enrollment','detach_links'})
        if 'creneau_id' in changes:raise HTTPException(422,'Utilisez le mécanisme de réservation pour changer un rendez-vous')
        if any(changes.get(k) is None for k in ('agency','type','activity','status') if k in changes):raise HTTPException(422,'Champ obligatoire vide')
        reassigned=changes.get('agency',d['agency'])!=d['agency']
        if body.status == 'inscrit' and d.get('status') != 'inscrit' and not body.confirm_enrollment:
            raise HTTPException(422, 'Confirmez explicitement la nouvelle inscription réelle')
        if body.status and body.status != 'inscrit' and d.get('status') == 'inscrit':
            changes.update(enrollment_verified=False, enrolled_at=None)
        linked=bool(d.get('creneau_id') or d.get('session_id'))
        if reassigned and linked:
            if not body.detach_links:raise HTTPException(409,'Détachement explicite des réservations requis avant réaffectation')
            changes.update(await detach_reservations(d,user,session))
        elif body.status=='annule' and d.get('creneau_id'):
            detached=await detach_reservations(d,user,session)
            changes.update(reservation_active=False,rdv_token_hash=None,rdv_token_expires=None)
        elif d.get('creneau_id') and d.get('reservation_active') is False and body.status and body.status!='annule':
            raise HTTPException(409,'Un rendez-vous annulé nécessite une nouvelle réservation')
        proposed={**d,**changes}
        proposed=await workflow.validate_business(db(),proposed,body,session)
        for key in ('enrolled_at','enrollment_verified','non_registration_label'):
            if key in proposed:changes[key]=proposed[key]
        if body.appointment_outcome:
            if d.get('reservation_active') is False or d.get('status') == 'annule':
                raise HTTPException(422, 'Un rendez-vous annulé ne peut pas être déclaré honoré ou absent')
            if not d.get('creneau_id'):raise HTTPException(422,'Rendez-vous requis')
            slot=await db().creneaux.find_one({'id':d['creneau_id']},session=session)
            if not slot:raise HTTPException(422,'Rendez-vous introuvable')
            appointment_at=datetime.fromisoformat(slot['date']+'T'+slot['time']).replace(tzinfo=workflow.PARIS).astimezone(timezone.utc)
            if appointment_at>workflow.instant():raise HTTPException(422,'Rendez-vous futur')
            if user['role']!='direction' and user.get('agency')!=d['agency']:raise HTTPException(403,'Résultat réservé à cette agence')
            changes['appointment_recorded_at']=now_iso()
        events=[]
        for key,value in changes.items():
            if value!=d.get(key):events.append({'at':now_iso(),'by':user['name'],'kind':'reaffectation' if key=='agency' else 'modification','field':key,'text':f'{key}: {d.get(key) or "—"} → {value or "—"}'})
        if body.note:events.append({'at':now_iso(),'by':user['name'],'kind':'note','text':body.note})
        if changes or events:
            await db().demandes.update_one({'id':id},{'$set':{**changes,'updated_at':now_iso()},'$inc':{'crm_revision':1},'$push':{'history':{'$each':events}}},session=session)
            await workflow.pending_tasks(db(),{**d,**changes},session)
            if changes.get("assigned_to") and changes.get("assigned_to")!=d.get("assigned_to"):
                from internal_notifications import assignment
                await assignment(db(),{**d,**changes},d["id"]+":assignment:"+str(d.get("crm_revision",0)+1),session)
            await log_action('demande_update',request,user,target=d['reference'],meta={'fields':list(changes),'note':bool(body.note)},mongo_session=session)
    await run(db(),operation)
    return await get_demande(id,user)


@router.post('/demandes/{id}/contacts',status_code=201)
async def contact(id: str, body: workflow.ContactEvent, request: Request, user=Depends(require_roles('direction','responsable','accueil'))):
    from transactions import run
    async def operation(session):
        d=await db().demandes.find_one(prospect_scope(user,{'id':id}),session=session)
        if not d:raise HTTPException(404,'Dossier introuvable')
        at=body.occurred_at or now_iso()
        if workflow.parse_time(at)<workflow.parse_time(d['created_at']):raise HTTPException(422,'Contact antérieur au dossier')
        sets={'updated_at':now_iso()}
        if body.direction=='sortant' and body.outcome=='effectue':
            if not d.get('first_response_at'):sets['first_response_at']=at
            if d.get('type')=='rappel':sets['callback_handled_at']=at
        await db().demandes.update_one({'id':id},{'$set':sets,'$inc':{'crm_revision':1},'$push':{'history':{'at':at,'by':user['name'],'kind':'contact',**body.model_dump(exclude_none=True)}}},session=session)
        await log_action('contact_record',request,user,target=d['reference'],meta={'channel':body.channel,'direction':body.direction,'outcome':body.outcome},mongo_session=session)
    await run(db(),operation)
    return await get_demande(id,user)


@router.post('/demandes/{id}/archive')
async def archive(id:str,body:workflow.Decision,request:Request,user=Depends(require_roles('direction'))):
    return await decide(id,body,request,user,False)


@router.post('/demandes/{id}/delete')
async def delete(id:str,body:workflow.Decision,request:Request,user=Depends(require_roles('direction'))):
    return await decide(id,body,request,user,True)


async def decide(id,body,request,user,erase):
    from transactions import run
    async def operation(session):
        d=await db().demandes.find_one({'id':id},{'_id':0},session=session)
        if not d:raise HTTPException(404,'Dossier introuvable')
        if body.confirmation!=d['reference']:raise HTTPException(422,'Confirmation exacte de la référence requise')
        if erase and d.get('legal_hold'):raise HTTPException(409,'Conservation légale active')
        if erase:
            for collection in ('prospect_document_links','private_documents','business_documents','documents','solidarity_applications','business_training_people','business_training_enrollments','training_enrollments','road_requests','business_road_safety'):
                if await db()[collection].find_one({'$or':[{'prospect_id':id},{'demande_id':id},{'parent_id':id}]},session=session):raise HTTPException(409,'Des éléments métier liés doivent être traités avant suppression')
            if await db().mail_outbox.find_one({'payload.reference':d['reference'],'status':{'$in':['sending','uncertain']}},session=session):raise HTTPException(409,'Envoi en cours ou résultat indéterminé')
        sets={}
        if d.get('creneau_id') or d.get('session_id'):
            if not body.detach_links:raise HTTPException(409,'Détachement explicite des réservations requis')
            sets=await detach_reservations(d,user,session)
        if erase:
            await db().relances.delete_many({'demande_id':id},session=session)
            await db().mail_outbox.delete_many({'payload.reference':d['reference']},session=session)
            await db().demandes.delete_one({'id':id},session=session)
        else:
            sets.update(archived=True,archived_at=now_iso(),archived_by=user['id'],archive_reason=body.reason)
            await db().demandes.update_one({'id':id},{'$set':sets,'$inc':{'crm_revision':1},'$push':{'history':{'at':now_iso(),'by':user['name'],'kind':'archive','text':body.reason}}},session=session)
            await workflow.schedule(db(),{**d,**sets},session)
        await log_action('demande_delete' if erase else 'demande_archive',request,user,target=d['reference'],meta={'reason':body.reason},mongo_session=session)
    await run(db(),operation)
    return {'ok':True}


class WorkflowSettings(BaseModel):
    non_registration_reasons: list[dict] = Field(default_factory=list,max_length=100)


@router.get('/workflow-settings')
async def workflow_settings(user=Depends(require_roles('direction','responsable','accueil'))):
    config=await db().site_settings.find_one({'_id':'crm_workflow'},{'_id':0}) or {}
    return {'non_registration_reasons':config.get('non_registration_reasons',[]),'activities':list(workflow.ACTIVITIES),'sub_statuses':workflow.SUB_STATUSES}


@router.patch('/workflow-settings')
async def save_workflow(body:WorkflowSettings,request:Request,user=Depends(require_roles('direction'))):
    seen=set();reasons=[]
    for item in body.non_registration_reasons:
        if set(item)-{'id','label','active'} or not isinstance(item.get('id'),str) or not re.fullmatch(r'[a-zA-Z0-9_-]{1,100}',item['id']) or item['id'] in seen or not isinstance(item.get('label'),str) or not 2<=len(item['label'].strip())<=120 or not isinstance(item.get('active',True),bool):raise HTTPException(422,'Liste de motifs invalide')
        seen.add(item['id']);reasons.append({'id':item['id'],'label':item['label'].strip(),'active':item.get('active',True)})
    await db().site_settings.update_one({'_id':'crm_workflow'},{'$set':{'non_registration_reasons':reasons}},upsert=True)
    await log_action('crm_workflow_settings',request,user,meta={'count':len(reasons)})
    return await workflow_settings(user)


@router.get('/assignees')
async def assignees(user=Depends(require_roles('direction','responsable','accueil'))):
    prospect_scope(user,{})
    return await db().users.find({'$or':[{'active':True},{'active':{'$exists':False}}],'role':{'$in':['direction','responsable','accueil']}},{'_id':0,'id':1,'name':1,'role':1,'agency':1}).to_list(500)


@router.get('/alerts')
async def callback_alerts(user=Depends(require_roles('direction','responsable','accueil'))):
    return await workflow.alerts(db(),scope(user,workflow.active_query()))


# ---------- relances ----------
class RelanceCreate(BaseModel):
    due_date: str
    note: str = Field(min_length=2, max_length=500)
    channel: str = "telephone"


@router.get("/relances")
async def list_relances(all: bool = False, user=Depends(require_roles("direction", "responsable", "accueil"))):
    f = scope(user, {"cancelled": {"$ne": True}, **({} if all else {"done": False})})
    rel = await db().relances.find(f, {"_id": 0}).sort("due_date", 1).to_list(300)
    today = date.today().isoformat()
    for r in rel:
        r["overdue"] = (not r["done"]) and r["due_date"] < today
    return rel


@router.post('/demandes/{id}/relances',status_code=201)
async def create_relance(id:str,body:RelanceCreate,request:Request,user=Depends(require_roles('direction','responsable','accueil'))):
    from transactions import run
    try:date.fromisoformat(body.due_date)
    except ValueError:raise HTTPException(422,'Date invalide')
    if body.channel not in ('telephone','email','sms','interne'):raise HTTPException(422,'Canal invalide')
    result={}
    async def operation(session):
        d=await db().demandes.find_one(scope(user,{'id':id,'archived':{'$ne':True}}),session=session)
        if not d:raise HTTPException(404,'Dossier introuvable')
        if d.get('status') in workflow.TERMINAL:raise HTTPException(409,'Dossier clôturé')
        r={'id':str(uuid.uuid4()),'demande_id':id,'reference':d['reference'],'name':d['name'],'agency':d['agency'],'due_date':body.due_date,'note':body.note,'channel':body.channel,'done':False,'created_by':user['name'],'created_at':now_iso()}
        await db().demandes.update_one({'id':id},{'$inc':{'crm_revision':1},'$push':{'history':{'at':now_iso(),'by':user['name'],'kind':'relance','text':f'Relance planifiée le {body.due_date} : {body.note}'}}},session=session)
        await db().relances.insert_one(dict(r),session=session)
        await log_action('relance_create',request,user,target=d['reference'],meta={'due_date':body.due_date},mongo_session=session)
        result.update(r)
    await run(db(),operation)
    return result


@router.patch('/relances/{rid}')
async def toggle_relance(rid:str,done:bool=True,user=Depends(require_roles('direction','responsable','accueil'))):
    from transactions import run
    result={}
    async def operation(session):
        r=await db().relances.find_one(scope(user,{'id':rid,'cancelled':{'$ne':True}}),{'_id':0},session=session)
        if not r:raise HTTPException(404,'Relance introuvable')
        d=await db().demandes.find_one(scope(user,{'id':r['demande_id'],'archived':{'$ne':True}}),session=session)
        if not d:raise HTTPException(404,'Dossier introuvable')
        if r['done']!=done:
            sets={'done':done,'done_at':now_iso() if done else None,'done_by':user['name'] if done else None}
            await db().relances.update_one({'id':rid},{'$set':sets},session=session)
            await db().demandes.update_one({'id':d['id']},{'$inc':{'crm_revision':1},'$push':{'history':{'at':now_iso(),'by':user['name'],'kind':'relance','text':('Relance effectuée : ' if done else 'Relance réouverte : ')+r['note']}}},session=session)
            r.update(sets)
        result.update(r)
    await run(db(),operation)
    return result


# ---------- calendrier ----------
@router.get("/calendrier")
async def calendrier(agency: Optional[str] = None, user=Depends(require_roles("direction", "responsable", "accueil"))):
    f = scope(user, {})
    if agency and "agency" not in f:
        f["agency"] = agency
    today = date.today().isoformat()
    slots = await db().creneaux.find({**f, "date": {"$gte": today}}, {"_id": 0}).sort([("date", 1), ("time", 1)]).to_list(500)
    from business_agenda import configuration,effective
    configs={a:await configuration(db(),a) for a in set(s["agency"] for s in slots)}
    slots=[effective(s,configs[s["agency"]]) for s in slots]
    booked_ids = [s["id"] for s in slots if s["booked"]]
    dem = await db().demandes.find(scope(user, {"creneau_id": {"$in": booked_ids}, "archived": {"$ne": True}, "reservation_active": {"$ne": False}, "status": {"$ne": "annule"}}), {"_id": 0, "id": 1, "reference": 1, "name": 1, "phone": 1, "type": 1, "status": 1, "creneau_id": 1}).to_list(500)
    by_slot = {}
    for d in dem:
        by_slot.setdefault(d["creneau_id"], []).append(d)
    for s in slots:
        s["demandes"] = by_slot.get(s["id"], [])
        s["remaining"] = max(0, s["capacity"] - s["booked"])
    return slots


class SlotUpdate(BaseModel):
    capacity: Optional[int] = Field(default=None, ge=0, le=10)
    closed: Optional[bool] = None


@router.patch("/calendrier/{sid}")
async def update_slot(sid: str, body: SlotUpdate, request: Request, user=Depends(require_roles("direction", "responsable", "accueil"))):
    if body.capacity is not None and user['role']=='accueil':
        raise HTTPException(403, "La modification de capacité est réservée à la Direction ou au Responsable.")
    sets=body.model_dump(exclude_none=True)
    if not sets:raise HTTPException(422,"Aucune modification demandée")
    condition=scope(user, {'id':sid})
    if body.capacity is not None:condition['booked']={'$lte':body.capacity}
    s = await db().creneaux.find_one_and_update(condition, {"$set": sets}, projection={"_id": 0}, return_document=True)
    if not s:
        if await db().creneaux.find_one(scope(user, {"id": sid}), {"_id": 0, "id": 1}):
            raise HTTPException(409, "La capacité ne peut pas être inférieure aux réservations existantes.")
        raise HTTPException(404, "Créneau introuvable")
    await log_action("slot_capacity", request, user, target=sid, meta=sets)
    return s


# ---------- contenus (actualités) ----------
class ArticleBody(BaseModel):
    title: str = Field(min_length=3, max_length=160)
    cat: str = "Actualités"
    body: str = Field(min_length=10, max_length=5000)


@router.get("/articles")
async def list_articles(user=Depends(require_roles("direction", "editeur"))):
    return await db().articles.find({}, {"_id": 0}).sort("created_at", -1).to_list(100)


@router.post("/articles", status_code=201)
async def create_article(body: ArticleBody, user=Depends(require_roles("direction", "editeur"))):
    a = {**body.model_dump(), "id": str(uuid.uuid4()), "status": "brouillon", "author": user["name"], "created_at": now_iso(), "history": [{"at": now_iso(), "by": user["name"], "text": "Brouillon créé"}]}
    await db().articles.insert_one({**a})
    return a


@router.patch("/articles/{aid}")
async def article_status(aid: str, status: str, request: Request, user=Depends(require_roles("direction", "editeur"))):
    allowed = {"editeur": ("brouillon", "en_attente"), "direction": ("brouillon", "en_attente", "publie", "refuse")}
    if status not in allowed[user["role"]]:
        raise HTTPException(403, "Seule la Direction peut publier ou refuser un contenu.")
    a = await db().articles.find_one_and_update({"id": aid}, {"$set": {"status": status, **({"published_at": now_iso()} if status == "publie" else {})}, "$push": {"history": {"at": now_iso(), "by": user["name"], "text": f"Statut : {status}"}}}, projection={"_id": 0}, return_document=True)
    if not a:
        raise HTTPException(404, "Article introuvable")
    await log_action("article_status", request, user, target=a["title"], meta={"status": status})
    return a


# ---------- utilisateurs ----------
@router.get("/users")
async def list_users(user=Depends(require_roles("direction"))):
    return [public_user(u) for u in await db().users.find({}, {"_id": 0}).to_list(50)]


class UserCreate(BaseModel):
    email: EmailStr
    name: str = Field(min_length=2, max_length=120)
    role: str
    agency: Optional[str] = None
    password: str = Field(min_length=8, max_length=72)


@router.post("/users", status_code=201)
async def create_user(body: UserCreate, request: Request, user=Depends(require_roles("direction"))):
    if body.role not in ROLE_LABELS:
        raise HTTPException(400, "Rôle inconnu")
    if (body.agency not in (None, "creteil", "bonneuil")
            or body.role in ("responsable", "accueil") and body.agency is None):
        raise HTTPException(422, "Une agence valide est obligatoire pour ce rôle")
    if await db().users.find_one({"email": body.email.lower()}):
        raise HTTPException(409, "Cet e-mail existe déjà")
    u = {"id": str(uuid.uuid4()), "email": body.email.lower(), "name": body.name, "role": body.role, "agency": body.agency, "active": True, "password_hash": hash_password(body.password), "created_at": now_iso()}
    await db().users.insert_one({**u})
    await log_action("user_create", request, user, target=u["email"], meta={"role": body.role, "agency": body.agency})
    return public_user(u)


class UserPatch(BaseModel):
    active: Optional[bool] = None
    revoke_sessions: Optional[bool] = None


@router.patch("/users/{uid}")
async def patch_user(uid: str, body: UserPatch, request: Request, user=Depends(require_roles("direction"))):
    target = await db().users.find_one({"id": uid}, {"_id": 0})
    if not target:
        raise HTTPException(404, "Utilisateur introuvable")
    if uid == user["id"] and body.active is False:
        raise HTTPException(400, "Vous ne pouvez pas désactiver votre propre compte.")
    sets = {}
    if body.active is not None:
        sets["active"] = body.active
    revoke = body.revoke_sessions or body.active is False
    if revoke:
        sets["sessions_revoked_at"] = now_iso()
    if sets:
        await db().users.update_one({"id": uid}, {"$set": sets, **({"$inc": {"session_version": 1}} if revoke else {})})
        await log_action("user_update", request, user, target=target["email"], meta=sets)
    return public_user(await db().users.find_one({"id": uid}, {"_id": 0}))


@router.get("/audit")
async def audit(action: Optional[str] = None, q: Optional[str] = None, limit: int = 200, user=Depends(require_roles("direction"))):
    f = {}
    if action:
        f["action"] = action
    if q:
        if len(q) > 120:
            raise HTTPException(422, "Recherche trop longue")
        q = re.escape(q)
        f["$or"] = [{"user": {"$regex": q, "$options": "i"}}, {"target": {"$regex": q, "$options": "i"}}]
    return await db().audit_log.find(f, {"_id": 0}).sort("at", -1).limit(max(1, min(limit, 1000))).to_list(1000)


@router.get("/meta")
async def meta():
    return {"statuses": STATUS_LABELS, "roles": ROLE_LABELS}


# ---------- export CSV (Direction) ----------
TYPE_LABELS = {"rendez-vous": "Rendez-vous", "informations": "Informations", "inscription": "Inscription", "rappel": "Rappel", "intervention": "Intervention", "partenariat": "Partenariat", "formation-ia": "Formation IA"}
INSC_LABELS = {"en_attente": "En attente", "confirmee": "Confirmée", "refusee": "Refusée", "liste_attente": "Liste d'attente"}


def _csv(rows, headers):
    import csv
    import io
    buf = io.StringIO()
    w = csv.writer(buf, delimiter=";", lineterminator="\r\n")
    w.writerow(headers)
    for r in rows:
        # Spreadsheet quoting alone does not stop formula execution.
        w.writerow(["'" + str(v) if str(v).lstrip().startswith(("=", "+", "-", "@", "\t", "\r", "\n"))
                    or str(v).startswith(("\t", "\r", "\n")) else v for v in r])
    return "\ufeff" + buf.getvalue()


@router.get("/export")
async def export_csv(kind: str, request: Request, date_from: Optional[str] = None, date_to: Optional[str] = None, agency: Optional[str] = None, status: Optional[str] = None, archived: bool = False, user=Depends(require_roles("direction"))):
    from fastapi.responses import Response
    if kind not in ("prospects", "rendez-vous"):
        raise HTTPException(400, "Type d'export inconnu")
    f = {'archived': True} if archived else workflow.active_query()
    if agency:
        f["agency"] = agency
    if status:
        f["status"] = status
    if date_from or date_to:
        f["created_at"] = {}
        if date_from:
            f["created_at"]["$gte"] = date_from
        if date_to:
            f["created_at"]["$lte"] = date_to + "T23:59:59"
    if kind == "rendez-vous":
        f["$or"] = [{"creneau_id": {"$nin": [None, ""]}}, {"type": "rendez-vous"}]
    docs = await db().demandes.find(f, {"_id": 0}).sort("created_at", 1).to_list(5000)
    slots = {s["id"]: s for s in await db().creneaux.find({"id": {"$in": [d.get("creneau_id") for d in docs if d.get("creneau_id")]}}, {"_id": 0}).to_list(5000)}
    rows = []
    for d in docs:
        s = slots.get(d.get("creneau_id"))
        base = [d.get("reference", ""), str(d.get("created_at") or "")[:19].replace("T", " "), TYPE_LABELS.get(d.get("type"), d.get("type", "")), d.get("agency", ""), STATUS_LABELS.get(d.get("status", "nouveau"), d.get("status", "")), d.get("name", ""), d.get("phone", ""), d.get("email", "")]
        if kind == "prospects":
            rows.append(base + [d.get("formation", ""), d.get("structure", ""), f"{d.get('rappel_date') or ''} {d.get('rappel_time') or ''}".strip(), INSC_LABELS.get(d.get("inscription_status"), ""), (d.get("message") or "").replace("\n", " ")])
        else:
            rows.append(base + [s["date"] if s else "", s["time"] if s else "", f"{d.get('rappel_date') or ''} {d.get('rappel_time') or ''}".strip()])
    headers = ["Référence", "Reçue le", "Motif", "Agence", "Statut", "Nom", "Téléphone", "E-mail"] + (["Formation", "Structure", "Rappel souhaité", "Inscription session IA", "Message"] if kind == "prospects" else ["Date RDV", "Heure RDV", "Rappel souhaité"])
    filters = {k: v for k, v in {"date_from": date_from, "date_to": date_to, "agency": agency, "status": status}.items() if v}
    await log_action("export_csv", request, user, target=kind, meta={**filters, "rows": len(rows)})
    name = f"gsr-{kind}-{datetime.now(timezone.utc).strftime('%Y%m%d-%H%M')}.csv"
    return Response(content=_csv(rows, headers), media_type="text/csv; charset=utf-8", headers={"Content-Disposition": f'attachment; filename="{name}"'})
