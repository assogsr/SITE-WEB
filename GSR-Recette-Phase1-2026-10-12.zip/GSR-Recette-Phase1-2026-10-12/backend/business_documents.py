"""Private, agency-scoped document versions. No file is exposed by a static URL."""
import base64
import binascii
import hashlib
import io
import secrets
import re
import uuid
import zipfile
from datetime import datetime, timezone, timedelta
from typing import Literal
from fastapi import APIRouter, Depends, HTTPException, Request, Response
from pydantic import BaseModel, Field, ConfigDict
from bson.binary import Binary
from auth import require_roles, log_action
from crm import scope
from transactions import run
from security import consume_limit
from auth import client_ip
from document_antivirus import scan_bytes, assert_clean, verify_available

router = APIRouter(prefix='/crm/documents')
_db = {}
MAX_SIZE = 8 * 1024 * 1024
allowed = require_roles('direction', 'responsable', 'accueil')

def init(database):
    _db['db'] = database

def database():
    return _db['db']

def now():
    return datetime.now(timezone.utc)

def public(doc):
    result = {k: v for k, v in doc.items() if k not in ('_id', 'links', 'revision')}
    if doc.get('versions'):
        result['current_version'] = doc['versions'][-1]['id']
        result['mime_type'] = doc['versions'][-1]['mime']
    return result

async def authorized_document(database, document_id, user, session=None):
    doc = await database.private_documents.find_one(scope(user, {'id': document_id, 'deleted': {'$ne': True}}), session=session)
    if not doc or (user['role'] != 'direction' and ((doc.get('permitted_users') and user['id'] not in doc['permitted_users']) or (doc.get('permitted_roles') and user['role'] not in doc['permitted_roles']))):
        raise HTTPException(404, 'Document introuvable ou non autorisé')
    return public(doc)

class Strict(BaseModel):
    model_config = ConfigDict(extra='forbid', str_strip_whitespace=True)

class Upload(Strict):
    filename: str = Field(min_length=1, max_length=160, pattern=r'^[^/\\\x00-\x1f]+$')
    content_base64: str = Field(min_length=1, max_length=11200000)
    mime: Literal['application/pdf', 'image/png', 'image/jpeg', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document']
    comment: str = Field(default='', max_length=1000)

class Create(Upload):
    title: str = Field(min_length=2, max_length=160)
    agency: Literal['creteil', 'bonneuil']
    category: str = Field(min_length=2, max_length=100)
    sensitivity: Literal['interne', 'confidentiel'] = 'confidentiel'
    permitted_users: list[str] = Field(default_factory=list, max_length=100)
    retention_until: str | None = None
    formation_id: str | None = None
    permitted_roles: list[Literal['responsable', 'accueil']] = Field(default_factory=list, max_length=2)

class Category(Strict):
    name: str = Field(min_length=2, max_length=100)
    retention_days: int | None = Field(default=None, ge=1, le=36500)

class Categories(Strict):
    categories: list[Category] = Field(max_length=100)

class Permissions(Strict):
    permitted_roles: list[Literal['responsable', 'accueil']] = Field(default_factory=list, max_length=2)
    permitted_users: list[str] = Field(max_length=100)
    sensitivity: Literal['interne', 'confidentiel']

class Review(Strict):
    decision: Literal['valide', 'rejete']
    note: str = Field(min_length=2, max_length=1000)

class Share(Strict):
    version_id: str
    minutes: int = Field(ge=1, le=1440)
    purpose: str = Field(min_length=2, max_length=500)

class Token(Strict):
    token: str = Field(min_length=43, max_length=100)

class Delete(Strict):
    confirmation: str
    reason: str = Field(min_length=2, max_length=500)

def decode(body):
    try:
        data = base64.b64decode(body.content_base64, validate=True)
    except (ValueError, binascii.Error):
        raise HTTPException(422, 'Contenu base64 invalide')
    if not data or len(data) > MAX_SIZE:
        raise HTTPException(413, 'Fichier vide ou supérieur à 8 Mio')
    ext = body.filename.rsplit('.', 1)[-1].lower()
    valid = False
    if body.mime == 'application/pdf':
        normalized = re.sub(rb'#([0-9A-Fa-f]{2})', lambda m: bytes([int(m[1], 16)]), data).lower()
        valid = ext == 'pdf' and data.startswith(b'%PDF-') and b'%%EOF' in data[-1024:] and not any(tag in normalized for tag in (b'/javascript', b'/js', b'/launch', b'/embeddedfile', b'/openaction', b'/aa', b'/richmedia', b'/xfa'))
    elif body.mime == 'image/png':
        valid = ext == 'png' and data.startswith(b'\x89PNG\r\n\x1a\n') and b'IEND' in data[-16:]
    elif body.mime == 'image/jpeg':
        valid = ext in ('jpg', 'jpeg') and data.startswith(b'\xff\xd8\xff') and data.endswith(b'\xff\xd9')
    elif ext == 'docx' and data.startswith(b'PK'):
        try:
            with zipfile.ZipFile(io.BytesIO(data)) as archive:
                entries = archive.infolist()
                names = {e.filename for e in entries}
                valid = (len(entries) <= 1000 and sum(e.file_size for e in entries) <= 32 * 1024 * 1024
                         and '[Content_Types].xml' in names and 'word/document.xml' in names
                         and all(not e.flag_bits & 1 and not e.filename.startswith('/') and '..' not in e.filename.split('/') for e in entries)
                         and not any('vbaproject' in n.lower() or n.lower().endswith(('.exe', '.js')) for n in names))
                if valid:
                    valid = not any(b'targetmode="external"' in archive.read(n).lower() or b'<!doctype' in archive.read(n).lower() for n in names if n.endswith(('.rels', '.xml')))
        except (zipfile.BadZipFile, RuntimeError, ValueError):
            valid = False
    if not valid:
        raise HTTPException(422, 'Format, extension ou contenu actif non autorisé')
    return data

async def validate_users(db, ids, agency, session=None):
    if len(set(ids)) != len(ids):
        raise HTTPException(422, 'Autorisations dupliquées')
    for uid in ids:
        u = await db.users.find_one({'id': uid, 'active': {'$ne': False}}, session=session)
        if not u or u.get('role') not in ('direction', 'responsable', 'accueil') or (u['role'] != 'direction' and u.get('agency') != agency):
            raise HTTPException(422, 'Utilisateur non habilité dans cette agence')

def version(body, user, data):
    return {'id': str(uuid.uuid4()), 'filename': body.filename, 'mime': body.mime, 'size': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'author_id': user['id'], 'author_name': user['name'], 'created_at': now().isoformat(), 'comment': body.comment, 'review_status': 'a_verifier', 'antivirus': {'status': 'pending'}}

@router.get('')
async def list_documents(user=Depends(allowed)):
    docs = await database().private_documents.find(scope(user, {'deleted': {'$ne': True}})).sort('updated_at', -1).to_list(500)
    return [public(d) for d in docs if user['role'] == 'direction' or ((not d.get('permitted_users') or user['id'] in d['permitted_users']) and (not d.get('permitted_roles') or user['role'] in d['permitted_roles']))]

@router.post('', status_code=201)
async def create(body: Create, request: Request, user=Depends(allowed)):
    if scope(user, {}) .get('agency', body.agency) != body.agency:
        raise HTTPException(403, 'Agence non autorisée')
    if user['role'] != 'direction' and (body.permitted_users or body.permitted_roles or body.retention_until):
        raise HTTPException(403, 'La Direction configure les permissions nominatives')
    if body.retention_until:
        try:
            datetime.strptime(body.retention_until, '%Y-%m-%d')
        except ValueError:
            raise HTTPException(422, 'Date de rétention invalide')
    data = decode(body)
    v = version(body, user, data)
    v['antivirus'] = await scan_bytes(data)
    doc = {'id': str(uuid.uuid4()), 'title': body.title, 'agency': body.agency, 'category': body.category, 'sensitivity': body.sensitivity, 'permitted_users': body.permitted_users, 'retention_until': body.retention_until, 'formation_id': body.formation_id, 'permitted_roles': body.permitted_roles, 'created_at': now().isoformat(), 'updated_at': now().isoformat(), 'versions': [v], 'history': [{'at': now().isoformat(), 'by': user['name'], 'action': 'creation'}], 'revision': 0}
    async def operation(session):
        await validate_users(database(), body.permitted_users, body.agency, session)
        if body.formation_id:
            course = await database().business_training_catalog.find_one({'id': body.formation_id}, session=session)
            if not course:
                raise HTTPException(422, 'Formation introuvable')
        settings = await database().site_settings.find_one({'_id': 'document_categories'}, session=session) or {}
        category = next((c for c in settings.get('categories', []) if c['name'] == body.category), {})
        if not doc['retention_until'] and category.get('retention_days'):
            doc['retention_until'] = (now() + timedelta(days=category['retention_days'])).date().isoformat()
        await database().private_documents.insert_one(doc, session=session)
        await database().private_document_data.insert_one({'id': v['id'], 'document_id': doc['id'], 'data': Binary(data)}, session=session)
        await log_action('document_create', request, user, doc['id'], {'version_id': v['id'], 'antivirus_status': v['antivirus']['status'], 'sha256': v['sha256'], 'engine': v['antivirus'].get('engine'), 'signature_version': v['antivirus'].get('signature_version')}, mongo_session=session)
    await run(database(), operation)
    return public(doc)

@router.get('/configuration/categories')
async def categories(user=Depends(allowed)):
    settings = await database().site_settings.find_one({'_id': 'document_categories'}) or {}
    return {'categories': settings.get('categories', [])}

@router.put('/configuration/categories')
async def configure_categories(body: Categories, request: Request, user=Depends(require_roles('direction'))):
    if len({c.name.casefold() for c in body.categories}) != len(body.categories):
        raise HTTPException(422, 'Catégories dupliquées')
    await database().site_settings.update_one({'_id': 'document_categories'}, {'$set': body.model_dump()}, upsert=True)
    await log_action('document_categories', request, user, meta={'count': len(body.categories)})
    return body.model_dump()

@router.get('/{document_id}')
async def detail(document_id: str, user=Depends(allowed)):
    return await authorized_document(database(), document_id, user)

@router.post('/{document_id}/versions', status_code=201)
async def add_version(document_id: str, body: Upload, request: Request, user=Depends(allowed)):
    data = decode(body)
    v = version(body, user, data)
    v['antivirus'] = await scan_bytes(data)
    async def operation(session):
        await authorized_document(database(), document_id, user, session)
        await database().private_documents.update_one({'id': document_id}, {'$push': {'versions': v, 'history': {'at': now().isoformat(), 'by': user['name'], 'action': 'version', 'version_id': v['id']}}, '$set': {'updated_at': now().isoformat()}, '$inc': {'revision': 1}}, session=session)
        await database().private_document_data.insert_one({'id': v['id'], 'document_id': document_id, 'data': Binary(data)}, session=session)
        await log_action('document_version', request, user, document_id, {'version_id': v['id'], 'antivirus_status': v['antivirus']['status'], 'sha256': v['sha256'], 'engine': v['antivirus'].get('engine'), 'signature_version': v['antivirus'].get('signature_version')}, mongo_session=session)
    await run(database(), operation)
    return v

@router.patch('/{document_id}/permissions')
async def permissions(document_id: str, body: Permissions, request: Request, user=Depends(require_roles('direction'))):
    async def operation(session):
        d = await authorized_document(database(), document_id, user, session)
        await validate_users(database(), body.permitted_users, d['agency'], session)
        await database().private_documents.update_one({'id': document_id}, {'$set': body.model_dump(), '$inc': {'revision': 1}, '$push': {'history': {'at': now().isoformat(), 'by': user['name'], 'action': 'permissions'}}}, session=session)
        await database().private_document_links.update_many({'document_id': document_id}, {'$set': {'revoked': True}}, session=session)
        await log_action('document_permissions', request, user, document_id, mongo_session=session)
    await run(database(), operation)
    return await authorized_document(database(), document_id, user)

@router.post('/{document_id}/versions/{version_id}/scan')
async def antivirus_scan(document_id: str, version_id: str, request: Request, user=Depends(require_roles('direction'))):
    d = await authorized_document(database(), document_id, user)
    v = next((v for v in d['versions'] if v['id'] == version_id), None)
    raw = await database().private_document_data.find_one({'id': version_id, 'document_id': document_id})
    if not v or not raw:
        raise HTTPException(404, 'Version introuvable')
    result = await scan_bytes(bytes(raw['data']))
    async def operation(session):
        fresh = await authorized_document(database(), document_id, user, session)
        current = next((v for v in fresh['versions'] if v['id'] == version_id), None)
        stored = await database().private_document_data.find_one({'id': version_id, 'document_id': document_id}, session=session)
        if not current or not stored or current['sha256'] != result['sha256'] or hashlib.sha256(bytes(stored['data'])).hexdigest() != result['sha256']:
            raise HTTPException(409, 'La version ne correspond plus au fichier analysé')
        await database().private_documents.update_one({'id': document_id, 'versions.id': version_id}, {'$set': {'versions.$.antivirus': result}, '$inc': {'revision': 1}, '$push': {'history': {'at': now().isoformat(), 'by': user['name'], 'action': 'antivirus', 'version_id': version_id, 'status': result['status']}}}, session=session)
        if result['status'] != 'clean':
            await database().private_document_links.update_many({'document_id': document_id, 'version_id': version_id}, {'$set': {'revoked': True}}, session=session)
        await log_action('document_antivirus', request, user, document_id, {'version_id': version_id, 'status': result['status'], 'sha256': result['sha256'], 'engine': result.get('engine'), 'signature_version': result.get('signature_version')}, mongo_session=session)
    await run(database(), operation)
    return result

@router.post('/{document_id}/versions/{version_id}/review')
async def review(document_id: str, version_id: str, body: Review, request: Request, user=Depends(require_roles('direction'))):
    async def operation(session):
        await authorized_document(database(), document_id, user, session)
        result = await database().private_documents.update_one({'id': document_id, 'versions.id': version_id}, {'$set': {'versions.$.review_status': body.decision, 'versions.$.review_note': body.note, 'versions.$.reviewed_by': user['name']}, '$inc': {'revision': 1}}, session=session)
        if not result.matched_count:
            raise HTTPException(404, 'Version introuvable')
        if body.decision == 'rejete':
            await database().private_document_links.update_many({'document_id': document_id, 'version_id': version_id}, {'$set': {'revoked': True}}, session=session)
        await log_action('document_review', request, user, document_id, {'version_id': version_id, 'decision': body.decision}, mongo_session=session)
    await run(database(), operation)
    return {'status': body.decision, 'verification': 'humaine', 'antivirus_required': True}

async def download(doc, version_id):
    v = next((v for v in doc['versions'] if v['id'] == version_id), None)
    if not v:
        raise HTTPException(404, 'Version introuvable')
    if v['review_status'] != 'valide':
        raise HTTPException(409, 'Validation humaine Direction requise')
    assert_clean(v)
    await verify_available(v)
    raw = await database().private_document_data.find_one({'id': version_id, 'document_id': doc['id']})
    if not raw:
        raise HTTPException(404, 'Contenu introuvable')
    assert_clean(v, bytes(raw['data']))
    return Response(bytes(raw['data']), media_type=v['mime'], headers={'Content-Disposition': "attachment; filename*=UTF-8''" + __import__('urllib.parse', fromlist=['quote']).quote(v['filename']), 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', 'Content-Security-Policy': "default-src 'none'; sandbox"})

@router.get('/{document_id}/versions/{version_id}/download')
async def authenticated_download(document_id: str, version_id: str, request: Request, user=Depends(allowed)):
    doc = await authorized_document(database(), document_id, user)
    response = await download(doc, version_id)
    await log_action('document_download', request, user, document_id, {'version_id': version_id})
    return response

@router.post('/{document_id}/links', status_code=201)
async def share(document_id: str, body: Share, request: Request, user=Depends(require_roles('direction'))):
    d = await authorized_document(database(), document_id, user)
    v = next((v for v in d['versions'] if v['id'] == body.version_id), None)
    if v:
        await verify_available(v)
    token = secrets.token_urlsafe(32)
    item = {'id': str(uuid.uuid4()), 'document_id': document_id, 'version_id': body.version_id, 'token_hash': hashlib.sha256(token.encode()).hexdigest(), 'expires_at': (now() + timedelta(minutes=body.minutes)).isoformat(), 'revoked': False, 'purpose': body.purpose, 'created_by': user['id'], 'created_at': now().isoformat()}
    async def operation(session):
        d = await authorized_document(database(), document_id, user, session)
        v = next((v for v in d['versions'] if v['id'] == body.version_id), None)
        if d['sensitivity'] != 'interne':
            raise HTTPException(409, 'Les documents confidentiels ne peuvent pas être partagés par lien')
        if not v or v['review_status'] != 'valide':
            raise HTTPException(409, 'Version validée par la Direction requise')
        assert_clean(v)
        await database().private_documents.update_one({'id': document_id}, {'$inc': {'revision': 1}}, session=session)
        await database().private_document_links.insert_one(item, session=session)
        await log_action('document_share', request, user, document_id, {'link_id': item['id'], 'expires_at': item['expires_at']}, mongo_session=session)
    await run(database(), operation)
    return {'id': item['id'], 'token': token, 'expires_at': item['expires_at'], 'url': '/documents/partage#' + token}

@router.get('/{document_id}/links')
async def links(document_id: str, user=Depends(require_roles('direction'))):
    await authorized_document(database(), document_id, user)
    return await database().private_document_links.find({'document_id': document_id}, {'_id': 0, 'token_hash': 0}).to_list(100)

@router.delete('/{document_id}/links/{link_id}')
async def revoke(document_id: str, link_id: str, request: Request, user=Depends(require_roles('direction'))):
    await authorized_document(database(), document_id, user)
    result = await database().private_document_links.update_one({'id': link_id, 'document_id': document_id}, {'$set': {'revoked': True}})
    if not result.matched_count:
        raise HTTPException(404, 'Lien introuvable')
    await log_action('document_link_revoke', request, user, document_id, {'link_id': link_id})
    return {'revoked': True}

@router.post('/shared/download')
async def shared_download(body: Token, request: Request):
    await consume_limit(database(), 'document-shared', client_ip(request), 60, 600)
    item = await database().private_document_links.find_one({'token_hash': hashlib.sha256(body.token.encode()).hexdigest(), 'revoked': False, 'expires_at': {'$gt': now().isoformat()}})
    if not item:
        raise HTTPException(404, 'Lien expiré, révoqué ou invalide')
    d = await database().private_documents.find_one({'id': item['document_id'], 'deleted': {'$ne': True}, 'sensitivity': 'interne'})
    if not d:
        raise HTTPException(404, 'Document non partageable')
    response = await download(d, item['version_id'])
    await log_action('document_shared_download', request, target=d['id'], meta={'link_id': item['id']})
    return response

@router.delete('/{document_id}')
async def delete(document_id: str, body: Delete, request: Request, user=Depends(require_roles('direction'))):
    async def operation(session):
        await authorized_document(database(), document_id, user, session)
        if body.confirmation != document_id:
            raise HTTPException(422, 'Confirmation du document requise')
        # Protect references in all independent phase-1 modules, not just one parent.
        for collection in ('editorial_media', 'prospect_document_links', 'business_organizations', 'business_interventions', 'business_road_safety', 'solidarity_devices', 'solidarity_applications', 'business_training_catalog', 'business_training_people', 'business_training_sessions', 'business_training_enrollments', 'business_speakers', 'business_resources', 'business_deadlines', 'demandes'):
            if await database()[collection].find_one({'$or': [{'sequences.document_id': document_id}, {'document_ids': document_id}, {'document_id': document_id}, {'documents': document_id}, {'document_checks.document_id': document_id}, {'maintenance_events.document_id': document_id}, {'quote_document_id': document_id}, {'steps.document_ids': document_id}, {'convention_document_ids': document_id}, {'result_document_id': document_id}, {'documents.document_id': document_id}, {'document_requirements.document_id': document_id}]}, session=session):
                raise HTTPException(409, 'Document lié à un dossier métier : retirer sa référence avant suppression')
        requirement_query = {'$expr': {'$in': [document_id, {'$map': {'input': {'$objectToArray': {'$cond': [{'$eq': [{'$type': '$document_requirements'}, 'object']}, '$document_requirements', {}]}}, 'as': 'entry', 'in': '$$entry.v'}}]}}
        if await database().business_training_enrollments.find_one(requirement_query, session=session):
            raise HTTPException(409, 'Document lié à une exigence de formation : retirer sa référence avant suppression')
        await database().private_document_data.delete_many({'document_id': document_id}, session=session)
        await database().private_document_links.delete_many({'document_id': document_id}, session=session)
        await database().private_documents.delete_one({'id': document_id}, session=session)
        await log_action('document_delete', request, user, document_id, {'reason': body.reason}, mongo_session=session)
    await run(database(), operation)
    return {'deleted': True}
