"""WhatsApp settings isolated from CRM features; no default contact numbers."""
import re
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, Request, Response
from pydantic import BaseModel, ConfigDict, Field, field_validator

from auth import log_action, require_roles

router = APIRouter()
_db = {}
AGENCIES = (('creteil', 'Créteil'), ('bonneuil', 'Bonneuil-sur-Marne'))


def init(database):
    _db['db'] = database


def normalize_number(value):
    if value is None or value.strip() == '':
        return None
    value = value.strip()
    if not re.fullmatch(r'\+?[0-9 ()-]+', value):
        raise ValueError('Utilisez un numéro international avec son indicatif, sans texte ni lien.')
    digits = re.sub(r'[ ()-]', '', value).lstrip('+')
    if not re.fullmatch(r'[1-9][0-9]{7,14}', digits):
        raise ValueError('Le numéro international doit contenir de 8 à 15 chiffres, sans zéro initial.')
    return '+' + digits


class WhatsAppPatch(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True)
    creteil: str | None = Field(default=None, max_length=32)
    bonneuil: str | None = Field(default=None, max_length=32)

    @field_validator('creteil', 'bonneuil')
    @classmethod
    def valid_number(cls, value):
        return normalize_number(value)


async def numbers():
    doc = await _db['db'].site_settings.find_one({'_id': 'whatsapp'})
    stored = (doc or {}).get('numbers', {})
    if not isinstance(stored, dict):
        stored = {}
    result = {}
    for agency, _ in AGENCIES:
        try:
            result[agency] = normalize_number(stored.get(agency))
        except (ValueError, AttributeError, TypeError):
            result[agency] = None  # Fail closed for invalid historical/manual configuration.
    return result


@router.get('/contact/whatsapp')
async def public_whatsapp(response: Response):
    response.headers['Cache-Control'] = 'no-store'
    configured = await numbers()
    return {'agencies': [
        {'id': agency, 'label': label,
         'url': 'https://wa.me/' + configured[agency][1:] if configured[agency] else None}
        for agency, label in AGENCIES
    ]}


@router.get('/administration/whatsapp')
async def get_settings(response: Response, user=Depends(require_roles('direction'))):
    response.headers['Cache-Control'] = 'no-store'
    return await numbers()


@router.patch('/administration/whatsapp')
async def update_settings(body: WhatsAppPatch, request: Request, response: Response,
                          user=Depends(require_roles('direction'))):
    response.headers['Cache-Control'] = 'no-store'
    changes = body.model_dump(exclude_unset=True)
    if changes:
        await _db['db'].site_settings.update_one({'_id': 'whatsapp'}, {'$set': {
            **{'numbers.' + key: value for key, value in changes.items()},
            'updated_at': datetime.now(timezone.utc).isoformat(), 'updated_by': user['id'],
        }}, upsert=True)
        await log_action('whatsapp_settings_updated', request, user, target='whatsapp',
                         meta={'agencies': sorted(changes),
                               'enabled': {key: bool(value) for key, value in changes.items()}})
    return await numbers()
