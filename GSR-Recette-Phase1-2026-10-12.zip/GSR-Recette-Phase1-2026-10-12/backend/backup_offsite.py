"""Explicit offsite transport of already encrypted archives; never enabled by default."""
import argparse
import hashlib
import os
import re
import shutil
import subprocess
import tempfile
from pathlib import Path

MAGIC = b'GSR-BACKUP-1\n'


def digest(path):
    result = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            result.update(chunk)
    return result.hexdigest()


def config():
    if os.environ.get('GSR_OFFSITE_ENABLED') != 'true':
        raise ValueError('Copie extérieure désactivée ; configuration GSR requise')
    host = os.environ.get('GSR_OFFSITE_HOST', '')
    user = os.environ.get('GSR_OFFSITE_USER', '')
    directory = os.environ.get('GSR_OFFSITE_DIRECTORY', '')
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9.-]*', host) or not re.fullmatch(r'[A-Za-z0-9_][A-Za-z0-9_-]*', user):
        raise ValueError('Hôte ou utilisateur extérieur invalide')
    if not re.fullmatch(r'/[A-Za-z0-9_/-]+', directory) or '..' in directory.split('/'):
        raise ValueError('Répertoire extérieur invalide')
    port = int(os.environ.get('GSR_OFFSITE_PORT', '22'))
    if not 1 <= port <= 65535:
        raise ValueError('Port extérieur invalide')
    key = Path(os.environ['GSR_OFFSITE_SSH_KEY_FILE']).resolve()
    known = Path(os.environ['GSR_OFFSITE_KNOWN_HOSTS_FILE']).resolve()
    if not key.is_file() or key.stat().st_mode & 0o077 or not known.is_file() or not known.stat().st_size:
        raise ValueError('Clé privée protégée et empreinte SSH vérifiée requises')
    return ['sftp', '-q', '-b', '-', '-P', str(port), '-i', str(key),
            '-oBatchMode=yes', '-oIdentitiesOnly=yes', '-oStrictHostKeyChecking=yes',
            '-oUserKnownHostsFile=' + str(known), '-oConnectTimeout=20', user + '@' + host], directory.rstrip('/')


def transfer(commands):
    argv, _ = config()
    result = subprocess.run(argv, input=commands, text=True, stdout=subprocess.DEVNULL,
                            stderr=subprocess.PIPE, timeout=3600)
    if result.returncode:
        # SSH errors can contain addresses or credentials; keep them out of public logs.
        raise RuntimeError('Échec du transfert extérieur ; vérifier le service et ses habilitations')


def valid_name(name):
    if not re.fullmatch(r'[A-Za-z0-9_-]+\.gsrbackup', name):
        raise ValueError('Nom de sauvegarde invalide')
    return name


def upload(source):
    _, directory = config()
    source = Path(source)
    valid_name(source.name)
    with source.open('rb') as stream:
        if stream.read(len(MAGIC)) != MAGIC or source.stat().st_size <= len(MAGIC) + 32:
            raise ValueError('Seules les archives chiffrées GSR sont exportables')
    original = digest(source)
    # Copy to private fixed local names: user-controlled paths never become SFTP commands.
    with tempfile.TemporaryDirectory(prefix='gsr-offsite-') as temp:
        local = Path(temp) / 'archive'; verify = Path(temp) / 'verified'
        shutil.copyfile(source, local); local.chmod(0o600)
        if digest(local) != original:
            raise ValueError('Archive source modifiée pendant la préparation')
        remote = directory + '/' + source.name
        transfer(f'put {local} {remote}.partial\nget {remote}.partial {verify}\n')
        if digest(verify) != original:
            raise ValueError('Copie distante différente ; archive non publiée')
        transfer(f'rename {remote}.partial {remote}\n')
    return original


def download(name, destination):
    _, directory = config()
    valid_name(name)
    destination = Path(destination)
    if destination.exists():
        raise ValueError('Écrasement du fichier local refusé')
    with tempfile.TemporaryDirectory(prefix='gsr-offsite-') as temp:
        local = Path(temp) / 'archive'
        transfer(f'get {directory}/{name} {local}\n')
        with local.open('rb') as stream:
            if stream.read(len(MAGIC)) != MAGIC:
                raise ValueError('Archive extérieure invalide')
        fd = os.open(destination, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, 'wb') as output, local.open('rb') as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b''):
                output.write(chunk)
    # Authenticity/HMAC is checked by backup.restore before any database write.
    return digest(destination)


def main():
    os.umask(0o077)
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['upload', 'download'])
    parser.add_argument('source')
    parser.add_argument('destination', nargs='?')
    args = parser.parse_args()
    try:
        if args.action == 'upload':
            upload(args.source)
        else:
            if not args.destination:
                parser.error('destination locale requise')
            download(args.source, args.destination)
    except Exception:
        parser.exit(1, 'Copie extérieure non validée ; consulter la configuration sécurisée.\n')
    print('Transfert chiffré vérifié ; aucune clé de déchiffrement transférée.')


if __name__ == '__main__':
    main()
