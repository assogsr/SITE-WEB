"""Private, idempotent business notifications; no SMTP credentials or document payloads."""
from datetime import datetime,timezone,timedelta
from fastapi import APIRouter,Depends,HTTPException
from auth import require_roles
router=APIRouter(prefix='/crm/notifications');_db={}
def init(db):_db['db']=db
async def record(db,d,kind,key,session=None,recipient=None):
    await db.internal_notifications.update_one({'_id':key},{'$setOnInsert':{'id':key,'agency':d['agency'],'demande_id':d['id'],'reference':d['reference'],'kind':kind,'recipient_id':recipient,'created_at':datetime.now(timezone.utc).isoformat()}},upsert=True,session=session)
async def assignment(db,d,key,session=None):
    if d.get('assigned_to'):await record(db,d,'affectation',key,session,d['assigned_to'])
async def intervention_alerts(db,instant=None):
    instant=instant or datetime.now(timezone.utc)
    from notifications import queue
    async for d in db.demandes.find({'type':'intervention','archived':{'$ne':True},'first_response_at':{'$in':[None,'']},'created_at':{'$lte':(instant-timedelta(days=1)).isoformat()},'status':{'$in':['nouveau','en_cours']}}):
        await record(db,d,'intervention_j1',d['id']+':intervention-j1')
        await queue(db,d,'intervention-j1',d['id']+':intervention-j1',extra={'demande_id':d['id']})
def query(user):
    f={} if user['role']=='direction' else {'agency':user['agency'],'$or':[{'recipient_id':None},{'recipient_id':user['id']}]}
    return f
@router.get('')
async def listing(user=Depends(require_roles('direction','responsable','accueil'))):
    rows=await _db['db'].internal_notifications.find(query(user),{'_id':0}).sort('created_at',-1).to_list(200)
    read={r['notification_id'] async for r in _db['db'].notification_reads.find({'user_id':user['id']})}
    for row in rows:row['read']=row['id'] in read
    return rows
@router.post('/{nid}/lue')
async def read(nid:str,user=Depends(require_roles('direction','responsable','accueil'))):
    if not await _db['db'].internal_notifications.find_one({**query(user),'id':nid}):raise HTTPException(404,'Notification introuvable')
    await _db['db'].notification_reads.update_one({'_id':user['id']+':'+nid},{'$setOnInsert':{'user_id':user['id'],'notification_id':nid,'at':datetime.now(timezone.utc).isoformat()}},upsert=True)
    return {'ok':True}
