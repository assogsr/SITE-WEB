import uuid
from datetime import datetime, timezone, date
from typing import Optional, Literal
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field, ConfigDict, field_validator
from auth import get_current_user, log_action
from crm import scope
from transactions import run

_db = {}
def init(database): _db["db"] = database
def db(): return _db["db"]
def now(): return datetime.now(timezone.utc).isoformat()
def direction(user):
    if user["role"] != "direction": raise HTTPException(403, "Validation réservée à la Direction")
def instant(value):
    try:
        parsed = value if isinstance(value,datetime) else datetime.fromisoformat(value.replace("Z", "+00:00"))
        if parsed.tzinfo is None: raise ValueError()
        return parsed.astimezone(timezone.utc)
    except (ValueError, AttributeError): raise HTTPException(422, "Date et heure avec fuseau requises")
async def documents(ids, user, agency, session=None):
    if not ids: return
    from business_documents import authorized_document
    for identifier in ids:
        item=await authorized_document(db(), identifier, user,session=session)
        if item.get("agency") != agency: raise HTTPException(422,"Justificatif d’une autre agence non autorisé")
        await db().private_documents.update_one({"id":identifier},{"$inc":{"revision":1}},session=session)
async def get_record(identifier, user, session=None):
    result = await db()[COLLECTION].find_one(scope(user, {"id":identifier}), {"_id":0},session=session)
    if not result: raise HTTPException(404,"Fiche introuvable")
    return result
class Availability(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)
    start: str
    end: str
    available: bool
    note: str = Field(default="", max_length=1000)
    @field_validator("end")
    @classmethod
    def end_time(cls, value, info):
        if "start" not in info.data: return value
        if instant(value) <= instant(info.data["start"]): raise ValueError("Fin postérieure au début requise")
        return value

def availability_conflicts(record, start, end):
    start, end = instant(start), instant(end)
    return [item for item in record.get("availability", []) if not item["available"] and instant(item["start"]) < end and instant(item["end"]) > start]

COLLECTION="business_resources"
router=APIRouter(prefix="/crm/equipements",tags=["Équipements"])
class Maintenance(BaseModel):
    model_config=ConfigDict(extra="forbid",str_strip_whitespace=True)
    date: date
    description: str=Field(min_length=2,max_length=2000)
    document_id: Optional[str]=Field(default=None,max_length=100)
class Record(BaseModel):
    model_config=ConfigDict(extra="forbid",str_strip_whitespace=True)
    agency: Literal["creteil","bonneuil"]
    name: str=Field(min_length=2,max_length=160)
    kind: Literal["salle","vehicule","simulateur","materiel"]
    state: Literal["disponible","indisponible","immobilise"]="disponible"
    availability: list[Availability]=Field(default_factory=list,max_length=200)
    maintenance_events: list[Maintenance]=Field(default_factory=list,max_length=200)
    document_ids: list[str]=Field(default_factory=list,max_length=100)
    notes: str=Field(default="",max_length=4000)
async def validate_record(body,user,session=None):
    await documents(body.document_ids+[event.document_id for event in body.maintenance_events if event.document_id],user,body.agency,session)

@router.get("")
async def list_records(user=Depends(get_current_user)):
    return await db()[COLLECTION].find(scope(user, {}), {"_id":0}).sort("name",1).to_list(1000)
@router.post("", status_code=201)
async def create(body: Record, user=Depends(get_current_user)):
    scope(user,{})
    if user["role"] != "direction" and body.agency != user.get("agency"): raise HTTPException(403,"Agence non autorisée")
    async def operation(session):
        await validate_record(body,user,session)
        item=body.model_dump(mode="json")
        item.update(id=str(uuid.uuid4()),created_at=now(),updated_at=now(),history=[{"at":now(),"actor":user["id"],"event":"creation"}])
        await db()[COLLECTION].insert_one(dict(item),session=session)
        await log_action(COLLECTION+"_create",user=user,target=item["id"],mongo_session=session)
        return item
    return await run(db(),operation)
@router.get("/{identifier}")
async def read(identifier: str,user=Depends(get_current_user)): return await get_record(identifier,user)
@router.put("/{identifier}")
async def update(identifier: str,body: Record,user=Depends(get_current_user)):
    async def operation(session):
        item=await get_record(identifier,user,session)
        if body.agency != item["agency"]: raise HTTPException(409,"Réaffectation d’agence non prévue : créer une demande à la Direction")
        await validate_record(body,user,session)
        updated=body.model_dump(mode="json");updated.update(updated_at=now())
        await db()[COLLECTION].update_one(scope(user,{"id":identifier}),{"$set":updated,"$push":{"history":{"at":now(),"actor":user["id"],"event":"modification"}}},session=session)
        await log_action(COLLECTION+"_update",user=user,target=identifier,mongo_session=session)
        return await get_record(identifier,user,session)
    return await run(db(),operation)
