"""Real MongoDB transactions: never fall back to a non-atomic write."""
import logging

from fastapi import HTTPException
from pymongo.errors import OperationFailure
from pymongo.read_concern import ReadConcern
from pymongo.write_concern import WriteConcern


async def run(database, operation):
    async with await database.client.start_session() as session:
        try:
            return await session.with_transaction(
                operation, read_concern=ReadConcern('snapshot'),
                write_concern=WriteConcern('majority'))
        except OperationFailure as error:
            if error.code == 20:
                logging.getLogger(__name__).error('MongoDB transaction support is required')
                raise HTTPException(503, 'Le service de réservation nécessite la configuration transactionnelle MongoDB.') from error
            raise
