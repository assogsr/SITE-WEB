"""Fail-closed private ClamAV INSTREAM client. No HTTP upload or public file service."""
import asyncio
import hashlib
import ipaddress
import os
import re
import socket
import struct
import stat
import time
from datetime import datetime, timezone, timedelta
from fastapi import HTTPException

class AntivirusUnavailable(Exception):
    """Sanitized failure: addresses, file bytes and raw daemon responses are never returned."""

def _number(name, default, minimum, maximum):
    try:
        value = float(os.environ.get(name, default))
        if not minimum <= value <= maximum:
            raise ValueError()
        return value
    except (TypeError, ValueError):
        raise AntivirusUnavailable('Configuration antivirus invalide')

def enabled():
    return os.environ.get('GSR_CLAMAV_ENABLED', 'false').lower() == 'true'

def _private(address):
    address = ipaddress.ip_address(address.split('%')[0])
    ranges = ('127.0.0.0/8', '10.0.0.0/8', '172.16.0.0/12', '192.168.0.0/16') if address.version == 4 else ('::1/128', 'fc00::/7')
    return any(address in ipaddress.ip_network(network) for network in ranges)

def _connect(deadline):
    unix = os.environ.get('GSR_CLAMAV_UNIX_SOCKET')
    if unix:
        if not os.path.isabs(unix) or '\x00' in unix:
            raise AntivirusUnavailable('Socket antivirus invalide')
        info = os.stat(unix)
        if not stat.S_ISSOCK(info.st_mode) or info.st_mode & 0o007:
            raise AntivirusUnavailable('Le socket antivirus doit être privé')
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        endpoint = unix
    else:
        host = os.environ.get('GSR_CLAMAV_HOST', 'clamav')
        port = int(_number('GSR_CLAMAV_PORT', '3310', 1, 65535))
        addresses = socket.getaddrinfo(host, port, type=socket.SOCK_STREAM)
        if not addresses or any(not _private(addr[4][0]) for addr in addresses):
            raise AntivirusUnavailable('Le moteur antivirus doit être privé')
        family, kind, proto, _, endpoint = addresses[0]
        sock = socket.socket(family, kind, proto)
    try:
        sock.settimeout(max(.01, deadline - time.monotonic()))
        sock.connect(endpoint)
        return sock
    except Exception:
        sock.close()
        raise

def _send(sock, data, deadline):
    remaining = deadline - time.monotonic()
    if remaining <= 0:
        raise AntivirusUnavailable('Délai antivirus dépassé')
    sock.settimeout(remaining)
    sock.sendall(data)

def _reply(sock, deadline):
    reply = bytearray()
    while len(reply) <= 4096:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise AntivirusUnavailable('Délai antivirus dépassé')
        sock.settimeout(remaining)
        chunk = sock.recv(512)
        if not chunk:
            break
        reply.extend(chunk)
        if b'\x00' in chunk:
            break
    if len(reply) > 4096 or not reply.endswith(b'\x00'):
        raise AntivirusUnavailable('Réponse antivirus invalide')
    try:
        return bytes(reply[:-1]).decode('ascii', errors='strict')
    except UnicodeDecodeError:
        raise AntivirusUnavailable('Réponse antivirus invalide')

def _version(deadline):
    with _connect(deadline) as sock:
        _send(sock, b'zVERSION\x00', deadline)
        response = _reply(sock, deadline)
    match = re.fullmatch(r'ClamAV ([A-Za-z0-9._-]{1,50})/(\d{1,12})/([^\r\n]{1,100})', response)
    if not match:
        raise AntivirusUnavailable('Signatures antivirus non vérifiables')
    try:
        stamp = datetime.strptime(match[3], '%a %b %d %H:%M:%S %Y').replace(tzinfo=timezone.utc)
    except ValueError:
        raise AntivirusUnavailable('Date des signatures antivirus invalide')
    age = datetime.now(timezone.utc) - stamp
    maximum = _number('GSR_CLAMAV_SIGNATURE_MAX_AGE_HOURS', '48', 1, 168)
    if age < timedelta(minutes=-5) or age > timedelta(hours=maximum):
        raise AntivirusUnavailable('Signatures antivirus périmées')
    return {'engine': 'ClamAV ' + match[1], 'signature_version': match[2], 'signature_date': stamp.isoformat()}

def _scan_sync(data):
    if not enabled():
        raise AntivirusUnavailable('Antivirus désactivé : fichier en quarantaine')
    deadline = time.monotonic() + _number('GSR_CLAMAV_TIMEOUT_SECONDS', '15', .1, 120)
    version = _version(deadline)
    with _connect(deadline) as sock:
        _send(sock, b'zINSTREAM\x00', deadline)
        for start in range(0, len(data), 65536):
            chunk = data[start:start + 65536]
            _send(sock, struct.pack('!I', len(chunk)) + chunk, deadline)
        _send(sock, b'\x00\x00\x00\x00', deadline)
        result = _reply(sock, deadline)
    if result == 'stream: OK':
        status = 'clean'
    elif re.fullmatch(r'stream: [A-Za-z0-9_.: ()/-]{1,150} FOUND', result):
        status = 'infected'
    else:
        raise AntivirusUnavailable('Analyse antivirus incomplète')
    return {**version, 'status': status, 'sha256': hashlib.sha256(data).hexdigest(), 'scanned_at': datetime.now(timezone.utc).isoformat()}

async def scan_bytes(data):
    """Return a persisted quarantine verdict; failures never unlock a document."""
    digest = hashlib.sha256(data).hexdigest()
    try:
        if len(data) > 8 * 1024 * 1024:
            raise AntivirusUnavailable('Fichier supérieur à la limite antivirus')
        timeout = _number('GSR_CLAMAV_TIMEOUT_SECONDS', '15', .1, 120)
        return await asyncio.wait_for(asyncio.to_thread(_scan_sync, data), timeout=timeout + 1)
    except (AntivirusUnavailable, OSError, ValueError, asyncio.TimeoutError):
        return {'status': 'unavailable', 'sha256': digest, 'scanned_at': datetime.now(timezone.utc).isoformat(), 'reason': 'Analyse indisponible ou signatures non vérifiables ; quarantaine maintenue'}

def assert_clean(version, data=None):
    """Legacy scans, unavailable engines, stale signatures or changed bytes fail closed."""
    scan = version.get('antivirus') or {}
    try:
        if not enabled() or scan.get('status') != 'clean' or scan.get('sha256') != version.get('sha256'):
            raise AntivirusUnavailable()
        if data is not None and hashlib.sha256(data).hexdigest() != scan['sha256']:
            raise AntivirusUnavailable()
        current = datetime.now(timezone.utc)
        for key, env, default, maximum in (('signature_date', 'GSR_CLAMAV_SIGNATURE_MAX_AGE_HOURS', '48', 168), ('scanned_at', 'GSR_CLAMAV_SCAN_MAX_AGE_HOURS', '24', 168)):
            stamp = datetime.fromisoformat(scan[key])
            if stamp.tzinfo is None:
                raise AntivirusUnavailable()
            age = current - stamp
            if age < timedelta(minutes=-5) or age > timedelta(hours=_number(env, default, 1, maximum)):
                raise AntivirusUnavailable()
        if not scan.get('engine') or not scan.get('signature_version'):
            raise AntivirusUnavailable()
    except (AntivirusUnavailable, ValueError, TypeError, KeyError):
        raise HTTPException(409, 'Document en quarantaine : analyse antivirus saine et récente requise')

async def verify_available(version):
    """A current private daemon and current signatures are also required to release bytes."""
    assert_clean(version)
    try:
        timeout = _number('GSR_CLAMAV_TIMEOUT_SECONDS', '15', .1, 120)
        await asyncio.wait_for(asyncio.to_thread(_version, time.monotonic() + timeout), timeout=timeout + 1)
    except (AntivirusUnavailable, OSError, ValueError, asyncio.TimeoutError):
        raise HTTPException(503, 'Moteur antivirus indisponible : quarantaine maintenue')
