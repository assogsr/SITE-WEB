"""Encrypted local MongoDB backups; restore only to a fresh fictitious test database."""
import argparse
import hashlib
import hmac
import os
import secrets
import json
import subprocess
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path

from pymongo import MongoClient

MAGIC = b'GSR-BACKUP-1\n'


def key_file(create=True):
    path = Path(os.environ.get('GSR_BACKUP_KEY_FILE', '/backup-key/passphrase'))
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists() and not create:
        raise ValueError("Clé de restauration manquante")
    if not path.exists():
        fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        with os.fdopen(fd, 'wb') as output:
            output.write(secrets.token_hex(48).encode())
    if len(path.read_bytes()) < 48:
        raise ValueError('Clé de sauvegarde invalide')
    return path


def tag(path, key):
    digest = hmac.new(hashlib.sha256(b'GSR-HMAC-v1\0'+key.read_bytes()).digest(), digestmod='sha256')
    with path.open('rb') as data:
        while chunk := data.read(1024 * 1024):
            digest.update(chunk)
    return digest.digest()


def execute(command):
    environment = os.environ.copy()
    if command[0] in ('mongodump','mongorestore'):
        environment['LD_LIBRARY_PATH'] = '/opt/mongo-tools/lib'
    result = subprocess.run(command, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, env=environment)
    if result.returncode:
        # Tools may include connection details in stderr. Never echo them.
        raise RuntimeError('Échec de l’opération de sauvegarde/restauration')


def envelope(source, destination, key):
    with destination.open('xb') as output, source.open('rb') as data:
        output.write(MAGIC + tag(source, key))
        while chunk := data.read(1024 * 1024):
            output.write(chunk)
    destination.chmod(0o600)


def backup():
    directory = Path(os.environ.get('GSR_BACKUP_DIR', '/backups'))
    directory.mkdir(parents=True, exist_ok=True)
    database = os.environ['DB_NAME']
    uri = os.environ['MONGO_URL']
    key = key_file()
    with tempfile.TemporaryDirectory(prefix='gsr-backup-') as temporary:
        tmp = Path(temporary)
        config = tmp/'mongo.yml'
        # JSON is valid YAML; sensitive URI goes in a private file, never argv.
        import json
        config.write_text(json.dumps({'uri':uri})); config.chmod(0o600)
        archive = tmp/'database.gz'
        encrypted = tmp/'encrypted'
        # Refuse a mixed-time dump if any write occurred while it was captured.
        # Busy deployments need provider snapshots/oplog restoration, not a false success.
        with MongoClient(uri) as client:
            for attempt in range(3):
                if not client.admin.command('hello').get('setName'):
                    raise RuntimeError('MongoDB transactionnel requis pour la sauvegarde')
                before=client.local['oplog.rs'].find_one(sort=[('$natural',-1)])
                execute(['mongodump','--config',str(config),'--db',database,'--archive='+str(archive),'--gzip'])
                after=client.local['oplog.rs'].find_one(sort=[('$natural',-1)])
                if before and after and before['ts']==after['ts']:break
                if attempt==2:raise RuntimeError('Base active : sauvegarde cohérente non obtenue')
                time.sleep(1)
        execute(['openssl','enc','-aes-256-cbc','-pbkdf2','-iter','200000','-salt',
                 '-pass','file:'+str(key),'-in',str(archive),'-out',str(encrypted)])
        filename = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S')+'-'+secrets.token_hex(4)+'.gsrbackup'
        destination = directory/filename
        envelope(encrypted,destination,key)
        return destination


def restore(source, target):
    if not target.startswith('gsr_restore_test_') or target == os.environ['DB_NAME']:
        raise ValueError('La restauration exige une nouvelle base gsr_restore_test_*')
    key = key_file(create=False)
    with MongoClient(os.environ['MONGO_URL']) as client:
        if target in client.list_database_names():
            raise ValueError('La base cible existe déjà : restauration refusée')
    with tempfile.TemporaryDirectory(prefix='gsr-restore-') as temporary:
        tmp = Path(temporary); encrypted = tmp/'encrypted'; archive = tmp/'database.gz'
        with Path(source).open('rb') as data:
            if data.read(len(MAGIC)) != MAGIC:
                raise ValueError('Format de sauvegarde invalide')
            expected = data.read(32)
            with encrypted.open('wb') as output:
                while chunk := data.read(1024*1024): output.write(chunk)
        if not hmac.compare_digest(expected,tag(encrypted,key)):
            raise ValueError('Intégrité de sauvegarde invalide ; restauration refusée')
        execute(['openssl','enc','-d','-aes-256-cbc','-pbkdf2','-iter','200000',
                 '-pass','file:'+str(key),'-in',str(encrypted),'-out',str(archive)])
        import json
        config=tmp/'mongo.yml';config.write_text(json.dumps({'uri':os.environ['MONGO_URL']}));config.chmod(0o600)
        execute(['mongorestore','--config',str(config),'--archive='+str(archive),'--gzip',
                 '--nsFrom',os.environ['DB_NAME']+'.*','--nsTo',target+'.*'])


def main():
    os.umask(0o077)
    parser=argparse.ArgumentParser();parser.add_argument('action',choices=['backup','daemon','restore'])
    parser.add_argument('source',nargs='?');parser.add_argument('target',nargs='?');args=parser.parse_args()
    if args.action == 'restore':
        if not args.source or not args.target:parser.error('source et cible requises')
        restore(args.source,args.target);print('Restauration de test terminée.',flush=True);return
    while True:
        try:
            result=backup();print('Sauvegarde chiffrée terminée : '+result.name,flush=True)
            status={'ok':True,'at':datetime.now(timezone.utc).isoformat(),'file':result.name}
        except Exception:
            print('Échec de sauvegarde : consulter la configuration et le stockage.',flush=True)
            status={'ok':False,'at':datetime.now(timezone.utc).isoformat()}
            if args.action != 'daemon':raise
        directory=Path(os.environ.get('GSR_BACKUP_DIR','/backups'))
        temporary=directory/'last-run.tmp';temporary.write_text(json.dumps(status));temporary.replace(directory/'last-run.json')
        if args.action != 'daemon':return
        time.sleep(86400)


if __name__ == '__main__':main()
