"""Agency-scoped calendar rules. Changes and bookings serialize on one agency document."""
from datetime import date,datetime,timedelta,timezone,time
from typing import Literal
from fastapi import APIRouter,Depends,HTTPException,Request
from pydantic import BaseModel,ConfigDict,Field,model_validator
from pymongo import ReturnDocument
from auth import require_roles,log_action
from transactions import run
router=APIRouter(prefix='/crm/agenda');_db={}
def init(database):_db['db']=database
KINDS=('information','inscription','evaluation_initiale')
def access(user,agency):
    if agency not in ('creteil','bonneuil'):raise HTTPException(422,'Agence inconnue')
    if user['role']!='direction' and user.get('agency')!=agency:raise HTTPException(403,'Agenda réservé à cette agence')
class Strict(BaseModel):model_config=ConfigDict(extra='forbid')
class Closure(Strict):
    start:date;end:date;reason:str=Field(min_length=2,max_length=180)
    @model_validator(mode='after')
    def range(self):
        if self.end<self.start:raise ValueError('Période de fermeture inversée')
        return self
class ExceptionRule(Strict):
    date:date;time:str|None=None;closed:bool=False;capacity:int|None=Field(default=None,ge=0,le=10)
    reason:str=Field(min_length=2,max_length=180)
    @model_validator(mode='after')
    def valid(self):
        if self.time is not None:
            if len(self.time)!=5:raise ValueError('Horaire HH:MM requis')
            time.fromisoformat(self.time)
        return self
class Pattern(Strict):
    weekdays:list[int]=Field(min_length=1,max_length=7);times:list[str]=Field(min_length=1,max_length=48)
    capacity:int=Field(ge=1,le=10);appointment_type:Literal['information','inscription','evaluation_initiale']
    duration_minutes:int=Field(ge=5,le=240);confirmation_required:bool=True
    @model_validator(mode='after')
    def valid(self):
        if len(set(self.weekdays))!=len(self.weekdays) or any(x<0 or x>6 for x in self.weekdays):raise ValueError('Jours invalides')
        if len(set(self.times))!=len(self.times):raise ValueError('Horaires en double')
        for value in self.times:
            if len(value)!=5:raise ValueError('Horaire HH:MM requis')
            time.fromisoformat(value)
        return self
class Config(Strict):
    revision:int=Field(default=0,ge=0);closures:list[Closure]=Field(default_factory=list,max_length=100)
    exceptions:list[ExceptionRule]=Field(default_factory=list,max_length=200)
    patterns:list[Pattern]=Field(default_factory=list,max_length=30)
    @model_validator(mode='after')
    def unique(self):
        keys=[(str(x.date),x.time) for x in self.exceptions]
        if len(set(keys))!=len(keys):raise ValueError('Exceptions en double')
        occupied=set()
        for pattern in self.patterns:
            for day in pattern.weekdays:
                for hour in pattern.times:
                    if (day,hour) in occupied:raise ValueError('Horaires récurrents en conflit')
                    occupied.add((day,hour))
        return self
async def configuration(database,agency,session=None,touch=False):
    if touch:
        return await database.agenda_settings.find_one_and_update({'_id':agency},{'$inc':{'lock_revision':1},'$setOnInsert':{'revision':0,'closures':[],'exceptions':[],'patterns':[]}},upsert=True,return_document=ReturnDocument.AFTER,session=session)
    return await database.agenda_settings.find_one({'_id':agency},session=session) or {'revision':0,'closures':[],'exceptions':[],'patterns':[]}
def effective(slot,config):
    result=dict(slot)
    if any(c['start']<=slot['date']<=c['end'] for c in config['closures']):result['closed']=True
    for rule in sorted(config['exceptions'],key=lambda x:bool(x.get('time'))):
        if rule['date']==slot['date'] and (not rule.get('time') or rule['time']==slot['time']):
            result['closed']=rule['closed']
            if rule.get('capacity') is not None:result['capacity']=rule['capacity']
    if slot.get("closed"):result["closed"]=True
    return result
async def validate_slot(database,slot,session,appointment_type=None):
    if not slot:raise HTTPException(409,'Créneau indisponible')
    config=await configuration(database,slot['agency'],session,True)
    value=effective(slot,config)
    if value.get('closed') or value['booked']>=value['capacity']:raise HTTPException(409,'Créneau fermé ou complet')
    if appointment_type and slot.get('appointment_type') and slot['appointment_type']!=appointment_type:raise HTTPException(409,'Type de rendez-vous incompatible')
    if value['capacity']!=slot['capacity']:
        await database.creneaux.update_one({'id':slot['id']},{'$set':{'capacity':value['capacity']}},session=session)
    return value
@router.get('/{agency}')
async def get(agency:str,user=Depends(require_roles('direction','responsable','accueil'))):
    access(user,agency);value=await configuration(_db['db'],agency)
    return {k:value[k] for k in ('revision','closures','exceptions','patterns')}
@router.put('/{agency}')
async def save(agency:str,body:Config,request:Request,user=Depends(require_roles('direction','responsable','accueil'))):
    access(user,agency)
    async def operation(session):
        db=_db['db'];current=await configuration(db,agency,session,True)
        if current['revision']!=body.revision:raise HTTPException(409,'Configuration modifiée, rechargez l’agenda')
        data=body.model_dump(mode='json')
        if user['role']!='direction' and data['patterns']!=current['patterns']:raise HTTPException(403,'Horaires récurrents réservés à la Direction')
        if user['role']=='accueil' and sorted([(x['date'],x.get('time') or '',x['capacity']) for x in data['exceptions'] if x.get('capacity') is not None])!=sorted([(x['date'],x.get('time') or '',x['capacity']) for x in current['exceptions'] if x.get('capacity') is not None]):raise HTTPException(403,'Capacités réservées à la Direction ou au Responsable')
        # Existing reservations remain intact; reducing an effective capacity is forbidden.
        async for slot in db.creneaux.find({'agency':agency,'date':{'$gte':date.today().isoformat()},'booked':{'$gt':0}},session=session):
            if effective(slot,data)['capacity']<slot['booked']:raise HTTPException(409,'Capacité inférieure aux rendez-vous déjà réservés')
        await db.agenda_settings.update_one({'_id':agency},{'$set':{**data,'revision':body.revision+1,'updated_at':datetime.now(timezone.utc).isoformat()},'$push':{'history':{'at':datetime.now(timezone.utc).isoformat(),'by':user['id'],'kind':'configuration'}}},session=session)
        await log_action('agenda_configuration',request,user,target=agency,meta={'closures':len(data['closures']),'exceptions':len(data['exceptions'])},mongo_session=session)
    await run(_db['db'],operation);return await get(agency,user)
class Generate(Strict):
    start:date;end:date;revision:int=Field(ge=0)
    @model_validator(mode='after')
    def valid(self):
        if self.start<=date.today() or self.end<self.start or (self.end-self.start).days>90:raise ValueError('Période future de 90 jours maximum')
        return self
@router.post('/{agency}/generer')
async def generate(agency:str,body:Generate,request:Request,user=Depends(require_roles('direction'))):
    access(user,agency);result={'created':0}
    async def operation(session):
        result['created']=0;db=_db['db'];config=await configuration(db,agency,session,True)
        if config['revision']!=body.revision:raise HTTPException(409,'Configuration modifiée')
        if not config['patterns']:raise HTTPException(422,'La Direction doit configurer les horaires, types, durées et capacités')
        for i in range((body.end-body.start).days+1):
            day=body.start+timedelta(days=i)
            for pattern in config['patterns']:
                if day.weekday() not in pattern['weekdays']:continue
                for hour in pattern['times']:
                    sid=f"{agency}-{day.isoformat()}-{hour}"
                    existing=await db.creneaux.find_one({'id':sid},session=session)
                    if existing:continue # Never overwrite capacities or reservations.
                    row={'id':sid,'agency':agency,'date':day.isoformat(),'time':hour,'booked':0,'capacity':pattern['capacity'],'appointment_type':pattern['appointment_type'],'duration_minutes':pattern['duration_minutes'],'confirmation_required':pattern['confirmation_required']}
                    row=effective(row,config);await db.creneaux.insert_one(row,session=session);result['created']+=1
        await log_action('agenda_generation',request,user,target=agency,meta=result,mongo_session=session)
    await run(_db['db'],operation);return result
