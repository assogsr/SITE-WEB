"""Agency-private organization register. No automatic outbound communications."""
import uuid
from datetime import datetime, timezone
from typing import Literal
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field, EmailStr, ConfigDict
from auth import require_roles, log_action
from crm import scope
from transactions import run
router = APIRouter(prefix='/crm/organisations')
_db = {}
def init(db): _db['db'] = db
roles = require_roles('direction', 'responsable', 'accueil')
def now(): return datetime.now(timezone.utc).isoformat()
class Contact(BaseModel):
    model_config = ConfigDict(extra='forbid', str_strip_whitespace=True)
    name: str = Field(min_length=2,max_length=120)
    position: str = Field(default='',max_length=120)
    email: EmailStr | None = None
    phone: str = Field(default='',max_length=40)
class Organization(BaseModel):
    model_config = ConfigDict(extra='forbid', str_strip_whitespace=True)
    agency: Literal['creteil','bonneuil']
    name: str = Field(min_length=2,max_length=200)
    kind: str = Field(default='',max_length=120)
    address: str = Field(default='',max_length=400)
    email: EmailStr | None = None
    phone: str = Field(default='',max_length=40)
    contacts: list[Contact] = Field(default_factory=list,max_length=30)
    document_ids: list[str] = Field(default_factory=list,max_length=30)
    next_action: str = Field(default='',max_length=500)
    deadline: str | None = Field(default=None,max_length=40)
    note: str = Field(default='',max_length=2000)
async def documents(db, ids, user, agency, session):
    if not ids: return
    from business_documents import authorized_document
    for identifier in ids:
        d = await authorized_document(db,identifier,user,session=session)
        if d.get('agency') != agency: raise HTTPException(422,'La pièce doit appartenir à la même agence')
        await db.private_documents.update_one({'id':identifier},{'$inc':{'revision':1}},session=session)
async def fetch(identifier,user,session=None):
    d=await _db['db'].business_organizations.find_one(scope(user,{'id':identifier}),{'_id':0,'revision':0},session=session)
    if not d: raise HTTPException(404,'Organisme introuvable')
    return d
async def save(body,user,identifier=None):
    db=_db['db']; fields=body.model_dump(mode='json'); scope(user, {})
    if user['role']!='direction' and fields['agency']!=user.get('agency'): raise HTTPException(403,'Agence non autorisée')
    if fields['deadline']:
        try:
            dt=datetime.fromisoformat(fields['deadline'].replace('Z','+00:00'))
            if dt.tzinfo is None: raise ValueError()
            fields['deadline']=dt.astimezone(timezone.utc).isoformat()
        except ValueError: raise HTTPException(422,'Échéance avec fuseau horaire requise')
    async def operation(session):
        old=await fetch(identifier,user,session) if identifier else None
        if old and old['agency']!=fields['agency']: raise HTTPException(422,'Réaffectation non prévue : conserver l’agence')
        duplicate=await db.business_organizations.find_one({'_id':f"{fields['agency']}:{fields['name'].casefold()}"},session=session)
        if duplicate and duplicate['id']!=identifier: raise HTTPException(409,'Cet organisme existe déjà dans cette agence')
        await documents(db,fields['document_ids'],user,fields['agency'],session)
        record={**fields,'id':identifier or str(uuid.uuid4()),'created_at':old['created_at'] if old else now(),'updated_at':now(),'history':(old or {}).get('history',[])+[{'at':now(),'by':user['id'],'action':'modification' if old else 'creation','note':fields.pop('note')}]}
        # Unique primary key prevents concurrent duplicate organization creation.
        record['_id']=f"{record['agency']}:{record['name'].casefold()}"
        if old:
            await db.business_organizations.delete_one({'id':identifier},session=session)
        await db.business_organizations.insert_one(record,session=session)
        await log_action('organization_update' if old else 'organization_create', user=user, target=record['id'], meta={'agency':record['agency']}, mongo_session=session)
        record.pop('_id'); return record
    from pymongo.errors import DuplicateKeyError
    try: return await run(db,operation)
    except DuplicateKeyError: raise HTTPException(409,'Cet organisme existe déjà dans cette agence')
@router.get('')
async def listing(user=Depends(roles)):
    return await _db['db'].business_organizations.find(scope(user,{}),{'_id':0,'revision':0}).sort('name',1).to_list(500)
@router.post('',status_code=201)
async def create(body:Organization,user=Depends(roles)): return await save(body,user)
@router.get('/{identifier}')
async def detail(identifier:str,user=Depends(roles)): return await fetch(identifier,user)
@router.put('/{identifier}')
async def update(identifier:str,body:Organization,user=Depends(roles)): return await save(body,user,identifier)
