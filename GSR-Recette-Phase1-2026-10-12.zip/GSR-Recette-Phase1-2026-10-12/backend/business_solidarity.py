"""Phase 1: human-led solidarity applications; no automated eligibility decision."""
import uuid
from datetime import date, datetime, timezone
from typing import Literal
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, ConfigDict, Field, model_validator
from auth import get_current_user, log_action
from crm import scope
from crm_workflow import SUB_STATUSES
from transactions import run

router = APIRouter(prefix='/crm/solidarite', tags=['solidarite'])
_db = {}
STATUSES = SUB_STATUSES['solidarite']
def init(database): _db['db'] = database
def db(): return _db['db']
def now(): return datetime.now(timezone.utc).isoformat()
def direction(user):
    if user['role'] != 'direction': raise HTTPException(403, 'Configuration réservée à la Direction')
def permitted(user, agency):
    q = scope(user, {})
    if q.get('agency') and q['agency'] != agency: raise HTTPException(403, 'Agence non autorisée')

class Strict(BaseModel):
    model_config = ConfigDict(extra='forbid', str_strip_whitespace=True)
class Item(Strict):
    id: str = Field(min_length=1, max_length=100, pattern=r'^[A-Za-z0-9_-]+$')
    label: str = Field(min_length=1, max_length=200)
    required: bool = False
class Device(Strict):
    name: str = Field(min_length=2, max_length=160)
    agency: Literal['creteil', 'bonneuil']
    description: str = Field(default='', max_length=2000)
    active: bool = True
    criteria: list[Item] = Field(default_factory=list, max_length=50)
    required_documents: list[Item] = Field(default_factory=list, max_length=50)
    indicators: list[Item] = Field(default_factory=list, max_length=50)
    funders: list[str] = Field(default_factory=list, max_length=30)
    objectives: str = Field(default='', max_length=2000)
    period_start: date | None = None
    period_end: date | None = None
    convention_document_ids: list[str] = Field(default_factory=list, max_length=30)
    @model_validator(mode='after')
    def validate_config(self):
        for items in (self.criteria, self.required_documents, self.indicators):
            if len({x.id for x in items}) != len(items): raise ValueError('Identifiants de configuration dupliqués')
        if any(len(s) > 200 or not s.strip() for s in self.funders): raise ValueError('Financeur invalide')
        if self.period_start and self.period_end and self.period_end < self.period_start: raise ValueError('Période incohérente')
        return self
class Application(Strict):
    device_id: str = Field(min_length=1, max_length=100)
    prospect_id: str = Field(min_length=1, max_length=100)
    prescriber: str = Field(default='', max_length=200)
    prescriber_organization_id: str | None = Field(default=None, max_length=100)
    orientation_date: date | None = None
    source: str = Field(default='', max_length=200)
    document_ids: list[str] = Field(default_factory=list, max_length=30)
class Change(Strict):
    revision: int = Field(ge=0)
    status: Literal['recue','a_completer','en_etude','entretien','admise','attente','refusee','abandonnee'] | None = None
    note: str = Field(min_length=2, max_length=2000)
    confirm_human: bool = False
    non_registration_reason: str | None = Field(default=None, max_length=100)
    document_ids: list[str] | None = Field(default=None, max_length=30)
    checks: dict[str, Literal['a_verifier','conforme','non_conforme']] | None = None
    indicator_values: dict[str, str] | None = None
    prescriber: str | None = Field(default=None, max_length=200)
    prescriber_organization_id: str | None = Field(default=None, max_length=100)
    orientation_date: date | None = None
    source: str | None = Field(default=None, max_length=200)
    verify_proofs: bool = False
    step: str = Field(default='', max_length=200)
    result: str = Field(default='', max_length=1000)

async def documents(ids, user, agency, session):
    if not ids: return
    from business_documents import authorized_document
    for identifier in ids:
        record = await authorized_document(db(), identifier, user, session=session)
        if record.get('agency') != agency: raise HTTPException(422, 'Justificatif appartenant à une autre agence')
        await db().private_documents.update_one({'id':identifier},{'$inc':{'revision':1}},session=session)

async def organization(identifier, user, agency, session):
    if not identifier: return None
    record=await db().business_organizations.find_one(scope(user,{'id':identifier}),session=session)
    if not record or record.get('agency')!=agency: raise HTTPException(404,'Structure prescriptrice autorisée introuvable dans cette agence')
    await db().business_organizations.update_one({'id':identifier},{'$inc':{'revision':1}},session=session)
    return record

def clean(body): return body.model_dump(mode='json')
def event(user, action, note='', **extra):
    return {'at': now(), 'actor_id': user['id'], 'actor_name': user.get('name', ''), 'action': action, 'note': note, **extra}

@router.get('/meta')
async def meta(user=Depends(get_current_user)):
    scope(user,{})
    settings=await db().site_settings.find_one({'_id':'crm_workflow'}) or {}
    return {'statuses': STATUSES, 'non_registration_reasons': [r for r in settings.get('non_registration_reasons', []) if r.get('active', True)]}

@router.get('/dispositifs')
async def devices(user=Depends(get_current_user)):
    return await db().solidarity_devices.find(scope(user, {}), {'_id':0}).sort('name',1).to_list(500)

@router.post('/dispositifs', status_code=201)
async def create_device(body: Device, user=Depends(get_current_user)):
    direction(user)
    async def operation(session):
        await documents(body.convention_document_ids,user,body.agency,session)
        record={**clean(body),'id':str(uuid.uuid4()),'revision':0,'created_at':now(),'history':[event(user,'creation')]}
        await db().solidarity_devices.insert_one(record,session=session)
        await log_action('solidarity_device_create',user=user,target=record['id'],meta={'agency':record['agency']},mongo_session=session)
        record.pop('_id',None)
        return record
    return await run(db(),operation)

@router.put('/dispositifs/{identifier}')
async def update_device(identifier:str, body:Device, revision:int, user=Depends(get_current_user)):
    direction(user)
    async def operation(session):
        old=await db().solidarity_devices.find_one({'id':identifier},session=session)
        if not old: raise HTTPException(404,'Dispositif introuvable')
        if old['revision']!=revision: raise HTTPException(409,'Le dispositif a été modifié ; rechargez-le')
        if old['agency']!=body.agency: raise HTTPException(422,'Agence du dispositif immuable ; créez un dispositif distinct')
        await documents(body.convention_document_ids,user,body.agency,session)
        value={**clean(body),'updated_at':now()}
        await db().solidarity_devices.update_one({'id':identifier},{'$set':value,'$inc':{'revision':1},'$push':{'history':event(user,'modification',changes={key:{'before':old.get(key),'after':val} for key,val in value.items() if key!='updated_at' and old.get(key)!=val})}},session=session)
        await log_action('solidarity_device_update',user=user,target=identifier,meta={'agency':body.agency,'revision':revision+1},mongo_session=session)
        return await db().solidarity_devices.find_one({'id':identifier},{'_id':0},session=session)
    return await run(db(),operation)

@router.get('/candidatures')
async def applications(status:str|None=None, user=Depends(get_current_user)):
    q=scope(user,{})
    if status:
        if status not in STATUSES: raise HTTPException(422,'Statut invalide')
        q['status']=status
    return await db().solidarity_applications.find(q,{'_id':0}).sort('created_at',-1).to_list(500)

@router.post('/candidatures',status_code=201)
async def create_application(body:Application,user=Depends(get_current_user)):
    scope(user,{})
    async def operation(session):
        device=await db().solidarity_devices.find_one(scope(user,{'id':body.device_id,'active':True}),session=session)
        if not device: raise HTTPException(404,'Dispositif actif introuvable')
        prospect=await db().demandes.find_one(scope(user,{'id':body.prospect_id,'agency':device['agency'],'archived':{'$ne':True}}),session=session)
        if not prospect or prospect.get('agency')!=device['agency']: raise HTTPException(404,'Prospect autorisé introuvable dans cette agence')
        prescriber=await organization(body.prescriber_organization_id,user,device['agency'],session)
        await documents(body.document_ids,user,device['agency'],session)
        existing=await db().solidarity_applications.find_one({'device_id':body.device_id,'prospect_id':body.prospect_id},session=session)
        if existing: raise HTTPException(409,'Cette candidature existe déjà')
        # Serialize duplicate creation without relying on a best-effort read.
        await db().solidarity_devices.update_one({'id':device['id']},{'$inc':{'applications_revision':1}},session=session)
        await db().demandes.update_one({'id':prospect['id']},{'$inc':{'crm_revision':1}},session=session)
        record={**clean(body),'id':str(uuid.uuid4()),'agency':device['agency'],'prospect_name':prospect.get('name',''),'device_name':device['name'],'status':'recue','revision':0,'created_at':now(),'checks':{},'indicator_values':{},'steps':[],'history':[event(user,'creation')],'criteria_snapshot':device['criteria'],'documents_snapshot':device['required_documents']}
        if prescriber: record['prescriber_organization_name']=prescriber['name']
        await db().solidarity_applications.insert_one(record,session=session)
        await log_action('solidarity_application_create',user=user,target=record['id'],meta={'agency':record['agency'],'device_id':record['device_id']},mongo_session=session)
        record.pop('_id',None)
        return record
    return await run(db(),operation)

@router.patch('/candidatures/{identifier}')
async def change_application(identifier:str,body:Change,user=Depends(get_current_user)):
    scope(user,{})
    async def operation(session):
        old=await db().solidarity_applications.find_one(scope(user,{'id':identifier}),session=session)
        if not old: raise HTTPException(404,'Candidature introuvable')
        if old['revision']!=body.revision: raise HTTPException(409,'La candidature a été modifiée ; rechargez-la')
        device=await db().solidarity_devices.find_one({'id':old['device_id']},session=session)
        if not device: raise HTTPException(409,'Dispositif introuvable')
        status=body.status or old['status']
        if status!=old['status'] and status in ('admise','refusee','abandonnee') and not body.confirm_human: raise HTTPException(422,'Confirmation explicite de la décision humaine requise')
        updates={'status':status,'updated_at':now()}
        if status in ('refusee','abandonnee') and status!=old['status']:
            settings=await db().site_settings.find_one({'_id':'crm_workflow'},session=session) or {}
            reason=next((r for r in settings.get('non_registration_reasons',[]) if r.get('id')==body.non_registration_reason and r.get('active',True)),None)
            if not reason: raise HTTPException(422,'La Direction doit configurer les motifs de non-inscription')
            updates['decision_reason']={'id':reason['id'],'label':reason['label'],'comment':body.note}
        if body.checks is not None:
            if set(body.checks)-{x['id'] for x in old['criteria_snapshot']}: raise HTTPException(422,'Critère non configuré à la réception de cette candidature')
            updates['checks']=body.checks
        if body.indicator_values is not None:
            if set(body.indicator_values)-{x['id'] for x in device['indicators']} or any(len(v)>1000 for v in body.indicator_values.values()): raise HTTPException(422,'Indicateur non configuré ou valeur trop longue')
            updates['indicator_values']=body.indicator_values
        ids=body.document_ids if body.document_ids is not None else old['document_ids']
        await documents(ids,user,old['agency'],session)
        if body.document_ids is not None: updates['document_ids']=ids
        if 'prescriber_organization_id' in body.model_fields_set:
            linked=await organization(body.prescriber_organization_id,user,old['agency'],session)
            updates['prescriber_organization_id']=body.prescriber_organization_id
            updates['prescriber_organization_name']=linked['name'] if linked else None
        for field in ('prescriber','orientation_date','source'):
            if field in body.model_fields_set: updates[field]=clean(body)[field]
        if body.verify_proofs and (not ids or not body.confirm_human or not (body.step or body.result)):
            raise HTTPException(422,'Contrôle humain et justificatif requis pour vérifier un résultat')
        change=event(user,'suivi',body.note,old_status=old['status'],status=status,changes={key:{'before':old.get(key),'after':val} for key,val in updates.items() if key!='updated_at' and old.get(key)!=val})
        push={'history':change}
        if body.step or body.result:
            push['steps']={**event(user,'etape',body.note),'label':body.step,'result':body.result,'document_ids':ids,'verified':body.verify_proofs,'verified_by':user['id'] if body.verify_proofs else None,'verification_note':'Justificatif contrôlé humainement' if body.verify_proofs else ('Justificatif à contrôler humainement' if ids else 'Résultat sans justificatif : non vérifié')}
        if status!=old['status'] and status in ('admise','refusee','abandonnee'): updates['human_decision']={'actor_id':user['id'],'at':now(),'note':body.note}
        await db().solidarity_applications.update_one({'id':identifier},{'$set':updates,'$inc':{'revision':1},'$push':push},session=session)
        await log_action('solidarity_application_update',user=user,target=identifier,meta={'agency':old['agency'],'old_status':old['status'],'status':status,'human_decision':bool(status!=old['status'] and status in ('admise','refusee','abandonnee')),'revision':old['revision']+1},mongo_session=session)
        return await db().solidarity_applications.find_one({'id':identifier},{'_id':0},session=session)
    return await run(db(),operation)
