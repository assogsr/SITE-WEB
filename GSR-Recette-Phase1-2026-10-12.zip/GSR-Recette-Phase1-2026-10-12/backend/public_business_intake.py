"""Dedicated public requests, atomically recorded through the existing CRM intake."""
from datetime import date
from typing import Literal
from fastapi import APIRouter,HTTPException,Request
from pydantic import BaseModel,ConfigDict,Field,model_validator
from server import DemandeCreate,create_demande
router=APIRouter(prefix='/public/metier')
class Details(BaseModel):
    model_config=ConfigDict(extra='forbid',str_strip_whitespace=True)
    kind:Literal['intervention','solidarite','partenariat']
    action:str=Field(default='',max_length=180)
    contact_position:str=Field(default='',max_length=120)
    audience:str=Field(default='',max_length=300)
    headcount:int|None=Field(default=None,ge=1,le=100000)
    location:str=Field(default='',max_length=300)
    requested_dates:list[date]=Field(default_factory=list,max_length=20)
    device_requested:str=Field(default='',max_length=180)
    prescriber:str=Field(default='',max_length=200)
    orientation_date:date|None=None
class Intake(DemandeCreate):
    model_config=ConfigDict(extra='forbid')
    business_intake:Details
    privacy_informed:bool=False
    @model_validator(mode='after')
    def dedicated(self):
        if not self.privacy_informed:raise ValueError('Information confidentialité à lire et confirmer')
        if self.business_intake.kind=='intervention' and (not (self.structure or "").strip() or not self.business_intake.action.strip()):raise ValueError('Structure et action demandée requises')
        return self
@router.post('/demande',status_code=201)
async def submit(body:Intake,request:Request):
    expected={'intervention':'intervention','partenariat':'partenariat','solidarite':'informations'}[body.business_intake.kind]
    if body.type!=expected or body.creneau_id or body.session_id:raise HTTPException(422,'Type de demande métier incohérent')
    result=await create_demande(body,request)
    return {'reference':result.reference,'agency':result.agency,'status':result.status,'created_at':result.created_at,'admission':'non_confirmee'}
