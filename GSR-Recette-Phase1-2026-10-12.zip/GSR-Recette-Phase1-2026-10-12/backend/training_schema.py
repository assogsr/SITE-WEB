"""Versioned phase-2 data contracts only; no pedagogical write API is exposed."""
from datetime import datetime
from typing import Literal
from pydantic import BaseModel,ConfigDict,Field,model_validator
SCHEMA_VERSION=1
class Strict(BaseModel):
    model_config=ConfigDict(extra='forbid')
class Reference(Strict):
    session_id:str=Field(min_length=1,max_length=120)
    person_id:str=Field(min_length=1,max_length=120)
    enrollment_id:str=Field(min_length=1,max_length=120)
class Attendance(Reference):
    agency:Literal['creteil','bonneuil']
    starts_at:datetime
    ends_at:datetime
    state:Literal['present','absent','excused','not_recorded']='not_recorded'
    proof_document_ids:list[str]=Field(default_factory=list,max_length=20)
    signature_document_id:str|None=None
    recorded_by:str|None=None
    recorded_at:datetime|None=None
    @model_validator(mode='after')
    def time_range(self):
        if self.starts_at.tzinfo is None or self.ends_at.tzinfo is None or self.ends_at<=self.starts_at:raise ValueError('Horaires avec fuseau et intervalle valide requis')
        if self.recorded_at and self.recorded_at.tzinfo is None:raise ValueError('Horodatage avec fuseau requis')
        return self
class Outcome(Strict):
    criterion_id:str=Field(min_length=1,max_length=120)
    observed:str=Field(max_length=2000)
    proof_document_ids:list[str]=Field(default_factory=list,max_length=20)
    human_verified:bool=False
class Evaluation(Reference):
    agency:Literal['creteil','bonneuil']
    stage:Literal['initial','final']
    assessed_at:datetime
    assessor_id:str=Field(min_length=1,max_length=120)
    outcomes:list[Outcome]=Field(default_factory=list,max_length=100)
    result:str|None=Field(default=None,max_length=2000)
    proof_document_ids:list[str]=Field(default_factory=list,max_length=20)
    human_verified:bool=False
    @model_validator(mode='after')
    def timezone(self):
        if self.assessed_at.tzinfo is None:raise ValueError('Fuseau requis')
        return self
class Pedagogy(Strict):
    schema_version:Literal[1]=1
    phase:Literal[2]=2
    attendance:list[Attendance]=Field(default_factory=list)
    evaluations:list[Evaluation]=Field(default_factory=list)
def empty():return Pedagogy().model_dump(mode='json')
def contract():return Pedagogy.model_json_schema()
