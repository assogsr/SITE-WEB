"""Capability-protected appointment changes, committed together with capacities."""
import hashlib
import re
from datetime import datetime, timezone
from typing import Literal, Optional

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, Field
from pymongo import ReturnDocument

from auth import log_action
from transactions import run
from notifications import queue

router = APIRouter(prefix='/rdv/gestion')
_db = {}


def init(database): _db['db'] = database


def digest(token):
    if not re.fullmatch(r'[0-9a-f]{64}', token):
        raise HTTPException(404, 'Lien introuvable ou expiré')
    return hashlib.sha256(token.encode()).hexdigest()


def public_view(d, slot):
    return {'agency':d['agency'], 'status':d['status'],
            'active':d.get('reservation_active', d['status'] != 'annule'),
            'date':slot['date'] if slot else None, 'time':slot['time'] if slot else None}


async def cancel(database, d, mongo_session):
    if d.get('creneau_id') and d.get('reservation_active', d.get('status') != 'annule'):
        result = await database.creneaux.update_one(
            {'id':d['creneau_id'], 'agency':d['agency'], 'booked':{'$gt':0}},
            {'$inc':{'booked':-1}}, session=mongo_session)
        if result.modified_count != 1:
            raise HTTPException(409, 'Réservation incohérente : traitement par l’agence nécessaire.')


class Change(BaseModel):
    action: Literal['annuler','deplacer']
    creneau_id: Optional[str] = Field(default=None,max_length=120)


@router.get('/{token}')
async def information(token: str):
    database=_db['db']
    d=await database.demandes.find_one({'rdv_token_hash':digest(token),
        'rdv_token_expires':{'$gt':datetime.now(timezone.utc).isoformat()}},{'_id':0})
    if not d:raise HTTPException(404,'Lien introuvable ou expiré')
    slot=await database.creneaux.find_one({'id':d['creneau_id']},{'_id':0})
    return public_view(d,slot)


@router.post('/{token}')
async def change(token: str,body: Change,request: Request):
    database=_db['db'];hashed=digest(token)
    async def operation(mongo_session):
        d=await database.demandes.find_one({'rdv_token_hash':hashed,
            'rdv_token_expires':{'$gt':datetime.now(timezone.utc).isoformat()}},{'_id':0},session=mongo_session)
        if not d:raise HTTPException(404,'Lien introuvable ou expiré')
        old=await database.creneaux.find_one({'id':d['creneau_id']},{'_id':0},session=mongo_session)
        if not d.get('reservation_active',d['status']!='annule'):
            if body.action=='annuler':return public_view(d,old)
            raise HTTPException(409,'Ce rendez-vous est annulé.')
        from sessions import today
        if not old or old['date'] <= today().isoformat():
            raise HTTPException(409,'Contactez l’agence pour ce rendez-vous.')
        sets={'reservation_active':False,'status':'annule'}
        new=old
        if body.action=='deplacer':
            if not body.creneau_id:raise HTTPException(422,'Choisissez un nouveau créneau.')
            if body.creneau_id==old['id']:return public_view(d,old)
            from business_agenda import validate_slot
            candidate=await database.creneaux.find_one({'id':body.creneau_id,'agency':d['agency']},session=mongo_session)
            await validate_slot(database,candidate,mongo_session,d.get('appointment_type'))
            new=await database.creneaux.find_one_and_update(
                {'id':body.creneau_id,'agency':d['agency'],'date':{'$gt':today().isoformat()},
                 'closed':{'$ne':True},'$expr':{'$lt':['$booked','$capacity']}},
                {'$inc':{'booked':1}},session=mongo_session,return_document=ReturnDocument.AFTER)
            if not new:raise HTTPException(409,'Créneau indisponible dans cette agence.')
            sets={'creneau_id':new['id'],'reservation_active':True,'status':d['status']}
        await cancel(database,d,mongo_session)
        at=datetime.now(timezone.utc).isoformat()
        await database.demandes.update_one({'id':d['id']},{'$set':{**sets,'updated_at':at},
            '$push':{'history':{'at':at,'by':'Lien sécurisé','kind':'rdv','text':'Rendez-vous annulé' if body.action=='annuler' else 'Rendez-vous déplacé'}}},session=mongo_session)
        from crm_workflow import pending_tasks
        await pending_tasks(database, {**d, **sets}, mongo_session)
        await log_action('rdv_'+body.action,request,target=d['reference'],mongo_session=mongo_session)
        await queue(database,{**d,**sets},'annulation' if body.action=='annuler' else 'deplacement',d['id']+':'+body.action+':'+at,mongo_session,new)
        return public_view({**d,**sets},new)
    return await run(database,operation)
