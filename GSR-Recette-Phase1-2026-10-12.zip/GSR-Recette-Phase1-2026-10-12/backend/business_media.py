"""Controlled editorial media and ordered storyboards; never publish private attachments."""
import uuid
from datetime import date,datetime,timezone
from typing import Literal
from urllib.parse import urlsplit
from fastapi import APIRouter,Depends,HTTPException,Request,Query
from fastapi.responses import Response
from pydantic import BaseModel,ConfigDict,Field,model_validator
from auth import require_roles,log_action
from transactions import run
from business_documents import authorized_document
from document_antivirus import assert_clean,verify_available
router=APIRouter();store={}
def init(db):store['db']=db
def db():return store['db']
roles=require_roles('direction','responsable','accueil','editeur')
def scope(user):
    if user['role']=='direction':return {}
    if user['role']=='editeur':return {'created_by':user['id']}
    return {'agency':user['agency']}
class Sequence(BaseModel):
    model_config=ConfigDict(extra='forbid')
    title:str=Field(min_length=1,max_length=160)
    text:str=Field(default='',max_length=5000)
    document_id:str|None=None
    alt:str=Field(default='',max_length=500)
    credit:str=Field(default='',max_length=500)
class Media(BaseModel):
    model_config=ConfigDict(extra='forbid')
    title:str=Field(min_length=2,max_length=160)
    agency:Literal['creteil','bonneuil']
    format:Literal['presse','video','photo','radio','evenement','terrain','storyboard']
    occurred_on:date
    summary:str=Field(default='',max_length=1000)
    text:str=Field(default='',max_length=10000)
    themes:list[str]=Field(default_factory=list,max_length=20)
    program:str=Field(default='',max_length=160)
    source_name:str=Field(default='',max_length=300)
    source_url:str=Field(default='',max_length=1000)
    rights_reference:str=Field(default='',max_length=500)
    rights_verified:bool=False
    sequences:list[Sequence]=Field(default_factory=list,max_length=30)
    @model_validator(mode='after')
    def valid_url(self):
        if self.source_url:
            url=urlsplit(self.source_url)
            if url.scheme!='https' or not url.hostname or url.username or url.password or any(ord(c)<32 for c in self.source_url):raise ValueError('Lien officiel HTTPS requis')
        if any(not t.strip() or len(t)>120 for t in self.themes):raise ValueError('Thématique invalide')
        return self
class Change(Media):
    revision:int=Field(ge=0)
class Decision(BaseModel):
    model_config=ConfigDict(extra='forbid')
    revision:int=Field(ge=0)
    status:Literal['brouillon','en_validation','publie','archive']
class Featured(BaseModel):
    model_config=ConfigDict(extra='forbid')
    ids:list[str]=Field(max_length=3)
    @model_validator(mode='after')
    def unique(self):
        if len(set(self.ids))!=len(self.ids):raise ValueError('Sélection dupliquée')
        return self
async def get(mid,user,session=None):
    row=await db().editorial_media.find_one({'id':mid,**scope(user)},session=session)
    if not row:raise HTTPException(404,'Contenu introuvable')
    return row
async def validate_assets(values,user,session,publishing=False):
    for step in values['sequences']:
        if not step.get('document_id'):continue
        doc=await authorized_document(db(),step['document_id'],user,session)
        if doc['agency']!=values['agency'] or doc['sensitivity']!='interne':raise HTTPException(422,'Photo interne de la même agence requise')
        version=doc['versions'][-1]
        if version['mime'] not in ('image/jpeg','image/png'):raise HTTPException(422,'Image PNG ou JPEG requise')
        if publishing:
            if version['review_status']!='valide' or not step.get('alt') or not step.get('credit'):raise HTTPException(422,'Contrôle humain, alternative et crédit requis')
            assert_clean(version)
            await verify_available(version)
        await db().private_documents.update_one({'id':doc['id']},{'$inc':{'revision':1}},session=session)
def clean(row):return {k:v for k,v in row.items() if k!='_id'}
@router.get('/crm/medias')
async def private_list(user=Depends(roles)):
    return [clean(r) async for r in db().editorial_media.find(scope(user)).sort('occurred_on',-1).limit(500)]
@router.post('/crm/medias',status_code=201)
async def create(body:Media,request:Request,user=Depends(roles)):
    if user['role'] not in ('direction','editeur') and body.agency!=user['agency']:raise HTTPException(403,'Agence non autorisée')
    values=body.model_dump(mode='json');now=datetime.now(timezone.utc).isoformat()
    row={'id':str(uuid.uuid4()),**values,'created_by':user['id'],'created_at':now,'revision':0,'status':'brouillon','history':[{'at':now,'by':user['name'],'action':'creation'}]}
    async def operation(session):
        await validate_assets(values,user,session)
        await db().editorial_media.insert_one(row,session=session)
        await log_action('media_create',request,user,row['id'],mongo_session=session)
    await run(db(),operation);return clean(row)
@router.put('/crm/medias/{mid}')
async def update(mid:str,body:Change,request:Request,user=Depends(roles)):
    values=body.model_dump(mode='json',exclude={'revision'})
    async def operation(session):
        row=await get(mid,user,session)
        if row['revision']!=body.revision:raise HTTPException(409,'Contenu modifié ; rechargez')
        if row['agency']!=body.agency:raise HTTPException(422,'Agence immuable')
        await validate_assets(values,user,session)
        event={'at':datetime.now(timezone.utc).isoformat(),'by':user['name'],'action':'modification'}
        await db().editorial_media.update_one({'id':mid,'revision':body.revision},{'$set':{**values,'status':'brouillon'},'$inc':{'revision':1},'$push':{'history':event}},session=session)
        await db().site_settings.update_one({'_id':'media_featured'},{'$pull':{'ids':mid}},session=session)
        await log_action('media_update',request,user,mid,mongo_session=session)
    await run(db(),operation);return clean(await get(mid,user))
@router.post('/crm/medias/{mid}/decision')
async def decide(mid:str,body:Decision,request:Request,user=Depends(roles)):
    if body.status in ('publie','archive') and user['role']!='direction':raise HTTPException(403,'Publication/archivage réservés à la Direction')
    async def operation(session):
        row=await get(mid,user,session)
        if row['revision']!=body.revision:raise HTTPException(409,'Contenu modifié')
        if body.status=='publie':
            if not row['rights_verified'] or not row['rights_reference'].strip():raise HTTPException(422,'Droits et autorisations documentés requis')
            if row['format'] in ('presse','video','radio') and not row['source_url']:raise HTTPException(422,'Source officielle requise')
            await validate_assets(row,user,session,True)
        event={'at':datetime.now(timezone.utc).isoformat(),'by':user['name'],'action':body.status}
        await db().editorial_media.update_one({'id':mid,'revision':body.revision},{'$set':{'status':body.status,'published_assets':{step['document_id']:(await db().private_documents.find_one({'id':step['document_id']},session=session))['versions'][-1]['id'] for step in row['sequences'] if step.get('document_id')} if body.status=='publie' else {}},'$inc':{'revision':1},'$push':{'history':event}},session=session)
        if body.status!='publie':await db().site_settings.update_one({'_id':'media_featured'},{'$pull':{'ids':mid}},session=session)
        await log_action('media_decision',request,user,mid,{'status':body.status},mongo_session=session)
    await run(db(),operation);return clean(await get(mid,user))
@router.put('/crm/medias-selection/une')
async def featured(body:Featured,request:Request,user=Depends(require_roles('direction'))):
    async def operation(session):
        for mid in body.ids:
            row=await get(mid,user,session)
            if row['status']!='publie':raise HTTPException(422,'Seuls les contenus publiés peuvent être à la une')
            await db().editorial_media.update_one({'id':mid},{'$inc':{'revision':1}},session=session)
        await db().site_settings.update_one({'_id':'media_featured'},{'$set':{'ids':body.ids}},upsert=True,session=session)
        await log_action('media_featured',request,user,mongo_session=session)
    await run(db(),operation);return body.model_dump()
def public(row):
    result={k:row[k] for k in ('id','title','agency','format','occurred_on','summary','text','themes','program','source_name','source_url')}
    result['sequences']=[{**{k:v for k,v in step.items() if k!='document_id'},'image_url':f"/api/medias/{row['id']}/images/{i}" if step.get('document_id') else None} for i,step in enumerate(row['sequences'])]
    return result
@router.get('/medias')
async def public_list(year:int|None=None,month:int|None=None,theme:str|None=None,format:str|None=None,agency:str|None=None,program:str|None=None,q:str=Query(default='',max_length=120)):
    import re
    filters={'status':'publie'}
    if year:
        if not 1900<=year<=2200:raise HTTPException(422,'Année invalide')
        if month and not 1<=month<=12:raise HTTPException(422,'Mois invalide')
        prefix=str(year)+(f'-{month:02}' if month else '')
        filters['occurred_on']={'$regex':'^'+prefix}
    elif month:
        if not 1<=month<=12:raise HTTPException(422,'Mois invalide')
        filters['occurred_on']={'$regex':f'^\\d{{4}}-{month:02}-'}
    for key,value in [('themes',theme),('format',format),('agency',agency),('program',program)]:
        if value:filters[key]=value
    if q:
        if len(q)>120:raise HTTPException(422,'Recherche trop longue')
        filters['$or']=[{k:{'$regex':re.escape(q),'$options':'i'}} for k in ('title','summary','text')]
    return [public(row) async for row in db().editorial_media.find(filters).sort('occurred_on',-1).limit(500)]
@router.get('/medias/une')
async def public_featured():
    ids=(await db().site_settings.find_one({'_id':'media_featured'}) or {}).get('ids',[])
    rows={r['id']:public(r) async for r in db().editorial_media.find({'id':{'$in':ids},'status':'publie'})}
    return [rows[mid] for mid in ids if mid in rows]
@router.get('/medias/{mid}/images/{index}')
async def image(mid:str,index:int):
    row=await db().editorial_media.find_one({'id':mid,'status':'publie'})
    if not row or not 0<=index<len(row['sequences']):raise HTTPException(404,'Image introuvable')
    step=row['sequences'][index]
    doc=await db().private_documents.find_one({'id':step.get('document_id'),'agency':row['agency'],'sensitivity':'interne'})
    if not doc:raise HTTPException(404,'Image indisponible')
    v=doc['versions'][-1]
    if row.get('published_assets',{}).get(doc['id'])!=v['id']:raise HTTPException(409,'Nouvelle version à approuver')
    if v['review_status']!='valide' or v['mime'] not in ('image/png','image/jpeg'):raise HTTPException(409,'Image non validée')
    raw=await db().private_document_data.find_one({'id':v['id'],'document_id':doc['id']})
    if not raw:raise HTTPException(404,'Image indisponible')
    assert_clean(v,bytes(raw['data']));await verify_available(v)
    return Response(bytes(raw['data']),media_type=v['mime'],headers={'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'none'; sandbox"})
