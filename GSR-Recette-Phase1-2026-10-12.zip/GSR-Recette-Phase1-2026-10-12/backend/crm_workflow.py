"""Phase 1 CRM rules. Internal tasks only; no external message is sent here."""
import re
import uuid
from datetime import datetime, timezone, timedelta, date
from zoneinfo import ZoneInfo
from typing import Optional, Literal
from pydantic import BaseModel, ConfigDict, Field, model_validator
from email_validator import validate_email, EmailNotValidError
from fastapi import HTTPException

PARIS=ZoneInfo('Europe/Paris')
STATUS_LABELS={'nouveau':'Nouveau','a_rappeler':'À rappeler','contacte':'Contacté','rdv_fixe':'RDV fixé','venu':'Venu','inscrit':'Inscrit','sans_reponse':'Sans réponse','non_interesse':'Non intéressé','non_inscrit':'Non inscrit','annule':'Annulé','en_cours':'En cours','traite':'Traité'}
TERMINAL={'inscrit','non_interesse','non_inscrit','annule','traite'}
ACTIVITIES=('permis','formation-ia','intervention','partenariat','solidarite')
SUB_STATUSES={
 'intervention':{'recue':'Reçue','a_qualifier':'À qualifier','devis_a_preparer':'Devis à préparer','proposition_envoyee':'Proposition envoyée','acceptee':'Acceptée','refusee':'Refusée','realisee':'Réalisée','cloturee':'Clôturée'},
 'solidarite':{'recue':'Reçue','a_completer':'À compléter','en_etude':'En étude','entretien':'Entretien','admise':'Admise','attente':'Attente','refusee':'Refusée','abandonnee':'Abandonnée'}}
TYPES=('rendez-vous','informations','inscription','rappel','intervention','partenariat','formation-ia')


def instant():return datetime.now(timezone.utc)
def iso():return instant().isoformat()
def active_query():return {'archived':{'$ne':True}}
def activity_for(d):return d.get('activity') or (d['type'] if d.get('type') in ('intervention','partenariat','formation-ia') else 'permis')
def parse_time(value):
    if not value:return None
    parsed=datetime.fromisoformat(value.replace('Z','+00:00'))
    if parsed.tzinfo is None:raise ValueError('Fuseau horaire obligatoire')
    return parsed.astimezone(timezone.utc)


class ProspectFields(BaseModel):
    model_config=ConfigDict(extra='forbid',str_strip_whitespace=True)
    name:Optional[str]=Field(default=None,min_length=2,max_length=120)
    phone:Optional[str]=Field(default=None,max_length=40)
    email:Optional[str]=Field(default=None,max_length=254)
    agency:Optional[Literal['creteil','bonneuil']]=None
    type:Optional[Literal[TYPES]]=None
    activity:Optional[Literal[ACTIVITIES]]=None
    formation:Optional[str]=Field(default=None,max_length=120)
    structure:Optional[str]=Field(default=None,max_length=200)
    source:Optional[str]=Field(default=None,max_length=120)
    message:Optional[str]=Field(default=None,max_length=2000)
    assigned_to:Optional[str]=Field(default=None,max_length=120)
    next_action:Optional[str]=Field(default=None,max_length=500)
    next_action_due:Optional[str]=None
    privacy_informed:Optional[bool]=None
    privacy_notice_version:Optional[str]=Field(default=None,max_length=120)
    marketing_consent:Optional[bool]=None
    rappel_date:Optional[str]=None
    rappel_time:Optional[str]=None
    creneau_id:Optional[str]=Field(default=None,max_length=120)
    status:Optional[str]=None
    sub_status:Optional[str]=None
    non_registration_reason:Optional[str]=Field(default=None,max_length=100)
    non_registration_comment:Optional[str]=Field(default=None,max_length=1000)
    closure_reason:Optional[str]=Field(default=None,max_length=1000)
    note:Optional[str]=Field(default=None,max_length=1000)
    confirm_enrollment:bool=False
    detach_links:bool=False
    appointment_outcome:Optional[Literal['honore','absent']]=None

    @model_validator(mode='after')
    def valid_fields(self):
        if self.email:
            try:self.email=validate_email(self.email,check_deliverability=False,test_environment=True).normalized
            except EmailNotValidError:raise ValueError('Adresse email invalide')
        if self.phone and (not re.fullmatch(r'[+0-9().\s-]+',self.phone) or not 6 <= len(re.sub(r'\D','',self.phone)) <= 15):raise ValueError('Téléphone invalide')
        if self.rappel_date:date.fromisoformat(self.rappel_date)
        if self.rappel_time:datetime.strptime(self.rappel_time,'%H:%M')
        if self.next_action_due:parse_time(self.next_action_due)
        if self.status and self.status not in STATUS_LABELS:raise ValueError('Statut inconnu')
        return self


class ProspectCreate(ProspectFields):
    name:str=Field(min_length=2,max_length=120)
    agency:Literal['creteil','bonneuil']
    type:Literal[TYPES]='informations'
    status:Literal['nouveau']='nouveau'

    @model_validator(mode='after')
    def contact_required(self):
        if not self.phone and not self.email:raise ValueError('Téléphone ou email obligatoire')
        return self


class ContactEvent(BaseModel):
    model_config=ConfigDict(extra='forbid',str_strip_whitespace=True)
    channel:Literal['telephone','email','whatsapp','accueil']
    direction:Literal['entrant','sortant']='sortant'
    outcome:Literal['effectue','sans_reponse']='effectue'
    note:str=Field(min_length=2,max_length=1000)
    occurred_at:Optional[str]=None

    @model_validator(mode='after')
    def dated(self):
        if self.occurred_at and parse_time(self.occurred_at)>instant():raise ValueError('Un contact ne peut pas être daté dans le futur')
        return self


class Decision(BaseModel):
    model_config=ConfigDict(extra='forbid',str_strip_whitespace=True)
    reason:str=Field(min_length=2,max_length=1000)
    confirmation:str=Field(min_length=1,max_length=160)
    detach_links:bool=False


async def assigned_user(database,identifier,agency,session):
    if not identifier:return
    u=await database.users.find_one({'id':identifier,'$or':[{'active':True},{'active':{'$exists':False}}],'role':{'$in':['direction','responsable','accueil']}},session=session)
    if not u or (u['role']!='direction' and u.get('agency')!=agency):raise HTTPException(422,'Affectataire actif de cette agence requis')


async def validate_business(database,d,body,session):
    if not (d.get('name') or '').strip() or not ((d.get('phone') or '').strip() or (d.get('email') or '').strip()):raise HTTPException(422,'Nom et téléphone ou email obligatoires')
    activity=activity_for(d)
    if d.get('sub_status') and d['sub_status'] not in SUB_STATUSES.get(activity,{}):raise HTTPException(422,'Sous-statut incompatible avec cette activité')
    if body.assigned_to is not None or 'agency' in body.model_fields_set:
        await assigned_user(database,d.get('assigned_to'),d['agency'],session)
    if d.get('rappel_date') or d.get('rappel_time'):
        if not d.get('rappel_date') or not d.get('rappel_time'):raise HTTPException(422,'Date et heure de rappel requises ensemble')
        if {'rappel_date','rappel_time','agency'} & body.model_fields_set:
            from server import rappel_times
            if d['rappel_time'] not in rappel_times(d['agency'],date.fromisoformat(d['rappel_date']).weekday()):raise HTTPException(422,'Rappel hors des horaires de cette agence')
    if body.status in ('non_interesse','non_inscrit') or body.sub_status in ('refusee','abandonnee'):
        config=await database.site_settings.find_one({'_id':'crm_workflow'},session=session) or {}
        reasons=config.get('non_registration_reasons',[])
        found=next((r for r in reasons if r['id']==d.get('non_registration_reason') and r.get('active',True)),None)
        if not found:raise HTTPException(422,'Sélectionnez un motif actif configuré par la Direction')
        if not (d.get('non_registration_comment') or '').strip():raise HTTPException(422,'Commentaire de non-inscription obligatoire')
        d['non_registration_label']=found['label']
    if body.status=='traite' or body.sub_status=='cloturee' or (body.status=='annule' and not d.get('creneau_id')):
        if not (d.get('closure_reason') or '').strip():raise HTTPException(422,'Motif de clôture obligatoire')
    if body.status=='inscrit':
        if d.get('session_id') and d.get('inscription_status')!='confirmee':raise HTTPException(409,'Validez l’inscription IA depuis le module sessions autorisé')
        if not body.confirm_enrollment and not d.get('enrollment_verified'):raise HTTPException(422,'Confirmez explicitement l’inscription réelle')
        d['enrolled_at']=d.get('enrolled_at') or iso()
        d['enrollment_verified']=True
    return d


async def schedule(database,d,session=None):
    if d.get('archived') or d.get('status') in TERMINAL:
        await database.relances.update_many({'demande_id':d['id'],'automatic':True,'done':False},{'$set':{'cancelled':True,'cancelled_at':iso()}},session=session)
        return
    started=d.get('created_at')
    if not started:return
    start=parse_time(started)
    for day in (1,3,7):
        due=start+timedelta(days=day)
        key='crm:'+d['id']+':J'+str(day)
        await database.relances.update_one({'_id':key},{'$setOnInsert':{'id':uuid.uuid4().hex,'demande_id':d['id'],
            'reference':d['reference'],'name':d['name'],'agency':d['agency'],'automatic':True,'step':'J+'+str(day),
            'due_at':due.isoformat(),'due_date':due.astimezone(PARIS).date().isoformat(),'note':'Relance interne J+'+str(day),
            'channel':'interne','done':False,'cancelled':False,'created_at':iso(),'created_by':'Automatisation CRM'}},upsert=True,session=session)

    await database.relances.update_many({'demande_id':d['id'],'automatic':True,'done':False},{'$set':{'cancelled':False}},session=session)


async def pending_tasks(database,d,session=None):
    await database.relances.update_many({'demande_id':d['id'],'done':False},{'$set':{'name':d['name'],'agency':d['agency'],'reference':d['reference']}},session=session)
    await schedule(database,d,session)


def callback_deadline(d):
    if d.get('rappel_date') and d.get('rappel_time'):
        return datetime.fromisoformat(d['rappel_date']+'T'+d['rappel_time']).replace(tzinfo=PARIS).astimezone(timezone.utc)+timedelta(hours=24)
    return parse_time(d['created_at'])+timedelta(hours=24)


async def alerts(database,q,at=None):
    at=at or instant();rows=[]
    async for d in database.demandes.find({**q,'type':'rappel','callback_handled_at':{'$in':[None,'']},'status':{'$nin':list(TERMINAL)}}):
        deadline=callback_deadline(d)
        if deadline<=at:rows.append({'id':'callback:'+d['id'],'demande_id':d['id'],'reference':d['reference'],'name':d['name'],'agency':d['agency'],
            'assigned_to':d.get('assigned_to'),'due_at':deadline.isoformat(),'kind':'rappel_24h','urgency':'haute'})
    return sorted(rows,key=lambda r:r['due_at'])


async def worker(database):
    from transactions import run
    async for candidate in database.demandes.find({'id':{'$exists':True},'created_at':{'$exists':True},'reference':{'$exists':True},'name':{'$exists':True},'agency':{'$in':['creteil','bonneuil']}}):
        async def operation(session):
            d=await database.demandes.find_one({'id':candidate['id']},session=session)
            if not d:return
            tasks=await database.relances.find({'demande_id':d['id'],'automatic':True},session=session).to_list(4)
            closed=d.get('archived') or d.get('status') in TERMINAL
            if closed and all(t.get('done') or t.get('cancelled') for t in tasks):return
            if not closed and len(tasks)==3 and all(t.get('done') or (not t.get('cancelled') and t.get('agency')==d['agency'] and t.get('name')==d['name']) for t in tasks):return
            if not closed:
                try:
                    if parse_time(d.get('created_at')) is None:
                        return
                except (ValueError, TypeError, AttributeError):
                    # Preserve imported records; never invent a timezone or block
                    # the other dossiers and notification services on one bad date.
                    __import__('logging').getLogger(__name__).warning('Date CRM invalide : vérification humaine requise')
                    return
            await database.demandes.update_one({'id':d['id']},{'$inc':{'crm_revision':1}},session=session)
            await pending_tasks(database,d,session)
        await run(database,operation)
