import training_schema
"""Phase 1 training administration; pedagogical execution remains phase 2."""
import uuid
from datetime import datetime, timezone
from typing import Literal
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field, ConfigDict, model_validator
from auth import require_roles, log_action
from crm import scope
from transactions import run

router = APIRouter(prefix='/crm/formations')
_db = None
actor = require_roles('direction', 'responsable', 'accueil')

def init(database):
    global _db
    _db = database

def now(): return datetime.now(timezone.utc).isoformat()
def clean(d): return {k:v for k,v in d.items() if k not in ('_id','revision','identity_key')}
async def record(collection, identity, user, session=None):
    value = await collection.find_one(scope(user, {'id':identity}), session=session)
    if not value: raise HTTPException(404, 'Fiche introuvable dans votre périmètre')
    return value

class Body(BaseModel):
    model_config = ConfigDict(extra='forbid', str_strip_whitespace=True)
class Catalog(Body):
    title: str = Field(min_length=2,max_length=160)
    category: Literal['permis','ia']
    prerequisites: list[str] = Field(default_factory=list,max_length=30)
    required_documents: list[str] = Field(default_factory=list,max_length=30)
    active: bool = True
class Person(Body):
    agency: Literal['creteil','bonneuil']
    name: str = Field(min_length=2,max_length=160)
    email: str = Field(default='',max_length=254)
    phone: str = Field(default='',max_length=40)
    prospect_id: str = Field(default='',max_length=100)
    @model_validator(mode='after')
    def contact(self):
        if not self.email and not self.phone: raise ValueError('Un moyen de contact est requis')
        if self.email:
            from email_validator import validate_email
            self.email=validate_email(self.email,check_deliverability=False,test_environment=True).normalized
        if self.phone:
            import re
            if not re.fullmatch(r'[+0-9(). -]+',self.phone) or not 6<=sum(c.isdigit() for c in self.phone)<=15: raise ValueError('Téléphone invalide')
        return self
class Session(Body):
    agency: Literal['creteil','bonneuil']
    catalog_id: str = Field(max_length=100)
    starts_at: datetime
    ends_at: datetime
    location: str = Field(min_length=2,max_length=200)
    speaker_id: str = Field(default='',max_length=100)
    capacity: int = Field(ge=1,le=500)
    status: Literal['brouillon','ouverte','fermee','annulee'] = 'brouillon'
    @model_validator(mode='after')
    def dates(self):
        if not self.starts_at.tzinfo or not self.ends_at.tzinfo or self.ends_at <= self.starts_at: raise ValueError('Dates horodatées cohérentes requises')
        return self
class Enrollment(Body):
    person_id: str = Field(max_length=100)
    session_id: str = Field(max_length=100)
class Admission(Body):
    status: Literal['confirmee','refusee','liste_attente','annulee']
    prerequisites_checked: bool = False
    documents_checked: bool = False
    documents: list[str] = Field(default_factory=list,max_length=30)
    document_requirements: dict[str,str] = Field(default_factory=dict)
    prerequisites_verified: list[str] = Field(default_factory=list,max_length=30)
    reason: str = Field(default='',max_length=1000)

@router.get('/catalogue')
async def catalog(user=Depends(actor)):
    scope(user,{})
    return [clean(d) for d in await _db.business_training_catalog.find({}).to_list(500)]
@router.post('/catalogue',status_code=201)
async def create_catalog(body: Catalog, request: Request, user=Depends(require_roles('direction'))):
    doc={'id':str(uuid.uuid4()),**body.model_dump(),'created_at':now()}
    await _db.business_training_catalog.insert_one(doc)
    await log_action('formation_catalogue_creation',request,user,doc['id'])
    return clean(doc)
@router.put('/catalogue/{identity}')
async def edit_catalog(identity:str, body:Catalog, request:Request,user=Depends(require_roles('direction'))):
    result=await _db.business_training_catalog.update_one({'id':identity},{'$set':body.model_dump()})
    if not result.matched_count: raise HTTPException(404,'Formation introuvable')
    await log_action('formation_catalogue_modification',request,user,identity)
    return clean(await _db.business_training_catalog.find_one({'id':identity}))
@router.get('/personnes')
async def people(user=Depends(actor)):
    return [clean(d) for d in await _db.business_training_people.find(scope(user,{})).to_list(500)]
@router.post('/personnes',status_code=201)
async def create_person(body:Person, request:Request,user=Depends(actor)):
    if scope(user,{'agency':body.agency}).get('agency') != body.agency: raise HTTPException(403,'Agence non autorisée')
    await ensure_indexes(_db)
    key=body.email.casefold() if body.email else ''.join(c for c in body.phone if c.isdigit())
    async def operation(ms):
        if body.prospect_id:
            prospect=await record(_db.demandes,body.prospect_id,user,ms)
            if prospect.get('archived') or prospect['agency']!=body.agency: raise HTTPException(422,'Prospect actif de la même agence requis')
            await _db.demandes.update_one({'id':prospect['id']},{'$inc':{'crm_revision':1}},session=ms)
        old=await _db.business_training_people.find_one({'agency':body.agency,'identity_key':key},session=ms)
        if old:
            if body.prospect_id and body.prospect_id!=old.get('prospect_id'): raise HTTPException(409,'Ce contact possède déjà une fiche ; son lien prospect est immuable')
            return clean(old)
        doc={'id':str(uuid.uuid4()),**body.model_dump(),'identity_key':key,'created_at':now()}
        await _db.business_training_people.insert_one(doc,session=ms)
        await log_action('formation_personne_enregistrement',request,user,doc['id'],mongo_session=ms)
        return clean(doc)
    from pymongo.errors import DuplicateKeyError
    try: return await run(_db,operation)
    except DuplicateKeyError:
        existing=await _db.business_training_people.find_one({'agency':body.agency,'identity_key':key})
        if not existing or (body.prospect_id and existing.get('prospect_id')!=body.prospect_id): raise HTTPException(409,'Contact déjà associé à une autre fiche')
        return clean(existing)
@router.get('/sessions')
async def sessions(user=Depends(actor)):
    rows=await _db.business_training_sessions.find(scope(user,{})).sort('starts_at',1).to_list(500)
    for d in rows:
        d['confirmed']=await _db.business_training_enrollments.count_documents({'session_id':d['id'],'status':'confirmee'})
        d['remaining']=max(0,d['capacity']-d['confirmed'])
    return [clean(d) for d in rows]
async def session_values(body,user,mongo_session,exclude_id=None):
    if scope(user,{'agency':body.agency}).get('agency') != body.agency: raise HTTPException(403,'Agence non autorisée')
    cat=await _db.business_training_catalog.find_one({'id':body.catalog_id,'active':True},session=mongo_session)
    if not cat: raise HTTPException(422,'Formation active requise')
    if body.speaker_id:
        speaker=await record(_db.business_speakers,body.speaker_id,user,mongo_session)
        if speaker['agency']!=body.agency or not speaker.get('active',True): raise HTTPException(422,'Intervenant actif de la même agence requis')
        # Touch the intervenant to serialize competing assignments and availability edits.
        await _db.business_speakers.update_one({'id':speaker['id']},{'$inc':{'revision':1}},session=mongo_session)
        overlaps=await _db.business_training_sessions.count_documents({'speaker_id':speaker['id'],'id':{'$ne':exclude_id},'status':{'$ne':'annulee'},'starts_at':{'$lt':body.ends_at.astimezone(timezone.utc).isoformat()},'ends_at':{'$gt':body.starts_at.astimezone(timezone.utc).isoformat()}},session=mongo_session)
        if overlaps: raise HTTPException(409,'Intervenant déjà affecté à une session sur ces horaires')
        from business_speakers import availability_conflicts
        if availability_conflicts(speaker,body.starts_at,body.ends_at): raise HTTPException(409,'Intervenant indisponible sur ces horaires')
    return {**body.model_dump(),'starts_at':body.starts_at.astimezone(timezone.utc).isoformat(),'ends_at':body.ends_at.astimezone(timezone.utc).isoformat(),'category':cat['category']}
@router.post('/sessions',status_code=201)
async def create_session(body:Session,request:Request,user=Depends(actor)):
    async def operation(ms):
        values=await session_values(body,user,ms)
        doc={'id':str(uuid.uuid4()),**values,'created_at':now(),'revision':0,'pedagogy':training_schema.empty()}
        await _db.business_training_sessions.insert_one(doc,session=ms)
        await log_action('formation_session_creation',request,user,doc['id'],mongo_session=ms)
        return clean(doc)
    return await run(_db,operation)
@router.put('/sessions/{identity}')
async def edit_session(identity:str,body:Session,request:Request,user=Depends(actor)):
    async def operation(ms):
        old=await record(_db.business_training_sessions,identity,user,ms)
        values=await session_values(body,user,ms,identity)
        if old['agency'] != body.agency: raise HTTPException(409,'Réaffectation de session non prévue')
        count=await _db.business_training_enrollments.count_documents({'session_id':identity,'status':'confirmee'},session=ms)
        active=await _db.business_training_enrollments.count_documents({'session_id':identity,'status':{'$nin':['refusee','annulee']}},session=ms)
        if active and any(values[k]!=old[k] for k in ('catalog_id','starts_at','ends_at','speaker_id')): raise HTTPException(409,'Annulez les inscriptions actives avant de modifier la formation ou les horaires')
        if active and body.status=='annulee': raise HTTPException(409,'Annulez les inscriptions actives avant la session')
        if body.capacity<count: raise HTTPException(409,'Capacité inférieure aux admissions confirmées')
        if count and body.status=='annulee': raise HTTPException(409,'Annulez les inscriptions avant la session')
        await _db.business_training_sessions.update_one({'id':identity},{'$set':values,'$inc':{'revision':1}},session=ms)
        await log_action('formation_session_modification',request,user,identity,mongo_session=ms)
        return clean({**old,**values})
    return await run(_db,operation)
@router.get('/inscriptions')
async def enrollments(user=Depends(actor)):
    return [clean(d) for d in await _db.business_training_enrollments.find(scope(user,{})).to_list(1000)]
@router.post('/inscriptions',status_code=201)
async def enroll(body:Enrollment,request:Request,user=Depends(actor)):
    async def operation(ms):
        s=await record(_db.business_training_sessions,body.session_id,user,ms)
        p=await record(_db.business_training_people,body.person_id,user,ms)
        if p['agency']!=s['agency']: raise HTTPException(422,'Agences incompatibles')
        if s['status']!='ouverte' or datetime.fromisoformat(s['starts_at'])<=datetime.now(timezone.utc): raise HTTPException(409,'Session non ouverte')
        await _db.business_training_sessions.update_one({'id':s['id']},{'$inc':{'revision':1}},session=ms)
        old=await _db.business_training_enrollments.find_one({'session_id':s['id'],'person_id':p['id']},session=ms)
        if old: return clean(old)
        confirmed=await _db.business_training_enrollments.count_documents({'session_id':s['id'],'status':'confirmee'},session=ms)
        doc={'id':str(uuid.uuid4()),'person_id':p['id'],'session_id':s['id'],'agency':s['agency'],'status':'liste_attente' if confirmed>=s['capacity'] else 'preinscrite','created_at':now(),'history':[],'documents':[]}
        await _db.business_training_enrollments.insert_one(doc,session=ms)
        await log_action('formation_preinscription',request,user,doc['id'],mongo_session=ms)
        return clean(doc)
    return await run(_db,operation)
@router.patch('/inscriptions/{identity}')
async def admission(identity:str,body:Admission,request:Request,user=Depends(require_roles('direction','responsable'))):
    async def operation(ms):
        e=await record(_db.business_training_enrollments,identity,user,ms)
        s=await record(_db.business_training_sessions,e['session_id'],user,ms)
        person=await record(_db.business_training_people,e['person_id'],user,ms)
        prospect=None
        if person.get('prospect_id'):
            prospect=await record(_db.demandes,person['prospect_id'],user,ms)
            if prospect.get('archived') or prospect['agency']!=e['agency']: raise HTTPException(422,'Le prospect lié a changé de périmètre ; admission suspendue')
            await _db.demandes.update_one({'id':prospect['id']},{'$inc':{'crm_revision':1}},session=ms)
        await _db.business_training_sessions.update_one({'id':s['id']},{'$inc':{'revision':1}},session=ms)
        if body.status=='confirmee':
            if s['status']!='ouverte' or datetime.fromisoformat(s['starts_at'])<=datetime.now(timezone.utc): raise HTTPException(409,'Session non ouverte')
            if not body.prerequisites_checked or not body.documents_checked: raise HTTPException(422,'Contrôle humain des prérequis et pièces requis')
            cat=await _db.business_training_catalog.find_one({'id':s['catalog_id']},session=ms)
            if any(x not in body.prerequisites_verified for x in cat.get('prerequisites',[])): raise HTTPException(422,'Chaque prérequis doit être vérifié humainement')
            if any(not body.document_requirements.get(x) for x in cat.get('required_documents',[])): raise HTTPException(422,'Chaque pièce requise doit être associée à un justificatif')
            if any(v not in body.documents for v in body.document_requirements.values()): raise HTTPException(422,'Justificatifs non associés à la candidature')
            if body.documents:
                from business_documents import authorized_document
                for identity_doc in body.documents:
                    document=await authorized_document(_db,identity_doc,user,session=ms)
                    if document['agency']!=e['agency']: raise HTTPException(422,'Justificatif d’une autre agence')
                    await _db.private_documents.update_one({'id':identity_doc},{'$inc':{'revision':1}},session=ms)
            count=await _db.business_training_enrollments.count_documents({'session_id':s['id'],'status':'confirmee','id':{'$ne':identity}},session=ms)
            if count>=s['capacity']: raise HTTPException(409,"Session complète : sélectionner la liste d'attente")
        if body.status=='refusee' and not body.reason: raise HTTPException(422,'Motif de refus requis')
        if all(e.get(k)==v for k,v in body.model_dump().items()): return clean(e)
        changes={**body.model_dump(),'decided_by':user['id'],'decided_at':now()}
        if body.status=='confirmee': changes['requirements_snapshot']={'catalog_id':cat['id'],'prerequisites':cat.get('prerequisites',[]),'required_documents':cat.get('required_documents',[])}
        history={'at':now(),'by':user['id'],'from':e['status'],'to':body.status,'reason':body.reason}
        await _db.business_training_enrollments.update_one({'id':identity},{'$set':changes,'$push':{'history':history}},session=ms)
        if prospect:
            from crm_workflow import pending_tasks
            updates={}
            if body.status=='confirmee':
                updates={'status':'inscrit','enrollment_verified':True,'enrolled_at':prospect.get('enrolled_at') or now(),'training_enrollment_id':identity}
            elif prospect.get('training_enrollment_id')==identity and not prospect.get('inscription_status')=='confirmee':
                remaining=await _db.business_training_enrollments.find_one({'person_id':person['id'],'status':'confirmee','id':{'$ne':identity}},session=ms)
                if remaining: updates={'training_enrollment_id':remaining['id']}
                else: updates={'status':'nouveau','enrollment_verified':False,'enrolled_at':None,'training_enrollment_id':None}
            if updates:
                event={'at':now(),'by':user['name'],'kind':'formation','text':'Admission formation confirmée humainement' if body.status=='confirmee' else 'Admission formation révisée : '+body.status,'action':'formation_admission','from':prospect.get('status'),'to':updates.get('status',prospect.get('status')),'enrollment_id':identity}
                await _db.demandes.update_one({'id':prospect['id']},{'$set':updates,'$push':{'history':event}},session=ms)
                await pending_tasks(_db,{**prospect,**updates},ms)
        await log_action('formation_admission',request,user,identity,{'status':body.status},mongo_session=ms)
        return clean({**e,**changes,'history':e['history']+[history]})
    return await run(_db,operation)

async def ensure_indexes(database):
    await database.business_training_people.create_index([('agency',1),('identity_key',1)],unique=True)
    await database.business_training_enrollments.create_index([('session_id',1),('person_id',1)],unique=True)

@router.put('/personnes/{identity}')
async def edit_person(identity:str,body:Person,request:Request,user=Depends(actor)):
    from pymongo.errors import DuplicateKeyError
    await record(_db.business_training_people,identity,user)
    if scope(user,{'agency':body.agency}).get('agency')!=body.agency: raise HTTPException(403,'Agence non autorisée')
    old=await _db.business_training_people.find_one({'id':identity})
    if old['agency']!=body.agency: raise HTTPException(409,'Réaffectation de personne non prévue')
    if body.prospect_id!=old.get('prospect_id',''): raise HTTPException(409,'Lien prospect immuable')
    key=body.email.casefold() if body.email else ''.join(c for c in body.phone if c.isdigit())
    try: await _db.business_training_people.update_one({'id':identity},{'$set':{**body.model_dump(),'identity_key':key,'updated_at':now()}})
    except DuplicateKeyError: raise HTTPException(409,'Une fiche avec ce contact existe déjà dans cette agence')
    await log_action('formation_personne_modification',request,user,identity)
    return clean(await _db.business_training_people.find_one({'id':identity}))
