"""Phase-one road safety dossiers, manual quotes with Direction approval."""
import uuid
from datetime import datetime
from typing import Literal
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field, ConfigDict
from auth import require_roles, log_action
from crm import scope
from transactions import run
from business_organizations import now, documents
router=APIRouter(prefix='/crm/securite-routiere'); _db={}
def init(db): _db['db']=db
roles=require_roles('direction','responsable','accueil')
STATUSES={'recue':'Reçue','a_qualifier':'À qualifier','devis_a_preparer':'Devis à préparer','proposition_envoyee':'Proposition envoyée','acceptee':'Acceptée','refusee':'Refusée','realisee':'Réalisée','cloturee':'Clôturée'}
class Intervention(BaseModel):
    model_config=ConfigDict(extra='forbid',str_strip_whitespace=True)
    agency: Literal['creteil','bonneuil']
    organization_id: str = Field(min_length=1,max_length=120)
    contact_name: str = Field(default='',max_length=120)
    prospect_id: str | None = Field(default=None,max_length=120)
    audience: str = Field(default='',max_length=200)
    headcount: int | None = Field(default=None,ge=0,le=100000)
    action: str = Field(min_length=2,max_length=300)
    location: str = Field(default='',max_length=300)
    requested_dates: list[str] = Field(default_factory=list,max_length=30)
    comment: str = Field(default='',max_length=3000)
    status: str = 'recue'
    assigned_to: str | None = Field(default=None,max_length=120)
    next_action: str = Field(default='',max_length=500)
    deadline: str | None = Field(default=None,max_length=40)
    document_ids: list[str] = Field(default_factory=list,max_length=30)
    quote_document_id: str | None = Field(default=None,max_length=120)
async def fetch(identifier,user,session=None):
    d=await _db['db'].business_road_safety.find_one(scope(user,{'id':identifier}),{'_id':0},session=session)
    if not d: raise HTTPException(404,'Demande introuvable')
    if d.get('deadline'): d['overdue']=d['deadline']<now() and d['status'] not in ('cloturee','refusee')
    return d
async def save(body,user,identifier=None):
    db=_db['db']; fields=body.model_dump(); scope(user,{})
    if user['role']!='direction' and body.agency!=user.get('agency'): raise HTTPException(403,'Agence non autorisée')
    if body.status not in STATUSES: raise HTTPException(422,'Statut inconnu')
    for value in body.requested_dates:
        try: datetime.fromisoformat(value)
        except ValueError: raise HTTPException(422,'Date invalide')
    if body.deadline:
        try:
            dt=datetime.fromisoformat(body.deadline.replace('Z','+00:00'))
            if not dt.tzinfo: raise ValueError()
            fields['deadline']=dt.astimezone(__import__('datetime').timezone.utc).isoformat()
        except ValueError: raise HTTPException(422,'Échéance avec fuseau horaire requise')
    async def operation(session):
        old=await fetch(identifier,user,session) if identifier else None
        if old and old['agency']!=body.agency: raise HTTPException(422,'Conserver l’agence du dossier')
        org=await db.business_organizations.find_one(scope(user,{'id':body.organization_id,'agency':body.agency}),session=session)
        if not org or org['agency']!=body.agency: raise HTTPException(422,'Organisme inaccessible ou agence différente')
        if body.contact_name and body.contact_name not in [c['name'] for c in org.get('contacts',[])]: raise HTTPException(422,'Interlocuteur absent de la fiche organisme')
        await db.business_organizations.update_one({'id':body.organization_id},{'$inc':{'revision':1}},session=session)
        if body.prospect_id:
            p=await db.demandes.find_one({'id':body.prospect_id,'agency':body.agency,'archived':{'$ne':True}},session=session)
            if not p: raise HTTPException(422,'Prospect absent ou agence différente')
            await db.demandes.update_one({'id':body.prospect_id},{'$inc':{'crm_revision':1}},session=session)
        if body.assigned_to:
            u=await db.users.find_one({'id':body.assigned_to,'active':{'$ne':False},'role':{'$in':['direction','responsable','accueil']}},session=session)
            if not u or (u['role']!='direction' and u.get('agency')!=body.agency): raise HTTPException(422,'Responsable non autorisé dans cette agence')
        await documents(db,body.document_ids+([body.quote_document_id] if body.quote_document_id else []),user,body.agency,session)
        approval=(old or {}).get('quote_approval') if (old or {}).get('quote_document_id')==body.quote_document_id else None
        if body.status=='proposition_envoyee':
            if not body.quote_document_id or not approval: raise HTTPException(409,'Un devis externe approuvé par la Direction est requis ; aucun envoi automatique')
            from business_documents import authorized_document
            current=await authorized_document(db,body.quote_document_id,user,session=session)
            if not current.get('versions') or current['versions'][-1].get('review_status')!='valide' or current.get('mime_type')!='application/pdf': raise HTTPException(409,'Le devis doit rester validé et au format PDF')
            if current.get('current_version')!=approval.get('version'): raise HTTPException(409,'Le devis a changé : nouvelle approbation Direction requise')
            await db.private_documents.update_one({'id':body.quote_document_id},{'$inc':{'revision':1}},session=session)
        record={**fields,'id':identifier or str(uuid.uuid4()),'created_at':(old or {}).get('created_at',now()),'updated_at':now(),'quote_approval':approval,'history':(old or {}).get('history',[])+[{'at':now(),'by':user['id'],'action':'modification' if old else 'creation','status':body.status}]}
        await db.business_road_safety.replace_one({'id':record['id']},record,upsert=True,session=session)
        await log_action('road_safety_update' if old else 'road_safety_create',user=user,target=record['id'],meta={'agency':body.agency,'status':body.status},mongo_session=session)
        return record
    return await run(db,operation)
@router.get('/meta')
async def meta(user=Depends(roles)): return {'statuses':STATUSES,'real_sending_enabled':False}
@router.get('')
async def listing(user=Depends(roles)):
    rows=await _db['db'].business_road_safety.find(scope(user,{}),{'_id':0}).sort('created_at',-1).to_list(500)
    for r in rows: r['overdue']=bool(r.get('deadline') and r['deadline']<now() and r['status'] not in ('cloturee','refusee'))
    return rows
@router.post('',status_code=201)
async def create(body:Intervention,user=Depends(roles)): return await save(body,user)
@router.get('/{identifier}')
async def detail(identifier:str,user=Depends(roles)): return await fetch(identifier,user)
@router.put('/{identifier}')
async def update(identifier:str,body:Intervention,user=Depends(roles)): return await save(body,user,identifier)
@router.post('/{identifier}/devis/approbation')
async def approve(identifier:str,user=Depends(require_roles('direction'))):
    db=_db['db']
    async def operation(session):
        d=await fetch(identifier,user,session)
        if not d.get('quote_document_id'): raise HTTPException(409,'Joindre d’abord le devis externe')
        await documents(db,[d['quote_document_id']],user,d['agency'],session)
        # Approval binds to the precise immutable current document version.
        from business_documents import authorized_document
        document=await authorized_document(db,d['quote_document_id'],user,session=session)
        if document.get('mime_type') != 'application/pdf': raise HTTPException(422,'Un devis PDF est requis')
        if not document.get('versions') or document['versions'][-1].get('review_status')!='valide': raise HTTPException(409,'Le document doit être vérifié et validé par la Direction')
        await db.private_documents.update_one({'id':d['quote_document_id']},{'$inc':{'revision':1}},session=session)
        approval={'by':user['id'],'at':now(),'document_id':d['quote_document_id'],'version':document.get('current_version',document.get('version'))}
        await db.business_road_safety.update_one({'id':identifier},{'$set':{'quote_approval':approval},'$push':{'history':{'at':now(),'by':user['id'],'action':'devis_approuve'}}},session=session)
        await log_action('road_safety_quote_approved',user=user,target=identifier,meta={'document_id':d['quote_document_id'],'version':approval['version']},mongo_session=session)
        return {'approval':approval,'real_sending_enabled':False}
    return await run(db,operation)
