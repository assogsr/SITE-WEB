"""Manual phase-1 deadline register. No implied legal retention or renewal periods."""
import uuid
from datetime import date, datetime, timezone, timedelta
from typing import Literal, Optional
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, ConfigDict, Field
from auth import get_current_user, log_action
from crm import scope
from transactions import run as run_transaction
from zoneinfo import ZoneInfo

router=APIRouter(prefix="/crm/echeances",tags=["Échéances"])
_db={}
def init(database): _db["db"]=database
def db(): return _db["db"]
def now(): return datetime.now(timezone.utc).isoformat()
class Record(BaseModel):
    model_config=ConfigDict(extra="forbid",str_strip_whitespace=True)
    agency: Literal["creteil","bonneuil"]
    name: str=Field(min_length=2,max_length=160)
    category: str=Field(min_length=2,max_length=160)
    responsible_id: str=Field(min_length=1,max_length=100)
    due_date: date
    document_id: Optional[str]=Field(default=None,max_length=100)
    alert_days: list[int]=Field(default_factory=list,max_length=50)
    notes: str=Field(default="",max_length=4000)
class Renewal(BaseModel):
    model_config=ConfigDict(extra="forbid",str_strip_whitespace=True)
    document_id: str=Field(min_length=1,max_length=100)
    note: str=Field(min_length=2,max_length=2000)
    next_due_date: Optional[date]=None
async def authorized_doc(identifier,user,session=None,agency=None):
    if identifier:
        from business_documents import authorized_document
        item=await authorized_document(db(),identifier,user,session=session)
        if agency and item.get("agency") != agency: raise HTTPException(422,"Justificatif d’une autre agence non autorisé")
        await db().private_documents.update_one({"id":identifier},{"$inc":{"revision":1}},session=session)
        return item
async def validate(body,user,session=None):
    if any(day < 0 or day > 3650 for day in body.alert_days): raise HTTPException(422,"Délai d’alerte entre 0 et 3650 jours requis")
    responsible=await db().users.find_one({"id":body.responsible_id,"active":{"$ne":False},"role":{"$in":["direction","responsable","accueil"]}},session=session)
    if not responsible or (responsible["role"] != "direction" and responsible.get("agency") != body.agency): raise HTTPException(422,"Responsable actif de l’agence ou Direction requis")
    await authorized_doc(body.document_id,user,session,agency=body.agency)
async def get_record(identifier,user,session=None):
    item=await db().business_deadlines.find_one(scope(user,{"id":identifier}),{"_id":0},session=session)
    if not item: raise HTTPException(404,"Échéance introuvable")
    return item
@router.get("/alertes")
async def alerts(user=Depends(get_current_user)):
    today=datetime.now(ZoneInfo("Europe/Paris")).date()
    result=[]
    async for item in db().business_deadlines.find(scope(user,{"status":"ouverte"}),{"_id":0}):
        due=date.fromisoformat(item["due_date"])
        overdue=due < today
        if overdue or any(today >= due-timedelta(days=day) for day in item.get("alert_days",[])):
            result.append({**item,"overdue":overdue,"days_until":(due-today).days})
    return sorted(result,key=lambda item:item["due_date"])
@router.get("")
async def list_records(user=Depends(get_current_user)):
    return await db().business_deadlines.find(scope(user,{}),{"_id":0}).sort("due_date",1).to_list(1000)
@router.post("",status_code=201)
async def create(body:Record,user=Depends(get_current_user)):
    scope(user,{})
    if user["role"] != "direction" and body.agency != user.get("agency"): raise HTTPException(403,"Agence non autorisée")
    async def operation(session):
        await validate(body,user,session)
        item=body.model_dump(mode="json")
        item.update(id=str(uuid.uuid4()),status="ouverte",created_at=now(),history=[{"at":now(),"actor":user["id"],"event":"creation"}])
        await db().business_deadlines.insert_one(dict(item),session=session)
        await log_action("business_deadlines_create",user=user,target=item["id"],mongo_session=session)
        return item
    return await run_transaction(db(),operation)
@router.get("/{identifier}")
async def read(identifier:str,user=Depends(get_current_user)): return await get_record(identifier,user)
@router.put("/{identifier}")
async def update(identifier:str,body:Record,user=Depends(get_current_user)):
    async def operation(session):
        item=await get_record(identifier,user,session)
        if item["status"] != "ouverte": raise HTTPException(409,"Échéance clôturée non modifiable")
        if item["agency"] != body.agency: raise HTTPException(409,"Réaffectation d’agence non prévue")
        await validate(body,user,session)
        await db().business_deadlines.update_one(scope(user,{"id":identifier,"status":"ouverte"}),{"$set":body.model_dump(mode="json"),"$push":{"history":{"at":now(),"actor":user["id"],"event":"modification"}}},session=session)
        await log_action("business_deadlines_update",user=user,target=identifier,mongo_session=session)
        return await get_record(identifier,user,session)
    return await run_transaction(db(),operation)
@router.post("/{identifier}/renouveler")
async def renew(identifier:str,body:Renewal,user=Depends(get_current_user)):
    if user["role"] != "direction": raise HTTPException(403,"Validation de renouvellement réservée à la Direction")
    async def operation(session):
        item=await get_record(identifier,user,session)
        if item["status"] != "ouverte": raise HTTPException(409,"Échéance déjà clôturée")
        if body.next_due_date and body.next_due_date.isoformat() <= item["due_date"]: raise HTTPException(422,"Nouvelle échéance postérieure requise")
        proof=await authorized_doc(body.document_id,user,session,agency=item["agency"])
        versions=proof.get("versions",[])
        if not versions or versions[-1].get("review_status") != "valide": raise HTTPException(409,"Dernière version du justificatif non validée par la Direction")
        next_id=str(uuid.uuid4()) if body.next_due_date else None
        event={"at":now(),"actor":user["id"],"event":"renouvellement_valide","document_id":body.document_id,"note":body.note,"next_id":next_id}
        await db().business_deadlines.update_one({"id":identifier,"status":"ouverte"},{"$set":{"status":"renouvelee","document_id":body.document_id,"validated_by":user["id"],"validated_at":now()},"$push":{"history":event}},session=session)
        if next_id:
            renewed={key:value for key,value in item.items() if key not in ("_id","id","history","created_at","status","validated_by","validated_at")}
            renewed.update(id=next_id,due_date=body.next_due_date.isoformat(),status="ouverte",created_at=now(),previous_id=identifier,document_id=body.document_id,history=[event])
            await db().business_deadlines.insert_one(renewed,session=session)
        await log_action("business_deadlines_renew",user=user,target=identifier,meta={"next_id":next_id},mongo_session=session)
        return {"id":identifier,"status":"renouvelee","next_id":next_id}
    return await run_transaction(db(),operation)
