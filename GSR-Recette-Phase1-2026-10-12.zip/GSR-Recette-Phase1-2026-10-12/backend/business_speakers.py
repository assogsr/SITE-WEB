import uuid
import re
import hashlib
from pymongo.errors import DuplicateKeyError
from datetime import datetime, timezone, date
from typing import Optional, Literal
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field, ConfigDict, field_validator
from auth import get_current_user, log_action
from crm import scope
from transactions import run

_db = {}
def init(database): _db["db"] = database
def db(): return _db["db"]
def now(): return datetime.now(timezone.utc).isoformat()
def direction(user):
    if user["role"] != "direction": raise HTTPException(403, "Validation réservée à la Direction")
def instant(value):
    try:
        parsed = value if isinstance(value,datetime) else datetime.fromisoformat(value.replace("Z", "+00:00"))
        if parsed.tzinfo is None: raise ValueError()
        return parsed.astimezone(timezone.utc)
    except (ValueError, AttributeError): raise HTTPException(422, "Date et heure avec fuseau requises")
async def documents(ids, user, agency, session=None):
    if not ids: return
    from business_documents import authorized_document
    for identifier in ids:
        item=await authorized_document(db(), identifier, user,session=session)
        if item.get("agency") != agency: raise HTTPException(422,"Justificatif d’une autre agence non autorisé")
        await db().private_documents.update_one({"id":identifier},{"$inc":{"revision":1}},session=session)
async def get_record(identifier, user, session=None):
    result = await db()[COLLECTION].find_one(scope(user, {"id":identifier}), {"_id":0,"identity_key":0},session=session)
    if not result: raise HTTPException(404,"Fiche introuvable")
    return result
class Availability(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)
    start: str
    end: str
    available: bool
    note: str = Field(default="", max_length=1000)
    @field_validator("end")
    @classmethod
    def end_time(cls, value, info):
        if "start" not in info.data: return value
        if instant(value) <= instant(info.data["start"]): raise ValueError("Fin postérieure au début requise")
        return value

def availability_conflicts(record, start, end):
    start, end = instant(start), instant(end)
    return [item for item in record.get("availability", []) if not item["available"] and instant(item["start"]) < end and instant(item["end"]) > start]

COLLECTION="business_speakers"
router=APIRouter(prefix="/crm/intervenants",tags=["Intervenants"])
class Record(BaseModel):
    model_config=ConfigDict(extra="forbid",str_strip_whitespace=True)
    agency: Literal["creteil","bonneuil"]
    name: str=Field(min_length=2,max_length=160)
    email: str=Field(default="",max_length=254)
    phone: str=Field(default="",max_length=40)
    skills: list[str]=Field(default_factory=list,max_length=100)
    domains: list[str]=Field(default_factory=list,max_length=100)
    availability: list[Availability]=Field(default_factory=list,max_length=200)
    document_ids: list[str]=Field(default_factory=list,max_length=100)
    validity_date: Optional[date]=None
    active: bool=True
    notes: str=Field(default="",max_length=4000)
    @field_validator("skills","domains","document_ids")
    @classmethod
    def strings(cls,value):
        if any(not item.strip() or len(item)>200 for item in value): raise ValueError("Valeur vide ou trop longue")
        return list(dict.fromkeys(value))
    @field_validator("email")
    @classmethod
    def valid_email(cls,value):
        if value:
            from email_validator import validate_email, EmailNotValidError
            try: return validate_email(value,check_deliverability=False,test_environment=True).normalized
            except EmailNotValidError: raise ValueError("Email invalide")
        return value
    @field_validator("phone")
    @classmethod
    def valid_phone(cls,value):
        if not value: return value
        if not re.fullmatch(r"[+() .\-0-9]+",value): raise ValueError("Téléphone invalide")
        digits="".join(c for c in value if c.isdigit())
        if not 6 <= len(digits) <= 15: raise ValueError("Téléphone de 6 à 15 chiffres requis")
        return value

def identity_key(body):
    if body.email:
        identity="email:"+body.email.casefold()
    elif body.phone:
        identity="phone:"+"".join(c for c in body.phone if c.isdigit())
    else:
        identity="name:"+" ".join(body.name.casefold().split())
    return hashlib.sha256(identity.encode("utf-8")).hexdigest()

async def ensure_indexes():
    # Partial index preserves untouched historical records which lack a materialized identity.
    await db()[COLLECTION].create_index([("agency",1),("identity_key",1)],unique=True,
        partialFilterExpression={"identity_key":{"$type":"string"}},name="speaker_identity_per_agency")

async def ensure_unique(body,session,exclude=None):
    query={"agency":body.agency,"identity_key":identity_key(body)}
    if exclude: query["id"]={"$ne":exclude}
    if await db()[COLLECTION].find_one(query,{"id":1},session=session):
        raise HTTPException(409,"Une fiche intervenant utilise déjà cette identité dans cette agence")
    # Do not silently merge or rewrite legacy records.
    legacy={"agency":body.agency,"identity_key":{"$exists":False}}
    if exclude: legacy["id"]={"$ne":exclude}
    if body.email:
        legacy["email"]={"$regex":"^"+re.escape(body.email)+"$","$options":"i"}
    elif body.phone:
        digits="".join(c for c in body.phone if c.isdigit())
        legacy.update(email={"$in":["",None]},phone={"$regex":r"^\D*"+r"\D*".join(digits)+r"\D*$"})
    else:
        legacy.update(email={"$in":["",None]},phone={"$in":["",None]},name={"$regex":r"^\s*"+r"\s+".join(re.escape(part) for part in body.name.split())+r"\s*$","$options":"i"})
    if await db()[COLLECTION].find_one(legacy,{"id":1},session=session):
        raise HTTPException(409,"Une fiche intervenant historique utilise déjà cette identité dans cette agence")

async def unique_transaction(operation):
    try: return await run(db(),operation)
    except DuplicateKeyError:
        raise HTTPException(409,"Une fiche intervenant utilise déjà cette identité dans cette agence")

async def validate_record(body,user,session=None):
    await documents(body.document_ids,user,body.agency,session)

@router.get("")
async def list_records(user=Depends(get_current_user)):
    return await db()[COLLECTION].find(scope(user, {}), {"_id":0,"identity_key":0}).sort("name",1).to_list(1000)
@router.post("", status_code=201)
async def create(body: Record, user=Depends(get_current_user)):
    scope(user,{})
    if user["role"] != "direction" and body.agency != user.get("agency"): raise HTTPException(403,"Agence non autorisée")
    await ensure_indexes()
    async def operation(session):
        await ensure_unique(body,session)
        await validate_record(body,user,session)
        item=body.model_dump(mode="json")
        item.update(id=str(uuid.uuid4()),created_at=now(),updated_at=now(),history=[{"at":now(),"actor":user["id"],"event":"creation"}])
        await db()[COLLECTION].insert_one({**item,"identity_key":identity_key(body)},session=session)
        await log_action(COLLECTION+"_create",user=user,target=item["id"],mongo_session=session)
        return item
    return await unique_transaction(operation)
@router.get("/{identifier}")
async def read(identifier: str,user=Depends(get_current_user)): return await get_record(identifier,user)
@router.put("/{identifier}")
async def update(identifier: str,body: Record,user=Depends(get_current_user)):
    scope(user,{})
    await ensure_indexes()
    async def operation(session):
        item=await get_record(identifier,user,session)
        if body.agency != item["agency"]: raise HTTPException(409,"Réaffectation d’agence non prévue : créer une demande à la Direction")
        await ensure_unique(body,session,exclude=identifier)
        await validate_record(body,user,session)
        updated=body.model_dump(mode="json");updated.update(updated_at=now(),identity_key=identity_key(body))
        await db()[COLLECTION].update_one(scope(user,{"id":identifier}),{"$set":updated,"$push":{"history":{"at":now(),"actor":user["id"],"event":"modification"}}},session=session)
        await log_action(COLLECTION+"_update",user=user,target=identifier,mongo_session=session)
        return await get_record(identifier,user,session)
    return await unique_transaction(operation)
