"""User-scoped CRM preferences and agency-protected prospect document links."""
from datetime import date, datetime, timezone
from typing import Literal
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, ConfigDict, Field, model_validator
from auth import require_roles, log_action
from transactions import run
from business_documents import authorized_document
from crm import prospect_scope

router=APIRouter(prefix='/crm')
store={}
allowed=require_roles('direction','responsable','accueil')
COLUMNS=('reference','name','type','agency','contact','created_at','status','assigned_to','next_action')
def init(db):store['db']=db
def db():return store['db']
class Filters(BaseModel):
    model_config=ConfigDict(extra='forbid')
    q:str=Field(default='',max_length=120)
    status:str=Field(default='',max_length=40)
    type:str=Field(default='',max_length=40)
    agency:Literal['','creteil','bonneuil']=''
    assigned_to:str=Field(default='',max_length=120)
    start:str=''
    end:str=''
    due:str=''
    archived:bool=False
    @model_validator(mode='after')
    def dates(self):
        for v in [self.start,self.end,self.due]:
            if v:date.fromisoformat(v)
        if self.start and self.end and self.end<self.start:raise ValueError('Période inversée')
        return self
class Preferences(BaseModel):
    model_config=ConfigDict(extra='forbid')
    columns:list[str]=Field(default_factory=lambda:list(COLUMNS[:7]),min_length=1,max_length=9)
    sort:Literal['created_at','name','reference','agency','status','next_action_due']='created_at'
    order:Literal['asc','desc']='desc'
    filters:Filters=Field(default_factory=Filters)
    @model_validator(mode='after')
    def columns_valid(self):
        if len(set(self.columns))!=len(self.columns) or set(self.columns)-set(COLUMNS):raise ValueError('Colonnes invalides')
        return self
@router.get('/preferences/prospects')
async def preferences(user=Depends(allowed)):
    row=await db().user_preferences.find_one({'_id':user['id']+':prospects'})
    value=(row or {}).get('value',Preferences().model_dump())
    if user['role']!='direction':value['filters']['archived']=False
    return value
@router.put('/preferences/prospects')
async def save_preferences(body:Preferences,request:Request,user=Depends(allowed)):
    if body.filters.archived and user['role']!='direction':raise HTTPException(403,'Archives réservées à la Direction')
    value=body.model_dump()
    await db().user_preferences.update_one({'_id':user['id']+':prospects'},{'$set':{'value':value}},upsert=True)
    await log_action('crm_preferences',request,user)
    return value
class Link(BaseModel):
    model_config=ConfigDict(extra='forbid')
    document_id:str=Field(min_length=1,max_length=120)
    note:str=Field(default='',max_length=500)
async def parent(pid,user,session=None):
    row=await db().demandes.find_one(prospect_scope(user,{'id':pid}),session=session)
    if not row or (user['role']!='direction' and (row.get('archived') or row['agency']!=user.get('agency'))):raise HTTPException(403,'Documents limités à votre agence')
    return row
@router.get('/demandes/{pid}/documents')
async def documents(pid:str,user=Depends(allowed)):
    await parent(pid,user)
    result=[]
    async for link in db().prospect_document_links.find({'prospect_id':pid},{'_id':0}):
        try:doc=await authorized_document(db(),link['document_id'],user)
        except HTTPException:continue
        result.append({**link,'document':doc})
    return result
async def mutate(pid,body,request,user,remove=False):
    async def operation(session):
        p=await parent(pid,user,session)
        doc=await authorized_document(db(),body.document_id,user,session)
        if not remove and p['agency']!=doc['agency']:raise HTTPException(422,'Pièce et prospect doivent appartenir à la même agence')
        key=pid+':'+body.document_id
        existing=await db().prospect_document_links.find_one({'_id':key},session=session)
        if not remove and existing:return
        if remove and not existing:raise HTTPException(404,'Association introuvable')
        event={'at':datetime.now(timezone.utc).isoformat(),'by':user['name'],'kind':'document','text':('Pièce détachée' if remove else 'Pièce associée')}
        await db().private_documents.update_one({'id':doc['id']},{'$inc':{'revision':1}},session=session)
        await db().demandes.update_one({'id':pid},{'$inc':{'crm_revision':1},'$push':{'history':event}},session=session)
        if remove:await db().prospect_document_links.delete_one({'_id':key},session=session)
        else:await db().prospect_document_links.insert_one({'_id':key,'prospect_id':pid,'document_id':doc['id'],'created_at':event['at'],'by':user['name'],'note':body.note},session=session)
        await log_action('prospect_document_unlink' if remove else 'prospect_document_link',request,user,pid,{'document_id':doc['id']},mongo_session=session)
    await run(db(),operation)
    return {'ok':True}
@router.post('/demandes/{pid}/documents')
async def link(pid:str,body:Link,request:Request,user=Depends(allowed)):return await mutate(pid,body,request,user)
@router.delete('/demandes/{pid}/documents/{did}')
async def unlink(pid:str,did:str,request:Request,user=Depends(allowed)):return await mutate(pid,Link(document_id=did),request,user,True)
