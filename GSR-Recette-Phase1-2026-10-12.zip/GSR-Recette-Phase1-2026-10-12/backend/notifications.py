"""Approved SMTP settings and durable, idempotent email events. Sending is off by default."""
import asyncio
import os
import smtplib
import ssl
import string
import uuid
import json
from datetime import datetime, timezone, timedelta
from zoneinfo import ZoneInfo
from email.message import EmailMessage
from pathlib import Path
from typing import Literal, Optional

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, ConfigDict, EmailStr, Field, model_validator
from pymongo import ReturnDocument

from auth import require_roles, log_action
from security import private_key

router=APIRouter(prefix='/administration/notifications')
_db={}
EVENTS=('accuse','annulation','deplacement','rappel-rdv','intervention-j1')
SERVICES=('creteil','bonneuil','asso')


def service_for(d):
    return 'asso' if d.get('type') in ('partenariat','formation-ia') else d['agency']


class Account(BaseModel):
    model_config=ConfigDict(extra='forbid')
    host:Optional[str]=Field(default=None,max_length=253)
    port:int=Field(default=587,ge=1,le=65535)
    tls:Literal['starttls','ssl']='starttls'
    username:Optional[str]=Field(default=None,max_length=254)


def init(database):_db['db']=database


def now():return datetime.now(timezone.utc).isoformat()


class Template(BaseModel):
    model_config=ConfigDict(extra='forbid')
    subject:str=Field(default='',max_length=160)
    body:str=Field(default='',max_length=5000)
    approved:bool=False

    @model_validator(mode='after')
    def safe_fields(self):
        if '\r' in self.subject or '\n' in self.subject:raise ValueError('Objet invalide')
        for text in (self.subject,self.body):
            for _,key,spec,conversion in string.Formatter().parse(text):
                if key is not None and (key not in ('reference','agency','date','time') or spec or conversion):
                    raise ValueError('Champs autorisés : reference, agency, date, time')
        if self.approved and (not self.subject.strip() or not self.body.strip()):raise ValueError('Modèle approuvé incomplet')
        return self


class Settings(BaseModel):
    model_config=ConfigDict(extra='forbid')
    enabled:bool=False
    host:Optional[str]=Field(default=None,max_length=253)
    port:int=Field(default=587,ge=1,le=65535)
    tls:Literal['starttls','ssl']='starttls'
    username:Optional[str]=Field(default=None,max_length=254)
    from_email:Optional[EmailStr]='asso.gsr@gmail.com'
    creteil_email:Optional[EmailStr]='creteil.gsr@gmail.com'
    bonneuil_email:Optional[EmailStr]='accueil.gsr@gmail.com'
    accounts:dict[str,Account]=Field(default_factory=lambda:{s:Account() for s in SERVICES})
    templates:dict[str,Template]=Field(default_factory=dict)

    @model_validator(mode='after')
    def valid_settings(self):
        if set(self.templates)-set(EVENTS):raise ValueError('Type de modèle inconnu')
        if set(self.accounts)-set(SERVICES):raise ValueError('Compte SMTP inconnu')
        if self.enabled and not ((self.host and self.username and self.from_email) or all(self.accounts.get(s) and self.accounts[s].host and self.accounts[s].username for s in SERVICES)):
            raise ValueError('Configuration SMTP incomplète')
        return self


def password():
    path=os.environ.get('GSR_SMTP_PASSWORD_FILE')
    return Path(path).read_text().strip() if path and Path(path).is_file() else os.environ.get('GSR_SMTP_PASSWORD','')


def account_password(service):
    path=os.environ.get('GSR_SMTP_'+service.upper()+'_PASSWORD_FILE')
    if not path or not Path(path).is_file():return ''
    if Path(path).stat().st_mode & 0o077:
        raise HTTPException(503,'Le fichier de secret SMTP doit être privé.')
    return Path(path).read_text().strip()


def sender(config,service):
    return config['from_email'] if service=='asso' else config.get(service+'_email')


def fingerprint(config,service,secret):
    return private_key(json.dumps(config['accounts'].get(service,{}),sort_keys=True)+str(sender(config,service))+secret)


async def account_status(config):
    result={}
    for service in SERVICES:
        profile=config['accounts'].get(service,{})
        secret=account_password(service)
        checked=await _db['db'].smtp_checks.find_one({'_id':service})
        configured=bool(profile.get('host') and profile.get('username') and secret and sender(config,service))
        result[service]={'password_configured':bool(secret),'configured':configured,
            'verified':bool(configured and checked and checked.get('mode')=='real' and checked.get('fingerprint')==fingerprint(config,service,secret)),
            'last_test_at':checked.get('at') if checked else None}
    return result


def authenticate(profile,secret,smtp_factory=None):
    context=ssl.create_default_context()
    factory=smtp_factory or (smtplib.SMTP_SSL if profile['tls']=='ssl' else smtplib.SMTP)
    kwargs={'timeout':20}
    if profile['tls']=='ssl':kwargs['context']=context
    with factory(profile['host'],profile['port'],**kwargs) as connection:
        if profile['tls']=='starttls':connection.starttls(context=context)
        connection.login(profile['username'],secret)
        connection.noop()


async def test_account(service,smtp_factory=None):
    if service not in SERVICES:raise HTTPException(404,'Compte inconnu')
    config=await settings();secret=account_password(service);profile=config['accounts'].get(service,{})
    if not profile.get('host') or not profile.get('username') or not secret:raise HTTPException(422,'Compte SMTP incomplet')
    try:await asyncio.to_thread(authenticate,profile,secret,smtp_factory)
    except Exception:
        await _db['db'].smtp_checks.delete_one({'_id':service})
        raise HTTPException(422,'Connexion SMTP non validée ; vérifier les paramètres et le secret.')
    await _db['db'].smtp_checks.replace_one({'_id':service},{'_id':service,'at':now(),
        'mode':'simulation' if smtp_factory else 'real','fingerprint':fingerprint(config,service,secret)},upsert=True)
    return {'service':service,'connection_tested':True,'real_sending_allowed':False}


async def settings():
    doc=await _db['db'].site_settings.find_one({'_id':'smtp'},{'_id':0})
    return Settings.model_validate(doc or {}).model_dump()


@router.get('')
async def get_settings(user=Depends(require_roles('direction'))):
    config=await settings();statuses=await account_status(config)
    return {**config,'password_configured':bool(password()),'accounts_status':statuses,
            'all_accounts_verified':all(s['verified'] for s in statuses.values()),
            'testing_enabled':os.environ.get('GSR_SMTP_TEST_ENABLED')=='true',
            'sending_enabled':os.environ.get('GSR_SMTP_SEND_ENABLED')=='true'}


@router.post('/comptes/{service}/tester')
async def check_connection(service:str,request:Request,user=Depends(require_roles('direction'))):
    if os.environ.get('GSR_SMTP_TEST_ENABLED')!='true':raise HTTPException(403,'Tests SMTP réels désactivés dans cet environnement.')
    try:result=await test_account(service)
    except HTTPException:
        await log_action('smtp_test',request,user,meta={'service':service,'success':False});raise
    await log_action('smtp_test',request,user,meta={'service':service,'success':True})
    return result


@router.put('')
async def save_settings(body:Settings,request:Request,user=Depends(require_roles('direction'))):
    await _db['db'].site_settings.replace_one({'_id':'smtp'},{'_id':'smtp',**body.model_dump()},upsert=True)
    await log_action('smtp_settings',request,user,meta={'enabled':body.enabled,'approved_templates':sum(t.approved for t in body.templates.values())})
    return await get_settings(user)


@router.get('/journal')
async def journal(user=Depends(require_roles('direction'))):
    return await _db['db'].mail_outbox.find({}, {'_id':0,'id':1,'event':1,'status':1,'created_at':1,'attempted_at':1,'sent_at':1,'failure':1,'service':1,'sender':1,'reply_to':1,'recipient':1}).sort('created_at',-1).to_list(200)


async def queue(database,d,event,key,mongo_session=None,slot=None,extra=None):
    if not d.get('email'):return
    await database.mail_outbox.update_one({'_id':key},{'$setOnInsert':{
        'id':uuid.uuid4().hex,'event':event,'status':'pending','created_at':now(),
        'recipient':d['email'],'agency':d['agency'],'service':service_for(d),'payload':{
            'reference':d['reference'],'agency':d['agency'],
            'date':slot['date'] if slot else '', 'time':slot['time'] if slot else ''}, **(extra or {})}},
        upsert=True,session=mongo_session)


def transmit(config,event,secret,smtp_factory=None):
    template=config['templates'][event['event']]
    message=EmailMessage();message['Subject']=template['subject'].format_map(event['payload'])
    address=sender(config,event.get('service',event['agency']))
    message['From']=address
    message['Reply-To']=address
    message['To']=event['recipient'];message['Message-ID']='<'+event['id']+'@gsr.local>'
    message.set_content(template['body'].format_map(event['payload']))
    context=ssl.create_default_context()
    factory=smtp_factory or (smtplib.SMTP_SSL if config['tls']=='ssl' else smtplib.SMTP)
    kwargs={'timeout':20}
    if config['tls']=='ssl':kwargs['context']=context
    with factory(config['host'],config['port'],**kwargs) as connection:
        if config['tls']=='starttls':connection.starttls(context=context)
        connection.login(config['username'],secret)
        connection.send_message(message)


async def dispatch_one(smtp_factory=None):
    config=await settings();secret=password()
    simulated=smtp_factory is not None
    statuses=await account_status(config)
    if os.environ.get('GSR_SMTP_SEND_ENABLED')!='true' or not config['enabled'] or (not simulated and not all(s['verified'] for s in statuses.values())):
        return 'configuration_required'
    approved=[key for key,template in config['templates'].items() if template['approved']]
    event=await _db['db'].mail_outbox.find_one_and_update(
        {'status':'pending','event':{'$in':approved}},
        {'$set':{'status':'sending','attempted_at':now()}},return_document=ReturnDocument.AFTER)
    if not event:return 'idle'
    service=event.get('service')
    if not service:
        demand=await _db['db'].demandes.find_one({'reference':event['payload']['reference']},{'type':1,'agency':1})
        service=service_for(demand) if demand else event['agency']
        event={**event,'service':service}
    profile=config['accounts'].get(service,{})
    if profile.get('host') and profile.get('username'):
        config={**config,**profile};secret=account_password(service)
    address=sender(config,service)
    await _db['db'].mail_outbox.update_one({'_id':event['_id']},{'$set':{'service':service,'sender':address,'reply_to':address}})
    if event['event']=='intervention-j1':
        demand=await _db['db'].demandes.find_one({'id':event.get('demande_id'),'archived':{'$ne':True},'first_response_at':{'$in':[None,'']},'status':{'$in':['nouveau','en_cours']}})
        if not demand:
            await _db['db'].mail_outbox.update_one({'_id':event['_id']},{'$set':{'status':'cancelled'}})
            return 'cancelled'
    if event['event']=='rappel-rdv':
        demand=await _db['db'].demandes.find_one({'id':event.get('demande_id'),'status':'rdv_fixe',
            'creneau_id':event.get('slot_id'),'reservation_active':{'$ne':False}})
        slot=await _db['db'].creneaux.find_one({'id':event.get('slot_id')}) if demand else None
        appointment=(datetime.fromisoformat(slot['date']+'T'+slot['time']).replace(tzinfo=ZoneInfo('Europe/Paris')).astimezone(timezone.utc)) if slot else None
        if not appointment or appointment <= datetime.now(timezone.utc):
            await _db['db'].mail_outbox.update_one({'_id':event['_id']},{'$set':{'status':'cancelled'}})
            return 'cancelled'
    try:
        await asyncio.to_thread(transmit,config,event,secret,smtp_factory)
    except Exception:
        # Delivery may already have happened: do not automatically resend uncertain events.
        await _db['db'].mail_outbox.update_one({'_id':event['_id']},{'$set':{'status':'uncertain','failure':'Envoi non confirmé : vérification humaine requise.'}})
        return 'uncertain'
    await _db['db'].mail_outbox.update_one({'_id':event['_id']},{'$set':{'status':'sent','sent_at':now()}})
    return 'sent'


async def reminders(database, instant=None):
    instant=instant or datetime.now(timezone.utc)
    window=instant+timedelta(hours=24)
    async for slot in database.creneaux.find({'date':{'$gte':instant.astimezone(ZoneInfo('Europe/Paris')).date().isoformat(),
                                                     '$lte':window.astimezone(ZoneInfo('Europe/Paris')).date().isoformat()}}):
        appointment=datetime.fromisoformat(slot['date']+'T'+slot['time']).replace(tzinfo=ZoneInfo('Europe/Paris')).astimezone(timezone.utc)
        if not instant < appointment <= window:continue
        async for d in database.demandes.find({'creneau_id':slot['id'],'status':'rdv_fixe','reservation_active':{'$ne':False}}):
            key=d['id']+':reminder:'+slot['id']
            await queue(database,d,'rappel-rdv',key,slot=slot,extra={'demande_id':d['id'],'slot_id':slot['id']})


async def worker():
    from motor.motor_asyncio import AsyncIOMotorClient
    client=AsyncIOMotorClient(os.environ['MONGO_URL']);init(client[os.environ['DB_NAME']])
    try:
        while True:
            try:
                from crm_workflow import worker as process_crm_tasks
                await process_crm_tasks(_db['db'])
                from internal_notifications import intervention_alerts
                await intervention_alerts(_db['db'])
                await reminders(_db['db'])
                await dispatch_one()
            except Exception:
                print('Échec du traitement des notifications ; événements conservés pour vérification.',flush=True)
            await asyncio.sleep(30)
    finally:client.close()


if __name__=='__main__':asyncio.run(worker())
